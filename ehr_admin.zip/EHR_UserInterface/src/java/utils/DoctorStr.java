/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import admin_ws.HcProfessionalEntity;

/**
 *
 * @author Alina
 */
public class DoctorStr extends HcProfessionalEntity {
    
    @Override
    public String toString(){
    return name;
    }
}
