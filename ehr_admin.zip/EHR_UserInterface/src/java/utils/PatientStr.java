/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import admin_ws.PatientEntity;

/**
 *
 * @author Alina
 */
public class PatientStr extends PatientEntity {

    @Override
    public String toString() {
        return name;
    }
}
