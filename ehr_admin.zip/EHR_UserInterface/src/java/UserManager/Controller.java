/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UserManager;

import admin_ws.AddressEntity;
import admin_ws.HcOrganizationEntity;
import java.util.List;

/**
 *
 * @author Alina
 */
public class Controller {

    private static class SingletonHolder {

        private static final Controller INSTANCE = new Controller();
    }

    public static Controller getInstance() {
        return SingletonHolder.INSTANCE;
    }
    admin_ws.AdminWebService_Service service = new admin_ws.AdminWebService_Service();
    admin_ws.AdminWebService port = service.getAdminWebServicePort();
    hcwebservices.EditEOCWebService_Service service_edit = new hcwebservices.EditEOCWebService_Service();
    hcwebservices.EditEOCWebService port_edit = service_edit.getEditEOCWebServicePort();
    hcwebservices.DeleteEOCWebService_Service service_delete = new hcwebservices.DeleteEOCWebService_Service();
    hcwebservices.DeleteEOCWebService port_delete = service_delete.getDeleteEOCWebServicePort();

    public HcOrganizationEntity addHCOrganization(java.lang.String name, java.lang.String details) {
        return port.addHCOrganization(name, details);
    }

    public void addHCOrganizationAddress(java.lang.Long orgId, java.lang.Long addressId) {
        port.addHCOrganizationAddress(orgId, addressId);
    }

    public Long addHCProfessional(java.lang.String name, java.lang.String specialization, java.lang.String email, java.lang.String phone, java.lang.String username, java.lang.String password, java.lang.Long userTypeId) {
        return port.addHCProfessional(name, specialization, email, phone, username, password, userTypeId);
    }

    public void addHcOrgToDoctor(java.lang.Long hcOrgId, java.lang.Long doctorId) {
        port.addHcOrgToDoctor(hcOrgId, doctorId);
    }

    public AddressEntity createAddress(java.lang.String country, java.lang.String city, java.lang.String street, java.lang.String number) {
        return port.createAddress(country, city, street, number);
    }

    public Long createPatient(java.lang.String name, java.lang.String cnp, java.lang.String healthInsurance,
            int age, java.lang.String bloodType, java.lang.String ethnicity,
            java.lang.String email, java.lang.String username, java.lang.String password) {
        return port.createPatient(name, cnp, healthInsurance, age, bloodType, ethnicity, email, username, password);
    }

    public void createUserType(java.lang.String type) {
        port.createUserType(type);
    }

    public Long findDoctorByName(java.lang.String name) {
        return port.findDoctorByName(name);
    }

    public java.util.List<java.lang.String> getHCProviders() {
        return port.getHCProviders();
    }

    public Long getPatientIdByName(java.lang.String name) {
        return port.getPatientIdByName(name);
    }

    public Long getUserTypeId(java.lang.String type) {
        return port.getUserTypeId(type);
    }

    public java.util.List<java.lang.String> getUserTypes() {
        return port.getUserTypes();
    }

    public void addPatientToHCProvider(java.lang.Long doctorId, java.lang.Long patientId) {
        port.addPatientToHCProvider(doctorId, patientId);
    }

    public void addAddressToPatient(java.lang.Long patientId, java.lang.Long addressId) {
        port.addAddressToPatient(patientId, addressId);
    }

    public boolean updateDoctorDetails(java.lang.Long userId, java.lang.Long doctorId, java.lang.String name, java.lang.String specialization, java.lang.String email, java.lang.String phone, java.lang.String username, java.lang.String password, java.lang.Long userTypeId) {
        return port_edit.updateDoctorDetails(userId, doctorId, name, specialization, email, phone, username, password, userTypeId);
    }

    public boolean updatePatient(java.lang.Long userId, java.lang.Long patientId, java.lang.String name,
            java.lang.String cnp, java.lang.String healthInsurance, int age, java.lang.String bloodType,
            java.lang.String ethnicity, java.lang.String email, java.lang.String username, java.lang.String password) {
        return port_edit.updatePatient(userId, patientId, name, cnp, healthInsurance, age, bloodType, ethnicity, email, username, password);
    }

    public void updateAddress(java.lang.Long addressId, java.lang.String country, java.lang.String city, java.lang.String street, java.lang.String number) {
        port_edit.updateAddress(addressId, country, city, street, number);
    }

    public void updateHCOrganization(java.lang.Long hcOrgId, java.lang.String name, java.lang.String details) {
        port_edit.updateHCOrganization(hcOrgId, name, details);
    }

    public void deleteDoctor(java.lang.Long doctorId) {
        port_delete.deleteDoctor(doctorId);
    }

    public void deletePatient(java.lang.Long patientId) {
        port_delete.deletePatient(patientId);
    }

    public java.util.List<admin_ws.PatientEntity> getAllPatients() {
        return port.getAllPatients();
    }

    public java.util.List<admin_ws.HcProfessionalEntity> getAllDoctors() {
        return port.getAllDoctors();
    }

    public java.util.List<java.lang.String> getHCProfessionalDetailsByHCProfessionalName(java.lang.String hcProfessionalName) {
        return port.getHCProfessionalDetailsByHCProfessionalName(hcProfessionalName);
    }

    public Long getAddressIdOfHCOrg(java.lang.Long hcOrgId) {
        return port_edit.getAddressIdOfHCOrg(hcOrgId);
    }

    public Long getHCOrgIdOfDoctor(java.lang.Long doctorId) {
        return port_edit.getHCOrgIdOfDoctor(doctorId);
    }

    public Long getUserIdOfDoctor(java.lang.Long doctorId) {
        return port_edit.getUserIdOfDoctor(doctorId);
    }

    public java.util.List<java.lang.String> getPatientById(java.lang.Long id) {
        return port.getPatientById(id);
    }

    public Long getAddressOfPatient(java.lang.Long patientId) {
        return port_edit.getAddressOfPatient(patientId);
    }

    public Long getUserIdOfPatient(java.lang.Long patientId) {
        return port_edit.getUserIdOfPatient(patientId);
    }

    public List<String> getPatientNames() {
        return port.getPatientNames();
    }

    public java.util.List<java.lang.Long> getPatients() {
        return port.getPatients();
    }

    public Long createAdminUser(java.lang.String password) {
        return port.createAdminUser(password);
    }

    public Long checkAdminLogin(java.lang.String password) {
        return port.checkAdminLogin(password);
    }

    public java.util.List<java.lang.Long> getDoctorsOfPatient(java.lang.Long patientId) {
        return port.getDoctorsOfPatient(patientId);
    }

    public java.util.List<java.lang.Long> getPatientsOfDoctor(java.lang.Long doctorId) {
        return port.getPatientsOfDoctor(doctorId);
    }

    public void removePatientFromDoctorList(java.lang.Long patientId, java.lang.Long doctorId) {
        port_delete.removePatientFromDoctorList(patientId, doctorId);
    }

    public void editAdminUser(java.lang.Long adminId, java.lang.String password) {
        port_edit.editAdminUser(adminId, password);
    }

    public void removeUserType(java.lang.String userTypeName) {
        port_delete.removeUserType(userTypeName);
    }

  
}