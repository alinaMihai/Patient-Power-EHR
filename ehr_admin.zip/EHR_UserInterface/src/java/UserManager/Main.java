package UserManager;

import com.digitprop.tonic.TonicLookAndFeel;
import javax.swing.JFrame;
import javax.swing.UIManager;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Alina
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //String lookAndFeel = "com.nilo.plaf.nimrod.NimRODMain";
        try {
            TonicLookAndFeel tlaf = new TonicLookAndFeel();
            UIManager.setLookAndFeel(tlaf);
            JFrame.setDefaultLookAndFeelDecorated(true);

        } catch (Exception e) {
            System.out.println("L&F isn't available");
        }
        // TODO code application logic here
        Login frame = new Login("Login");
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
