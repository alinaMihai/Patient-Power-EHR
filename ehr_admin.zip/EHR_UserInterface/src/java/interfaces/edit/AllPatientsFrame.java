/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.edit;

import UserManager.Controller;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import utils.DoctorStr;
import utils.PatientStr;

/**
 *
 * @author Alina
 */
public class AllPatientsFrame extends javax.swing.JFrame {

    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    private static JTree patientsTree;
    private DefaultMutableTreeNode selectedDoctorNode;
    private DoctorStr doctor;
    private Controller command;

    /**
     * Creates new form AllPatientsFrame
     */
    public AllPatientsFrame(String name) {
        super(name);
        command = Controller.getInstance();
        top = new DefaultMutableTreeNode("Patients", true);
        patientsTree = new JTree(top);
        model = (DefaultTreeModel) patientsTree.getModel();
        patientsTree.setRootVisible(false);
        patientsTree.setShowsRootHandles(true);
        initComponents();
        ArrayList<Long> patients = (ArrayList<Long>) command.getPatients();
        if (this.getTitle().equals("Patients Database")) {
            patientsTree.addMouseListener(new PatientsTreeAction(patientsTree));
            if (!patients.isEmpty()) {
                List<String> patientNames = command.getPatientNames();
                int i = 0;
                for (Long pId : patients) {
                    PatientStr patient = new PatientStr();
                    patient.setId(pId);
                    String patientName = patientNames.get(i);
                    i++;
                    patient.setName(patientName);
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(patient, false);
                    model.insertNodeInto(item, top, top.getChildCount());
                    model.nodeStructureChanged(top);

                    //top.add(item);
                    patient_list_lb.setVisible(false);
                }

            }
        }


        if (this.getTitle().equals("Add Patient to Healthcare Provider's list")) {
            selectedDoctorNode = (DefaultMutableTreeNode) AllDoctorsFrame.getDoctorsTree().getLastSelectedPathComponent();
            if (selectedDoctorNode != null) {
                doctor = (DoctorStr) selectedDoctorNode.getUserObject();
                List<Long> patientsOfDoctor = command.getPatientsOfDoctor(doctor.getId());

                if (!patients.isEmpty()) {
                    List<String> patientNames = command.getPatientNames();
                    int i = 0;
                    for (Long pId : patients) {
                        if (!patientsOfDoctor.contains(pId)) {
                            PatientStr patient = new PatientStr();
                            patient.setId(pId);
                            String patientName = patientNames.get(i);

                            // String patientName = command.getPatientName(pId);
                            patient.setName(patientName);
                            DefaultMutableTreeNode item = new DefaultMutableTreeNode(patient, false);
                            model.insertNodeInto(item, top, top.getChildCount());
                            model.nodeStructureChanged(top);

                            //top.add(item);
                        }
                        i++;
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No object is selected");
            }
            info_label.setText("");
            patient_list_lb.setVisible(true);
        }
        if (this.getTitle().equals("Remove Patient from Healthcare Provider's list")) {
            selectedDoctorNode = (DefaultMutableTreeNode) AllDoctorsFrame.getDoctorsTree().getLastSelectedPathComponent();
            if (selectedDoctorNode != null) {
                doctor = (DoctorStr) selectedDoctorNode.getUserObject();
                List<Long> patientsOfDoctor = command.getPatientsOfDoctor(doctor.getId());

                if (!patients.isEmpty()) {
                    List<String> patientNames = command.getPatientNames();
                    int i = 0;
                    for (Long pId : patients) {
                        if (patientsOfDoctor.contains(pId)) {
                            PatientStr patient = new PatientStr();
                            patient.setId(pId);
                            String patientName = patientNames.get(i);

                            //  String patientName = command.getPatientName(pId);
                            patient.setName(patientName);
                            DefaultMutableTreeNode item = new DefaultMutableTreeNode(patient, false);
                            model.insertNodeInto(item, top, top.getChildCount());
                            model.nodeStructureChanged(top);

                            // top.add(item);
                        }
                        i++;
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No object is selected");
            }
            info_label.setText("");
            patient_list_lb.setVisible(true);
        }
        for (int i = 0;
                i < patientsTree.getRowCount();
                i++) {
            patientsTree.expandRow(i);

        }
    }

    public JLabel getTitle_label() {
        return title_label;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    public static JTree getPatientsTree() {
        return patientsTree;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        title_label = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = patientsTree;
        OK_bt = new javax.swing.JButton();
        info_label = new javax.swing.JLabel();
        cancel_bt = new javax.swing.JButton();
        patient_list_lb = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_label.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_label.setText(" Patients Database");

        jScrollPane1.setViewportView(jTree1);

        OK_bt.setText("OK");
        OK_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OK_btActionPerformed(evt);
            }
        });

        info_label.setText("Right click a Patient to see options");

        cancel_bt.setText("Cancel");
        cancel_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_btActionPerformed(evt);
            }
        });

        patient_list_lb.setText("Select a Patient and then click OK");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addComponent(title_label, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(OK_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cancel_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(info_label)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(patient_list_lb)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(title_label)
                .addGap(18, 18, 18)
                .addComponent(patient_list_lb)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(info_label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 317, Short.MAX_VALUE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(OK_bt)
                    .addComponent(cancel_bt))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void OK_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OK_btActionPerformed
        // TODO add your handling code here:
        if (this.getTitle().equals("Add Patient to Healthcare Provider's list")) {

            DefaultMutableTreeNode selectedPatientNode = (DefaultMutableTreeNode) patientsTree.getLastSelectedPathComponent();
            if (selectedPatientNode != null) {
                PatientStr patient = (PatientStr) selectedPatientNode.getUserObject();
                command.addPatientToHCProvider(doctor.getId(), patient.getId());
                JOptionPane.showMessageDialog(null, "Patient added to Healthcare Provider's list");
                patientsTree.setSelectionPath(null);
            } else {
                JOptionPane.showMessageDialog(null, "No Patient Selected! Please select a Patient");
            }
        }
        if (this.getTitle().equals("Remove Patient from Healthcare Provider's list")) {
            DefaultMutableTreeNode selectedPatientNode = (DefaultMutableTreeNode) patientsTree.getLastSelectedPathComponent();
            if (selectedPatientNode != null) {

                PatientStr patient = (PatientStr) selectedPatientNode.getUserObject();
                command.removePatientFromDoctorList(patient.getId(), doctor.getId());
                JOptionPane.showMessageDialog(null, "Patient removed from Healthcare Provider's list");
                model.removeNodeFromParent(selectedPatientNode);
                model.reload();
                for (int i = 0; i < patientsTree.getRowCount(); i++) {
                    patientsTree.expandRow(i);

                }
            } else {
                JOptionPane.showMessageDialog(null, "No Patient Selected! Please select a Patient");
            }
        }
        if (this.getTitle().equals("Patients Database")) {
            this.setVisible(false);
        }
    }//GEN-LAST:event_OK_btActionPerformed

    public JButton getOK_bt() {
        return OK_bt;
    }

    public JButton getCancel_bt() {
        return cancel_bt;
    }

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void cancel_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_btActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_cancel_btActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;


                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AllPatientsFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AllPatientsFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AllPatientsFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AllPatientsFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AllPatientsFrame("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton OK_bt;
    private javax.swing.JButton cancel_bt;
    private javax.swing.JLabel info_label;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTree jTree1;
    private javax.swing.JLabel patient_list_lb;
    private javax.swing.JLabel title_label;
    // End of variables declaration//GEN-END:variables
}
