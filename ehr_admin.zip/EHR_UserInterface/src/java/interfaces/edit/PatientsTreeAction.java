/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.edit;

import UserManager.Controller;
import interfaces.CreatePatient;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import utils.PatientStr;

/**
 *
 * @author Alina
 */
public class PatientsTreeAction extends MouseAdapter {

    protected JTree tree;
    private Controller command;
    private Long patientId;
    private DefaultMutableTreeNode selectionNode;
    private PatientStr patient=null;
    private String name=null;
    public PatientsTreeAction(JTree tree) {
        this.tree = tree;
        this.command = Controller.getInstance();

    }

    @Override
    public void mousePressed(MouseEvent e) {

        if (SwingUtilities.isRightMouseButton(e)) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
           patient=(PatientStr)selectionNode.getUserObject();
           name=patient.getName();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);

            if (selectionNode.getAllowsChildren() == false) {
                JPopupMenu menu = new JPopupMenu();
                JMenuItem jt1 = new JMenuItem("Edit Patient");
                jt1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        DefaultMutableTreeNode selectedPatientNode = (DefaultMutableTreeNode) AllPatientsFrame.getPatientsTree().getLastSelectedPathComponent();
                        PatientStr patient = (PatientStr) selectedPatientNode.getUserObject();
                        List<String> p = command.getPatientById(patient.getId());
                        CreatePatient frame = new CreatePatient("Edit Patient");
                        frame.getTitle_label().setText("Edit "+name);
                        frame.getFull_name_tf().setText((String) p.get(0));
                        frame.getCnp_tf().setText(p.get(1));
                        frame.getHealthInsurance_tf().setText(p.get(2));
                        frame.getAge_tf().setText(p.get(3));
                        frame.getBloodType_tf().setText(p.get(4));
                        frame.getEthnicity_tf().setText(p.get(5));
                        frame.getEmail_tf().setText(p.get(6));
                        frame.getCity_tf().setText(p.get(8));
                        frame.getCountry_tf().setText(p.get(9));
                        frame.getStreet_tf().setText(p.get(10));
                        frame.getNumber_tf().setText(p.get(11));
                        frame.getUsername_tf().setText(p.get(12));
                        frame.getPassword_tf().setText(p.get(13));
                        frame.getPassword_tf().setEchoChar((char) 0);

                        frame.setResizable(false);
                        frame.setLocationRelativeTo(null);
                        frame.setVisible(true);
                    }
                });
                menu.add(jt1);
                JMenuItem jt2 = new JMenuItem("Delete Patient");
                jt2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        // command to delete doctor with question
                        if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Patient", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                            PatientStr patient = (PatientStr) selectionNode.getUserObject();
                            AllPatientsFrame.getTop().remove(selectionNode);
                            AllPatientsFrame.getModel().reload();
                            patientId = patient.getId();
                            command.deletePatient(patientId);
                        JOptionPane.showMessageDialog(null, "Patient successfully removed from the database");
                        }
                    }
                });
                menu.add(jt2);
                JMenuItem jt3 = new JMenuItem("Add Healthcare Provider to Patient's list");
                jt3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        // new frame with a list of doctors to add to the patient's list
                        AllDoctorsFrame frame = new AllDoctorsFrame("Add Healthcare Provider to Patient's list");
                        frame.getTitle_label().setText("Add Healthcare Provider to "+name+ "'s list");
                        frame.setResizable(false);
                        frame.setLocationRelativeTo(null);
                        frame.setVisible(true);
                    }
                });
                menu.add(jt3);
                JMenuItem jt4 = new JMenuItem("Remove Healthcare Provider from Patient's list");
                jt4.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        // new frame with a list of doctors to add to the patient's list
                        AllDoctorsFrame frame = new AllDoctorsFrame("Remove Healthcare Provider from Patient's list");
                        frame.getTitle_label().setText("Remove Healthcare Provider from "+name+ "'s list");
                        frame.setResizable(false);
                        frame.setLocationRelativeTo(null);
                        frame.setVisible(true);
                    }
                });
                menu.add(jt4);
                menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);

            }
        }
    }
}
