/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.edit;

import UserManager.Controller;
import admin_ws.HcProfessionalEntity;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import utils.DoctorStr;
import utils.PatientStr;

/**
 *
 * @author Alina
 */
public class AllDoctorsFrame extends javax.swing.JFrame {

    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    private static JTree doctorsTree;
    private DefaultMutableTreeNode selectedPatientNode;
    private PatientStr patient;
    private Controller command;

    /**
     * Creates new form AllDoctorsFrame
     */
    public AllDoctorsFrame(String name) {
        super(name);
        command = Controller.getInstance();
        top = new DefaultMutableTreeNode("Doctors", true);
        doctorsTree = new JTree(top);
        doctorsTree.setRootVisible(false);
        doctorsTree.setShowsRootHandles(true);
        model = (DefaultTreeModel) doctorsTree.getModel();
          initComponents();
        List<admin_ws.HcProfessionalEntity> doctors = command.getAllDoctors();
        if (this.getTitle().equals("Healthcare Providers Database")) {
            doctorsTree.addMouseListener(new DoctorsTreeAction(doctorsTree));
            if (!doctors.isEmpty()) {
                for (HcProfessionalEntity hcp : doctors) {
                    DoctorStr doc = new DoctorStr();
                    doc.setId(hcp.getId());
                    doc.setName(hcp.getName());
                    doc.setSpecialization(hcp.getSpecialization());
                    doc.setEmail(hcp.getEmail());
                    doc.setPhone(hcp.getPhone());

                    DefaultMutableTreeNode hcpNode = new DefaultMutableTreeNode(doc, false);
                    model.insertNodeInto(hcpNode, top, top.getChildCount());
                    model.nodeStructureChanged(top);

                    // top.add(hcpNode);
                }
            }
             doctor_list_infoLB.setVisible(false);
        }

      
        if (this.getTitle().equals("Add Healthcare Provider to Patient's list")) {
            selectedPatientNode = (DefaultMutableTreeNode) AllPatientsFrame.getPatientsTree().getLastSelectedPathComponent();
            patient = (PatientStr) selectedPatientNode.getUserObject();
            List<Long> doctorsOfPatient = command.getDoctorsOfPatient(patient.getId());

            if (!doctors.isEmpty()) {
                for (HcProfessionalEntity hcp : doctors) {
                    if (!doctorsOfPatient.contains(hcp.getId())) {
                        DoctorStr doc = new DoctorStr();
                        doc.setId(hcp.getId());
                        doc.setName(hcp.getName());
                        doc.setSpecialization(hcp.getSpecialization());
                        doc.setEmail(hcp.getEmail());
                        doc.setPhone(hcp.getPhone());

                        DefaultMutableTreeNode hcpNode = new DefaultMutableTreeNode(doc, false);
                        model.insertNodeInto(hcpNode, top, top.getChildCount());
                        model.nodeStructureChanged(top);

                        //top.add(hcpNode);
                    }
                }
            }
            info_lb.setText("");
             doctor_list_infoLB.setVisible(true);
        }
        if (this.getTitle().equals("Remove Healthcare Provider from Patient's list")) {
            selectedPatientNode = (DefaultMutableTreeNode) AllPatientsFrame.getPatientsTree().getLastSelectedPathComponent();
            patient = (PatientStr) selectedPatientNode.getUserObject();
            List<Long> doctorsOfPatient = command.getDoctorsOfPatient(patient.getId());

            if (!doctors.isEmpty()) {
                for (HcProfessionalEntity hcp : doctors) {
                    if (doctorsOfPatient.contains(hcp.getId())) {
                        DoctorStr doc = new DoctorStr();
                        doc.setId(hcp.getId());
                        doc.setName(hcp.getName());
                        doc.setSpecialization(hcp.getSpecialization());
                        doc.setEmail(hcp.getEmail());
                        doc.setPhone(hcp.getPhone());
                        DefaultMutableTreeNode hcpNode = new DefaultMutableTreeNode(doc, false);
                        model.insertNodeInto(hcpNode, top, top.getChildCount());
                        model.nodeStructureChanged(top);

                        //top.add(hcpNode);
                    }
                }
            }
            info_lb.setText("");
         doctor_list_infoLB.setVisible(true);
        }

        for (int i = 0; i < doctorsTree.getRowCount(); i++) {
            doctorsTree.expandRow(i);
        }
    }

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static JTree getDoctorsTree() {
        return doctorsTree;
    }

    public JLabel getTitle_label() {
        return title_label;
    }

    public JButton getCancel_bt() {
        return cancel_bt;
    }

    public JButton getOk_bt() {
        return ok_bt;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        title_label = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = doctorsTree;
        ok_bt = new javax.swing.JButton();
        info_lb = new javax.swing.JLabel();
        cancel_bt = new javax.swing.JButton();
        doctor_list_infoLB = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_label.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_label.setText("Healthcare Providers Database");

        jTree1.setForeground(new java.awt.Color(100, 70, 163));
        jScrollPane1.setViewportView(jTree1);

        ok_bt.setText("OK");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        info_lb.setText("Right click a Healthcare Provider to see options");

        cancel_bt.setText("Cancel");
        cancel_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_btActionPerformed(evt);
            }
        });

        doctor_list_infoLB.setText("Select a Healthcare Provider and then click OK");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(doctor_list_infoLB)
                            .addComponent(info_lb))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ok_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cancel_bt, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(title_label, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(title_label)
                .addGap(27, 27, 27)
                .addComponent(info_lb)
                .addGap(2, 2, 2)
                .addComponent(doctor_list_infoLB)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ok_bt)
                    .addComponent(cancel_bt))
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed
        // TODO add your handling code here:
        if (this.getTitle().equals("Add Healthcare Provider to Patient's list")) {

            DefaultMutableTreeNode selectedDoctorNode = (DefaultMutableTreeNode) doctorsTree.getLastSelectedPathComponent();
            if (selectedDoctorNode != null) {
                DoctorStr doctor = (DoctorStr) selectedDoctorNode.getUserObject();
                command.addPatientToHCProvider(doctor.getId(), patient.getId());
                JOptionPane.showMessageDialog(null, "Healthcare Provider added to Patient's List");
                doctorsTree.setSelectionPath(null);
            } else {
                JOptionPane.showMessageDialog(null, "No object is selected");
            }
        }
        if (this.getTitle().equals("Remove Healthcare Provider from Patient's list")) {
            DefaultMutableTreeNode selectedDoctorNode = (DefaultMutableTreeNode) doctorsTree.getLastSelectedPathComponent();
            if (selectedDoctorNode != null) {
                DoctorStr doctor = (DoctorStr) selectedDoctorNode.getUserObject();
                command.removePatientFromDoctorList(patient.getId(), doctor.getId());
                model.removeNodeFromParent(selectedDoctorNode);
                model.reload();
                for (int i = 0; i < doctorsTree.getRowCount(); i++) {
                    doctorsTree.expandRow(i);
                }
                JOptionPane.showMessageDialog(null, "Healthcare Provider removed from Patient's list");
                doctorsTree.setSelectionPath(null);
            } else {
                JOptionPane.showMessageDialog(null, "No object is selected");
            }
        }
        if (this.getTitle().equals("Healthcare Providers Database")) {

            this.setVisible(false);
        }

    }//GEN-LAST:event_ok_btActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void cancel_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_btActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_cancel_btActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AllDoctorsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AllDoctorsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AllDoctorsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AllDoctorsFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AllDoctorsFrame("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancel_bt;
    private javax.swing.JLabel doctor_list_infoLB;
    private javax.swing.JLabel info_lb;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTree jTree1;
    private javax.swing.JButton ok_bt;
    private javax.swing.JLabel title_label;
    // End of variables declaration//GEN-END:variables
}
