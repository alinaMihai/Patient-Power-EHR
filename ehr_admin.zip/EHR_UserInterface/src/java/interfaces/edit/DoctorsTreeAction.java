/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.edit;

import UserManager.Controller;
import interfaces.CreateDoctor;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import utils.DoctorStr;

/**
 *
 * @author Alina
 */
public class DoctorsTreeAction extends MouseAdapter {

    protected JTree tree;
    private Controller command;
    private Long doctorId;
    private DefaultMutableTreeNode selectionNode;
    private DoctorStr doctor = null;
    private String name;

    public DoctorsTreeAction(JTree tree) {
        this.tree = tree;
        this.command = Controller.getInstance();

    }

    @Override
    public void mousePressed(MouseEvent e) {

        if (SwingUtilities.isRightMouseButton(e)) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            doctor = (DoctorStr) selectionNode.getUserObject();
            name = doctor.getName();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);

            if (selectionNode.getAllowsChildren() == false) {
                JPopupMenu menu = new JPopupMenu();
                JMenuItem jt1 = new JMenuItem("Edit Healthcare Provider");
                jt1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        CreateDoctor frame = new CreateDoctor("Edit Healthcare Provider");
                        frame.getTitle_label().setText("Edit "+name);
                        DoctorStr doc = (DoctorStr) selectionNode.getUserObject();
                        String doctorName = doc.getName();
                        List<String> hcpDetails = command.getHCProfessionalDetailsByHCProfessionalName(doctorName);
                        if (!hcpDetails.isEmpty()) {
                            frame.getName_tf().setText(hcpDetails.get(0));
                            frame.getSpecialization_tf().setText(hcpDetails.get(1));
                            frame.getPhone_tf().setText(hcpDetails.get(2));
                            frame.getEmail_tf().setText(hcpDetails.get(3));
                            frame.getUserType_cb().setSelectedItem(hcpDetails.get(4));
                            frame.getHCOrgName_tf().setText(hcpDetails.get(5));
                            frame.getDescription_ta().setText(hcpDetails.get(6));
                            frame.getCity_tf().setText(hcpDetails.get(7));
                            frame.getCountry_tf().setText(hcpDetails.get(8));
                            frame.getStreet_tf().setText(hcpDetails.get(9));
                            frame.getNumber_tf().setText(hcpDetails.get(10));
                            frame.getUsername_tf().setText(hcpDetails.get(11));
                            frame.getPassword_tf().setEchoChar((char) 0);
                            frame.getPassword_tf().setText(hcpDetails.get(12));

                        }
                        frame.setResizable(false);
                        frame.setLocationRelativeTo(null);
                        frame.setVisible(true);
                    }
                });
                menu.add(jt1);
                JMenuItem jt2 = new JMenuItem("Delete Healthcare Provider");
                jt2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        // command to delete doctor with question
                        if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Healthcare Provider", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                            DoctorStr doctor = (DoctorStr) selectionNode.getUserObject();
                            AllDoctorsFrame.getTop().remove(selectionNode);
                            AllDoctorsFrame.getModel().reload();
                            doctorId = doctor.getId();
                            command.deleteDoctor(doctorId);
                       JOptionPane.showMessageDialog(null, "Healthcare Provider successfully removed from the database"); }
                    }
                });
                menu.add(jt2);
                JMenuItem jt3 = new JMenuItem("Add Patient to Healthcare Provider's list");
                jt3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        // new frame with a list of pacients to add to the doctor's list

                        AllPatientsFrame frame = new AllPatientsFrame("Add Patient to Healthcare Provider's list");
                        frame.getTitle_label().setText("Add Patient to " + name + " 's list");
                        frame.setResizable(false);
                        frame.setLocationRelativeTo(null);
                        frame.setVisible(true);
                    }
                });
                menu.add(jt3);
                JMenuItem jt4 = new JMenuItem("Remove Patient from Healthcare Provider's list");
                jt4.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        // new frame with a list of pacients to add to the doctor's list
                        AllPatientsFrame frame = new AllPatientsFrame("Remove Patient from Healthcare Provider's list");
                        frame.getTitle_label().setText("Remove Patient from " + name + " 's list");
                        frame.setResizable(false);
                        frame.setLocationRelativeTo(null);
                        frame.setVisible(true);
                    }
                });
                menu.add(jt4);
                menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);

            }
        }
    }
}
