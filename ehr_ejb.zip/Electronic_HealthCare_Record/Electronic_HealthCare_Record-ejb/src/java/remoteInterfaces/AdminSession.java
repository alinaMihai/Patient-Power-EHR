/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package remoteInterfaces;

import javax.ejb.Remote;

/**
 *
 * @author Alina
 */
@Remote
public interface AdminSession {

    public void createUserType(java.lang.String type);

    public java.lang.Long getUserTypeId(java.lang.String type);

    public java.util.List<java.lang.String> getUserTypes();

    public void addHCOrganizationAddress(java.lang.Long orgId, java.lang.Long addressId);

    public void addHcOrgToDoctor(java.lang.Long hcOrgId, java.lang.Long doctorId);

    public void addPatientToHCProvider(java.lang.Long doctorId, java.lang.Long patientId);

    public persistence.AddressEntity createAddress(java.lang.String country, java.lang.String city, java.lang.String street, java.lang.String number);

    public persistence.HCOrganizationEntity addHCOrganization(java.lang.String name, java.lang.String details);

    public java.lang.Long addHCProfessional(java.lang.String name, java.lang.String specialization, java.lang.String email, java.lang.String phone, java.lang.String username, java.lang.String password, java.lang.Long userTypeId);

    public java.lang.Long findDoctorByName(java.lang.String name);

    public java.util.List<java.lang.String> getHCProviders();

    public java.lang.Long getPatientIdByName(java.lang.String name);

    public void addAddressToPatient(java.lang.Long patientId, java.lang.Long addressId);

    public java.lang.Long createPatient(java.lang.String name, java.lang.String cnp, java.lang.String healthInsurance,
            int age, java.lang.String bloodType, java.lang.String ethnicity, 
            java.lang.String email, java.lang.String username, java.lang.String password);

    public boolean checkUniqueDoctorUser(java.lang.String username);

    public boolean checkUniquePatientUser(java.lang.String username);

    public java.util.List<persistence.HCProfessionalEntity> getAllDoctors();

    public java.util.List<persistence.PatientEntity> getAllPatients();

    public java.lang.Long createAdminUser(java.lang.String password);

    public Long checkAdminLogin(java.lang.String password);
}
