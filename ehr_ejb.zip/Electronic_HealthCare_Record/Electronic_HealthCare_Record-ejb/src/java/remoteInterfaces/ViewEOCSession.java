/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package remoteInterfaces;

import javax.ejb.Remote;

/**
 *
 * @author Alina
 */
@Remote
public interface ViewEOCSession {

    public java.lang.Long getUserDoctorId(java.lang.Long userId);

    public java.util.List<persistence.ContactEntity> getEncountersOfPatient(java.lang.Long patientId);

  
    public java.lang.Long createACLforUser(java.lang.Long userEntityId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete);

    public void addACLtoEOC(java.lang.Long eocId, java.lang.Long aclId);

   
    public java.util.List<java.lang.Long> getEOCs_Of_Patient(java.lang.Long patientId);

    public java.lang.String findDoctorName(java.lang.Long doctorId);

    public java.lang.Long findUserPatientId(java.lang.Long userId);

    public java.util.List<java.lang.Long> getDoctorUsers();

    public java.lang.String getDoctorNameByEncounter(java.lang.Long encounterId);

    public java.util.List<java.lang.String> getPatientById(java.lang.Long id);

    public java.lang.Long loginPatient(java.lang.String username, java.lang.String password);

    public java.lang.Long userIdByDoctorName(java.lang.String doctorName);

    public java.lang.Long createACL(java.lang.Long userTypeId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete);

    public java.util.List<java.lang.String> getHCProfessionalDetailsByHCProfessionalName(java.lang.String hcProfessionalName);

    public java.lang.Long getCustomizedCarePlan(java.lang.Long encounterId);

    public void addACLtoCCP(java.lang.Long ccpId, java.lang.Long aclId);

    public java.util.List<java.lang.Long> getCCPofEOC(java.lang.Long eocId);

    public java.util.List<java.lang.Long> getDoctorsOfPatient(java.lang.Long patientId);

    public java.util.List<java.lang.Long> getPatientsOfDoctor(java.lang.Long doctorId);

   
}
