/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package remoteInterfaces;

import javax.ejb.Remote;

/**
 *
 * @author Alina
 */
@Remote
public interface DeleteEOCSession {

    public int deleteEOC(java.lang.Long eocId);

    public void deleteProcedure(java.lang.Long procedureId);

    public void deleteQualObs(java.lang.Long qualObsId);

    public void deleteQuanObs(java.lang.Long quanObsId);

    public void deleteMedicine(java.lang.Long medId);

    public void deletePharmacotherapy(java.lang.Long phId);

    public void deleteSymptom(java.lang.Long symptomid);

    public void deleteEncounter(java.lang.Long encounterId);

    public void deleteDoctor(java.lang.Long doctorId);

    public void deletePatient(java.lang.Long patientId);

    public void deleteACL(java.lang.Long aclId);

    public void deleteGeneralCarePlan(java.lang.Long gcpId);

    public void deleteCCP(java.lang.Long ccpId);

    public void removePatientFromDoctorList(java.lang.Long patientId, java.lang.Long doctorId);

    public void removeUserType(java.lang.String userTypeName);
    
}
