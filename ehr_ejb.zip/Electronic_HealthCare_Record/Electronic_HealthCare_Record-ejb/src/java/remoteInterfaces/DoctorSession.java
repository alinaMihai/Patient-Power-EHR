/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package remoteInterfaces;

import javax.ejb.Remote;

/**
 *
 * @author Alina
 */
@Remote
public interface DoctorSession {

    public java.lang.Long login(java.lang.String username, java.lang.String password);

    public java.util.List<Long> getPatients();

    public java.lang.Long addCustomizedCarePlan(java.lang.Long EOCId, java.lang.Long HCProviderId, java.lang.Long ContactId);

    public void addDisease(java.lang.Long eocId, java.lang.Long diseaseId);

    public Long addEncounter(java.lang.String code, java.lang.Long patientId, java.lang.Long doctorId, java.lang.Long orgId, java.lang.String consult_date, java.lang.String consult_time, java.lang.String consult_type);

    public java.lang.Long addGeneralCarePlan(java.lang.Long EOCid);

    public persistence.PlannedPharmacotherapyEntity addGeneralPharmacotherapy(java.lang.Long generalCarePlanId, java.lang.String name);

    public persistence.PlannedProcedureEntity addGeneralProcedure(java.lang.Long generalCarePlanId, java.lang.String code, java.lang.String name,String notes);

    public persistence.QualitativeObservationEntity addGeneralQualitativeObservation(java.lang.Long generalCarePlanId, java.lang.String code, java.lang.String name, java.lang.String notes, java.lang.String description);

    public persistence.QuantitativeObservationEntity addGeneralQuantitativeObservation(java.lang.Long generalCarePlanId, java.lang.String code, java.lang.String name, java.lang.String measurement, java.lang.String description);

    public java.lang.Long addMedicine(java.lang.Long PharmacotherapyId, java.lang.String name, java.lang.String code, java.lang.String priceUnit, double price, java.lang.String strength, java.lang.String dose, java.lang.String howTaken, java.lang.String resonForTaking, java.lang.String dateStarted, java.lang.String dateStopped);

    public void addSymptom(java.lang.Long diseaseId, java.lang.Long symptomId);

    public java.lang.Long createDisease(java.lang.String diagnostic);

    public java.lang.Long createEOC(java.lang.String startdate, java.lang.String starttime, java.lang.String enddate, java.lang.String endtime, java.lang.String code);

    public java.lang.Long createSymptom(java.lang.String name, java.lang.String description, java.lang.String frequency, java.lang.String status, java.lang.String apperance, java.lang.String disapperance);

    public java.util.List<java.lang.String> getDiagnostics();

    public java.util.List<persistence.PlannedHCitemEntity> getGeneralHCItemsOfDisease(java.lang.String diagnostic);

    public java.util.List<persistence.MedicineEntity> getMedicinesOfPharmacotherapy(java.lang.Long pharmacotherapyId);

    public java.util.List<java.lang.String> getPatientInfo(java.lang.Long patientId);

    public java.lang.Long getHCOrgIdOfDoctor(java.lang.Long doctorId);

    public persistence.AccessControlListEntity getByUserAndEOC(java.lang.Long userId, java.lang.Long eocId);

    public persistence.AccessControlListEntity getByUserTypeAndEOC(java.lang.Long userTypeId, java.lang.Long eocId);

    public java.lang.Long getUserTypeIdofUser(java.lang.Long userId);

    public java.util.List<java.lang.String> getEOCDetails(java.lang.Long eocId);

    public java.util.List<persistence.SymptomEntity> getGeneralSymptomsOfDisease(java.lang.String diagnostic);

    public java.util.List<java.lang.Long> getEncounterOfEOC(java.lang.Long eocId);

    public java.util.List<java.lang.String> getEncounterDetails(java.lang.Long encounterId);

    public java.lang.String getHCProfessionalNameOfCCP(java.lang.Long ccpId);

    public java.util.List<persistence.PlannedHCitemEntity> getHCItemsOfCustomizedCarePlan(java.lang.Long ccpId);

    public java.util.List<persistence.SymptomEntity> getSymptomsOfDisease(java.lang.Long diseaseId);

  
    public java.lang.String getHCProfessionalNamebyUserId(java.lang.Long userId);

    public java.lang.Long addPharmacotherapy(java.lang.Long customizedCarePlanId, java.lang.String name, java.lang.String state, java.lang.String date_op, java.lang.String time_op);

    public void addProcedure(java.lang.Long customizedCarePlanId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String date_op, java.lang.String time_op, java.lang.String notes);

    public void addQualitativeObservation(java.lang.Long customizedCarePlanId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String date_op, java.lang.String time_op, java.lang.String notes, java.lang.String description);

    public void addQuantitativeObservation(java.lang.Long customizedCarePlanId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String date_op, java.lang.String time_op, java.lang.String measurement, java.lang.String description);

    public java.util.List<java.lang.Long> getPatientsOfDoctor(java.lang.Long doctorId);

    public java.util.List<java.lang.Long> getGeneralCarePlans();

    public java.lang.String getDiagnosticOfGCP(java.lang.Long gcpId);

    public java.lang.Long getDiseaseIdOfDiagnostic(java.lang.String diagnostic);

    public java.util.List<java.lang.String> getCCPDetails(java.lang.Long ccpId);

    public persistence.AccessControlListEntity getByUserAndCCP(java.lang.Long userId, java.lang.Long ccpId);

    public persistence.AccessControlListEntity getByUserTypeAndCCP(java.lang.Long userTypeId, java.lang.Long ccpId);

    public java.util.List<java.lang.String> getPatientNames();

    
}
