/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package remoteInterfaces;

import javax.ejb.Remote;

/**
 *
 * @author Alina
 */
@Remote
public interface EditEOCSession {

    public void updateProcedure(java.lang.Long procedureId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String date_op, java.lang.String time_op, java.lang.String notes);

    public void updateQualitativeObservation(java.lang.Long qualObsId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String date_op, java.lang.String time_op, java.lang.String notes, java.lang.String description);

    public void updateQuantitativeObservation(java.lang.Long quanObsId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String date_op, java.lang.String time_op, java.lang.String measurement, java.lang.String description);

    public void updatePharmacotherapy(java.lang.Long phId, java.lang.String name, java.lang.String state, java.lang.String date_op, java.lang.String time_op);

    public void updateMedicine(java.lang.Long medId, java.lang.String name, java.lang.String code, java.lang.String priceUnit, double price, java.lang.String strength, java.lang.String dose, java.lang.String howTaken, java.lang.String resonForTaking, java.lang.String dateStarted, java.lang.String dateStopped);

    public void updateSymptom(java.lang.Long symptomId, java.lang.String name, java.lang.String description, java.lang.String frequency, java.lang.String status, java.lang.String apperance, java.lang.String disapperance);

    public void updateEOC(java.lang.Long eocId, java.lang.String startdate, java.lang.String starttime, java.lang.String enddate, java.lang.String endtime, java.lang.String code);

    public void editEncounter(java.lang.Long encounterId, java.lang.String code, java.lang.String consult_date, java.lang.String consult_time, java.lang.String consult_type);

    public boolean updateDoctorDetails(java.lang.Long userId, java.lang.Long doctorId, java.lang.String name, java.lang.String specialization, java.lang.String email, java.lang.String phone, java.lang.String username, java.lang.String password, java.lang.Long userTypeId);

    public void updateAddress(java.lang.Long addressId, java.lang.String country, java.lang.String city, java.lang.String street, java.lang.String number);

    public void updateHCOrganization(java.lang.Long hcOrgId, java.lang.String name, java.lang.String details);

    public boolean updatePatient(java.lang.Long userId, java.lang.Long patientId, java.lang.String name,
            java.lang.String cnp, java.lang.String healthInsurance, int age, java.lang.String bloodType,
            java.lang.String ethnicity, java.lang.String email, java.lang.String username, java.lang.String password);

    public java.lang.Long getUserIdOfDoctor(java.lang.Long doctorId);

    public java.lang.Long getHCOrgIdOfDoctor(java.lang.Long doctorId);

    public java.lang.Long getAddressIdOfHCOrg(java.lang.Long hcOrgId);

    public java.lang.Long getUserIdOfPatient(java.lang.Long patientId);

    public java.lang.Long getAddressOfPatient(java.lang.Long patientId);

    public void updateACL(java.lang.Long aclId, java.lang.Long userTypeId, java.lang.Long userEntityId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete);

    public java.util.List<java.lang.Long> getACLsOfEOC(java.lang.Long eocId);

    public java.util.List<java.lang.String> getACLDetails(java.lang.Long aclId);

    public void editAdminUser(java.lang.Long adminId, java.lang.String password);

    public java.util.List<java.lang.Long> getACLsOfCCP(java.lang.Long ccpId);

    
}
