/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Alina
 */
@Entity
public class HCProfessionalEntity extends HCProviderEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String specialization;
    private String phone;
    @ManyToOne(cascade = CascadeType.REMOVE,fetch= FetchType.EAGER)
    private HCOrganizationEntity hcOrganization;
    @OneToMany(mappedBy = "hcProfessional")
    private Collection<ContactEntity> encounters;
    @OneToMany(mappedBy = "hcProfessional", cascade = CascadeType.REMOVE)
    private Collection<CustomizedCarePlanEntity> customizedCarePlans;
    @OneToOne(fetch= FetchType.EAGER)
    private UserE user;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public HCOrganizationEntity getHcOrganization() {
        return hcOrganization;
    }

    public void setHcOrganization(HCOrganizationEntity hcOrganization) {
        this.hcOrganization = hcOrganization;
    }

    @XmlTransient
    public Collection<ContactEntity> getEncounters() {
        return encounters;
    }

    public void setEncounters(Collection<ContactEntity> encounters) {
        this.encounters = encounters;
    }

    @XmlTransient
    public Collection<CustomizedCarePlanEntity> getCustomizedCarePlans() {
        return customizedCarePlans;
    }

    public void setCustomizedCarePlans(Collection<CustomizedCarePlanEntity> customizedCarePlans) {
        this.customizedCarePlans = customizedCarePlans;
    }

    public UserE getUser() {
        return user;
    }

    public void setUser(UserE user) {
        this.user = user;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HCProfessionalEntity)) {
            return false;
        }
        HCProfessionalEntity other = (HCProfessionalEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistence.HCProfessionalEntity[ id=" + id + " ]";
    }
}
