/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Alina
 */
@Entity
public class PlannedHCitemEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String code;
    private String name;
    private String date_op;
    private String time_op;
    private String stateHCI;
    @ManyToOne
    GeneralCarePlanEntity generalCarePlan;
    @ManyToOne
    private CustomizedCarePlanEntity customizedCarePlan;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate_op() {
        return date_op;
    }

    public void setDate_op(String date_op) {
        this.date_op = date_op;
    }

    public String getTime_op() {
        return time_op;
    }

    public void setTime_op(String time_op) {
        this.time_op = time_op;
    }

    public String getStateHCI() {
        return stateHCI;
    }

    public void setStateHCI(String stateHCI) {
        this.stateHCI = stateHCI;
    }

    public GeneralCarePlanEntity getGeneralCarePlan() {
        return generalCarePlan;
    }

    public void setGeneralCarePlan(GeneralCarePlanEntity generalCarePlan) {
        this.generalCarePlan = generalCarePlan;
    }
@XmlTransient
    public CustomizedCarePlanEntity getCustomizedCarePlan() {
        return customizedCarePlan;
    }

    public void setCustomizedCarePlan(CustomizedCarePlanEntity customizedCarePlan) {
        this.customizedCarePlan = customizedCarePlan;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PlannedHCitemEntity)) {
            return false;
        }
        PlannedHCitemEntity other = (PlannedHCitemEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistence.PlannedHCitemEntity[ id=" + id + " ]";
    }
}
