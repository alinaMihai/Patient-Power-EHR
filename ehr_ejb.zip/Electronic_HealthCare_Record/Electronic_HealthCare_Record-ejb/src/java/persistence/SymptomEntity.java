/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author Alina
 */
@Entity
public class SymptomEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    @Column(length=10000)
    private String description;
    private String frequency;
    private String status;
    private String appearance_date;
    private String disappearance_date;
    @ManyToOne
    private DiseaseEntity2 disease;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAppearance_date() {
        return appearance_date;
    }

    public void setAppearance_date(String appearance_date) {
        this.appearance_date = appearance_date;
    }

    public String getDisappearance_date() {
        return disappearance_date;
    }

    public void setDisappearance_date(String disappearance_date) {
        this.disappearance_date = disappearance_date;
    }

    public DiseaseEntity2 getDisease() {
        return disease;
    }

    public void setDisease(DiseaseEntity2 disease) {
        this.disease = disease;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SymptomEntity)) {
            return false;
        }
        SymptomEntity other = (SymptomEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistence.SymptomEntity[ id=" + id + " ]";
    }
}
