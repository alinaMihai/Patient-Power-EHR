/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Alina
 */
@Entity
public class EpisodeOfCareEntity2 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String startDate;
    private String startTime;
    private String endDate;
    private String endTime;
    private String code;
    @ManyToOne(fetch = FetchType.EAGER)
    private DiseaseEntity2 disease;
    @OneToMany(mappedBy = "episodeOfCare", fetch = FetchType.EAGER, orphanRemoval = true)
    private Collection<CustomizedCarePlanEntity> carePlans;
    @OneToOne(mappedBy = "episodeOfCare", fetch = FetchType.EAGER, orphanRemoval = true)
    private GeneralCarePlanEntity generalCarePlan;
    @OneToMany(mappedBy = "episodeOfCare", fetch = FetchType.EAGER, orphanRemoval = true)
    private Collection<AccessControlListEntity> acls;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public DiseaseEntity2 getDisease() {
        return disease;
    }

    public void setDisease(DiseaseEntity2 disease) {
        this.disease = disease;
    }

    public String getCode() {
        return code;
    }

    @XmlTransient
    public GeneralCarePlanEntity getGeneralCarePlan() {
        return generalCarePlan;
    }

    public void setGeneralCarePlan(GeneralCarePlanEntity generalCarePlan) {
        this.generalCarePlan = generalCarePlan;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @XmlTransient
    public Collection<CustomizedCarePlanEntity> getCarePlans() {
        return carePlans;
    }

    public void setCarePlans(Collection<CustomizedCarePlanEntity> carePlans) {
        this.carePlans = carePlans;
    }

    @XmlTransient
    public Collection<AccessControlListEntity> getAcls() {
        return acls;
    }

    public void setAcls(Collection<AccessControlListEntity> acls) {
        this.acls = acls;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EpisodeOfCareEntity2)) {
            return false;
        }
        EpisodeOfCareEntity2 other = (EpisodeOfCareEntity2) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistence.EpisodeOfCareEntity[ id=" + id + " ]";
    }
}
