/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Alina
 */
@Entity
public class PatientEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String cnp;
    private String healthInsurance;
    private int age;
    private String bloodType;
    private String ethnicity;
    private String email;
    @ManyToMany
    @JoinTable(name = "PAT_DOC", joinColumns =
    @JoinColumn(name = "PATIENT_ID", referencedColumnName = "ID"), inverseJoinColumns =
    @JoinColumn(name = "HCP_ID", referencedColumnName = "ID"))
    private Collection<HCProviderEntity> hcproviders;
    @OneToMany(mappedBy = "patient_contact", fetch = FetchType.EAGER)
    private Collection<ContactEntity> encounters;
    @OneToOne(cascade = CascadeType.REMOVE, fetch = FetchType.EAGER)
    private AddressEntity address;
    @OneToOne(fetch = FetchType.EAGER)
    private UserE user;

    public PatientEntity() {
        this.hcproviders = new ArrayList<HCProviderEntity>();
        this.encounters = new ArrayList<ContactEntity>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PatientEntity)) {
            return false;
        }
        PatientEntity other = (PatientEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCnp() {
        return cnp;
    }

    public void setCnp(String cnp) {
        this.cnp = cnp;
    }

    public String getHealthInsurance() {
        return healthInsurance;
    }

    public void setHealthInsurance(String healthInsurance) {
        this.healthInsurance = healthInsurance;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public String getEthnicity() {
        return ethnicity;
    }

    public void setEthnicity(String ethnicity) {
        this.ethnicity = ethnicity;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Collection<HCProviderEntity> getHcproviders() {
        return hcproviders;
    }

    public void setHcproviders(Collection<HCProviderEntity> hcproviders) {
        this.hcproviders = hcproviders;
    }

    @XmlTransient
    public Collection<ContactEntity> getEncounters() {
        return encounters;
    }

    public void setEncounters(Collection<ContactEntity> encounters) {
        this.encounters = encounters;
    }

    public AddressEntity getAddress() {
        return address;
    }

    public void setAddress(AddressEntity address) {
        this.address = address;
    }

    public UserE getUser() {
        return user;
    }

    public void setUser(UserE user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "persistence.PatientEntity[ id=" + id + " ]";
    }
}
