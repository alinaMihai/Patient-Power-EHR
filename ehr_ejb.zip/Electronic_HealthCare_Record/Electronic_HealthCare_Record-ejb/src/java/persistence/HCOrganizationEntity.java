/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Alina
 */
@Entity
public class HCOrganizationEntity extends HCProviderEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @OneToOne(cascade = CascadeType.REMOVE)
    private AddressEntity address;
    private String details;
    @OneToMany(mappedBy = "hcOrganization")
    private Collection<HCProfessionalEntity> hcProfessionals;
    @OneToMany(mappedBy = "hcOrganization")
    private Collection<ContactEntity> encounters;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public AddressEntity getAddress() {
        return address;
    }

    public void setAddress(AddressEntity address) {
        this.address = address;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    @XmlTransient
    public Collection<HCProfessionalEntity> getHcProfessionals() {
        return hcProfessionals;
    }

    public void setHcProfessionals(Collection<HCProfessionalEntity> hcProfessionals) {
        this.hcProfessionals = hcProfessionals;
    }

    @XmlTransient
    public Collection<ContactEntity> getEncounters() {
        return encounters;
    }

    public void setEncounters(Collection<ContactEntity> encounters) {
        this.encounters = encounters;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HCOrganizationEntity)) {
            return false;
        }
        HCOrganizationEntity other = (HCOrganizationEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistence.HCOrganizationEntity[ id=" + id + " ]";
    }
}
