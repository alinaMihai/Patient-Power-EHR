/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Alina
 */
@Entity
public class AccessControlListEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private boolean canView;
    private boolean canInsert;
    private boolean canUpdate;
    private boolean canDelete;
    @ManyToOne
    private UserTypeEntity userType;
    @ManyToOne
    private EpisodeOfCareEntity2 episodeOfCare;
    @ManyToOne
    private CustomizedCarePlanEntity hcService;
    @ManyToOne
    private UserE user;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isCanView() {
        return canView;
    }

    public void setCanView(boolean canView) {
        this.canView = canView;
    }

    public boolean isCanInsert() {
        return canInsert;
    }

    public void setCanInsert(boolean canInsert) {
        this.canInsert = canInsert;
    }

    public boolean isCanUpdate() {
        return canUpdate;
    }

    public void setCanUpdate(boolean canUpdate) {
        this.canUpdate = canUpdate;
    }

    public boolean isCanDelete() {
        return canDelete;
    }

    public void setCanDelete(boolean canDelete) {
        this.canDelete = canDelete;
    }

    public UserTypeEntity getUserType() {
        return userType;
    }

    public void setUserType(UserTypeEntity userType) {
        this.userType = userType;
    }
@XmlTransient
    public EpisodeOfCareEntity2 getEpisodeOfCare() {
        return episodeOfCare;
    }

    public void setEpisodeOfCare(EpisodeOfCareEntity2 episodeOfCare) {
        this.episodeOfCare = episodeOfCare;
    }
@XmlTransient
    public CustomizedCarePlanEntity getHcService() {
        return hcService;
    }

    public void setHcService(CustomizedCarePlanEntity hcService) {
        this.hcService = hcService;
    }
@XmlTransient
    public UserE getUser() {
        return user;
    }

    public void setUser(UserE user) {
        this.user = user;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AccessControlListEntity)) {
            return false;
        }
        AccessControlListEntity other = (AccessControlListEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistence.AccessControlList[ id=" + id + " ]";
    }
}
