/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Alina
 */
@Entity
public class CustomizedCarePlanEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @OneToOne(mappedBy="customizedCarePlanEntity")
    private ContactEntity encounter;
    @OneToMany(mappedBy = "customizedCarePlan", fetch = FetchType.EAGER,orphanRemoval=true)
    private Collection<PlannedHCitemEntity> plannedHCitems;
    @ManyToOne
    private EpisodeOfCareEntity2 episodeOfCare;
    @ManyToOne
    private HCProfessionalEntity hcProfessional;
    @OneToMany(mappedBy = "hcService", fetch = FetchType.EAGER,orphanRemoval=true)
    private Collection<AccessControlListEntity> acls;

    public CustomizedCarePlanEntity() {
        plannedHCitems = new ArrayList<PlannedHCitemEntity>();
        acls = new ArrayList<AccessControlListEntity>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Collection<PlannedHCitemEntity> getPlannedHCitems() {
        return plannedHCitems;
    }

    @XmlTransient
    public Collection<AccessControlListEntity> getAcls() {
        return acls;
    }

    public void setAcls(Collection<AccessControlListEntity> acls) {
        this.acls = acls;
    }

    public void setPlannedHCitems(Collection<PlannedHCitemEntity> plannedHCitems) {
        this.plannedHCitems = plannedHCitems;
    }

    public EpisodeOfCareEntity2 getEpisodeOfCare() {
        return episodeOfCare;
    }

    public void setEpisodeOfCare(EpisodeOfCareEntity2 episodeOfCare) {
        this.episodeOfCare = episodeOfCare;
    }

    public HCProfessionalEntity getHcProfessional() {
        return hcProfessional;
    }

    public void setHcProfessional(HCProfessionalEntity hcProfessional) {
        this.hcProfessional = hcProfessional;
    }

    public ContactEntity getEncounter() {
        return encounter;
    }

    public void setEncounter(ContactEntity encounter) {
        this.encounter = encounter;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustomizedCarePlanEntity)) {
            return false;
        }
        CustomizedCarePlanEntity other = (CustomizedCarePlanEntity) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistence.CustomizedCarePlanEntity[ id=" + id + " ]";
    }
}
