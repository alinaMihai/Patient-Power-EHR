/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionBeans;

import java.util.List;
import java.util.logging.Logger;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import persistence.AccessControlListEntity;
import persistence.AddressEntity;
import persistence.ContactEntity;
import persistence.CustomizedCarePlanEntity;
import persistence.DiseaseEntity2;
import persistence.EpisodeOfCareEntity2;
import persistence.GeneralCarePlanEntity;
import persistence.HCOrganizationEntity;
import persistence.HCProfessionalEntity;
import persistence.HCProviderEntity;
import persistence.MedicineEntity;
import persistence.PatientEntity;
import persistence.PlannedPharmacotherapyEntity;
import persistence.PlannedProcedureEntity;
import persistence.QualitativeObservationEntity;
import persistence.QuantitativeObservationEntity;
import persistence.SymptomEntity;
import persistence.UserE;
import persistence.UserTypeEntity;
import remoteInterfaces.DeleteEOCSession;

/**
 *
 * @author Alina
 */
@Stateless
public class DeleteEOCSessionBean implements DeleteEOCSession {
    
    @PersistenceContext(unitName = "Electronic_HealthCare_Record-ejbPU")
    private EntityManager em;
    private static final Logger logger = Logger.getLogger("ehr.request.RequestBean");
    
    public void persist(Object object) {
        em.persist(object);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public int deleteEOC(Long eocId) {
        logger.info("deleteEOC");
        try {
            EpisodeOfCareEntity2 eoc = em.find(EpisodeOfCareEntity2.class, eocId);
            List<CustomizedCarePlanEntity> ccps = (List<CustomizedCarePlanEntity>) eoc.getCarePlans();
            for (CustomizedCarePlanEntity ccp : ccps) {
                ccp.getPlannedHCitems().removeAll(ccp.getPlannedHCitems());
                em.remove(ccp);
                if (ccp.getEncounter() != null) {
                    deleteEncounter(ccp.getEncounter().getId());
                }
            }
            eoc.getAcls().removeAll(eoc.getAcls());
            em.remove(eoc);
            
            return 1;
            
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteProcedure(Long procedureId) {
        logger.info("deleteProcedure");
        try {
            PlannedProcedureEntity procedure = em.find(PlannedProcedureEntity.class, procedureId);
            em.remove(procedure);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteQualObs(Long qualObsId) {
        logger.info("deleteQualObs");
        try {
            QualitativeObservationEntity qq = em.find(QualitativeObservationEntity.class, qualObsId);
            em.remove(qq);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteQuanObs(Long quanObsId) {
        logger.info("deleteQuanObs");
        try {
            QuantitativeObservationEntity qq = em.find(QuantitativeObservationEntity.class, quanObsId);
            em.remove(qq);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteMedicine(Long medId) {
        logger.info("deleteMedicine");
        try {
            MedicineEntity med = em.find(MedicineEntity.class, medId);
            em.remove(med);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deletePharmacotherapy(Long phId) {
        logger.info("deletePharmacotherapy");
        try {
            PlannedPharmacotherapyEntity pp = em.find(PlannedPharmacotherapyEntity.class, phId);
            List<MedicineEntity> meds = (List<MedicineEntity>) pp.getMedicines();
            for (MedicineEntity med : meds) {
                deleteMedicine(med.getId());
            }
            em.remove(pp);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteSymptom(Long symptomid) {
        logger.info("deleteSymptom");
        try {
            SymptomEntity symptom = em.find(SymptomEntity.class, symptomid);
            em.remove(symptom);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteEncounter(Long encounterId) {
        logger.info("deleteEncounter");
        try {
            ContactEntity encounter = em.find(ContactEntity.class, encounterId);
            em.remove(encounter);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteDoctor(Long doctorId) {
        logger.info("deleteDoctor");
        try {
            HCProfessionalEntity doctor = em.find(HCProfessionalEntity.class, doctorId);
            for (PatientEntity p : doctor.getPatients()) {
                p.getHcproviders().remove(doctor);
            }
            doctor.getPatients().removeAll(doctor.getPatients());
            
            List<ContactEntity> encounters = (List<ContactEntity>) doctor.getEncounters();
            for (ContactEntity e : encounters) {
                deleteEncounter(e.getId());
            }
            HCOrganizationEntity hcOrg = doctor.getHcOrganization();
            hcOrg.getHcProfessionals().remove(doctor);
            doctor.setHcOrganization(null);
            // deleteHCOrganization(doctor.getHcOrganization().getId());
            deleteUser(doctor.getUser().getId());
            em.remove(doctor);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    public void deleteHCOrganization(Long hcOrganizationId) {
        logger.info("deleteHCOrganization");
        try {
            HCOrganizationEntity hcOrg = em.find(HCOrganizationEntity.class, hcOrganizationId);
            deleteAddress(hcOrg.getAddress().getId());
            em.remove(hcOrg);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    public void deleteAddress(Long addressid) {
        logger.info("deleteAddress");
        try {
            AddressEntity a = em.find(AddressEntity.class, addressid);
            em.remove(a);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    public void deleteUser(Long userId) {
        logger.info("deleteUser");
        try {
            UserE user = em.find(UserE.class, userId);
            user.setUserType(null);
            List<AccessControlListEntity> acls = (List<AccessControlListEntity>) user.getAcls();
            for (AccessControlListEntity acl : acls) {
                deleteACL(acl.getId());
            }
            em.remove(user);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deletePatient(Long patientId) {
        logger.info("deletePatient");
        try {
            PatientEntity p = em.find(PatientEntity.class, patientId);
            List<ContactEntity> encounters = (List<ContactEntity>) p.getEncounters();
            for (ContactEntity e : encounters) {
                deleteEncounter(e.getId());
            }
            for (HCProviderEntity doctor : p.getHcproviders()) {
                doctor.getPatients().remove(p);
            }
            deleteAddress(p.getAddress().getId());
            deleteUser(p.getUser().getId());
            em.remove(p);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteACL(Long aclId) {
        logger.info("deleteACL");
        try {
            AccessControlListEntity acl = em.find(AccessControlListEntity.class, aclId);
            UserE u = acl.getUser();
            u.getAcls().remove(acl);
            UserTypeEntity ut = acl.getUserType();
            ut.getAcls().remove(acl);
            em.remove(acl);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteGeneralCarePlan(Long gcpId) {
        logger.info("deleteGeneralCarePlan");
        try {
            DiseaseEntity2 d;
            Query q = em.createQuery("SELECT eoc.disease FROM EpisodeOfCareEntity2 eoc WHERE eoc.generalCarePlan.id=:id");
            q.setParameter("id", gcpId);
            if (!q.getResultList().isEmpty()) {
                d = (DiseaseEntity2) q.getResultList().get(0);
                List<SymptomEntity> symptoms = (List<SymptomEntity>) d.getSymptoms();
                for (SymptomEntity s : symptoms) {
                    deleteSymptom(s.getId());
                }
                d.getEpisodesOfCare().removeAll(d.getEpisodesOfCare());
                d.setDiagnostic(null);
                em.remove(d);
            }
            GeneralCarePlanEntity gcp = em.find(GeneralCarePlanEntity.class, gcpId);
            em.remove(gcp.getEpisodeOfCare());
            
            gcp.getPlannedHCitems().removeAll(gcp.getPlannedHCitems());
            
            em.remove(gcp);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void deleteCCP(Long ccpId) {
        logger.info("deleteCCP");
        try {
            CustomizedCarePlanEntity ccp = em.find(CustomizedCarePlanEntity.class, ccpId);
            EpisodeOfCareEntity2 eoc = em.find(EpisodeOfCareEntity2.class, ccp.getEpisodeOfCare());
            eoc.getCarePlans().remove(ccp);
            ccp.getPlannedHCitems().removeAll(ccp.getPlannedHCitems());
            ContactEntity encounter = em.find(ContactEntity.class, ccp.getEncounter().getId());
            em.remove(ccp);
            em.remove(encounter);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void removePatientFromDoctorList(Long patientId, Long doctorId) {
        logger.info("removePatientFromDoctorList");
        try {
            HCProfessionalEntity hcprof = em.find(HCProfessionalEntity.class, doctorId);
            PatientEntity patient = em.find(PatientEntity.class, patientId);
            hcprof.getPatients().remove(patient);
            patient.getHcproviders().remove(hcprof);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void removeUserType(String userTypeName) {
        logger.info("removeUserType");
        try {
            Long userTypeId;
            Query q = em.createQuery("SELECT ut.id FROM UserTypeEntity ut WHERE ut.type=:type");
            q.setParameter("type", userTypeName);
            if (!q.getResultList().isEmpty()) {
                userTypeId = (Long) q.getResultList().get(0);
                UserTypeEntity userType = em.find(UserTypeEntity.class, userTypeId);
                List<UserE> users = (List<UserE>) userType.getUsers();
                for (UserE u : users) {
                    u.setUserType(null);
                }
                List<AccessControlListEntity> acls = (List<AccessControlListEntity>) userType.getAcls();
                for (AccessControlListEntity acl : acls) {
                    deleteACL(acl.getId());
                }
               // userType.getUsers().removeAll(userType.getUsers());
                //userType.getAcls().removeAll(userType.getAcls());  
                em.remove(userType);
            }
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
}
