/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionBeans;

import java.util.List;
import java.util.logging.Logger;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import persistence.AddressEntity;
import persistence.HCOrganizationEntity;
import persistence.HCProfessionalEntity;
import persistence.PatientEntity;
import persistence.UserE;
import persistence.UserTypeEntity;
import remoteInterfaces.AdminSession;

/**
 *
 * @author Alina
 */
@Stateless
public class AdminSessionBean implements AdminSession {

    @PersistenceContext(unitName = "Electronic_HealthCare_Record-ejbPU")
    private EntityManager em;
    private static final Logger logger = Logger.getLogger("ehr.request.RequestBean");

    public void persist(Object object) {
        em.persist(object);
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public void createUserType(String type) {
        logger.info("createUserType");
        try {
            UserTypeEntity userType = new UserTypeEntity();
            userType.setType(type);
            em.persist(userType);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long getUserTypeId(String type) {
        logger.info("getUserTypeId");
        try {
            Long userTypeId = null;
            Query query = em.createQuery("SELECT ut.id from UserTypeEntity ut WHERE ut.type=:type");
            query.setParameter("type", type);
            if (query.getResultList().size() > 0) {
                userTypeId = (Long) query.getResultList().get(0);
            }
            return userTypeId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<String> getUserTypes() {
        logger.info("getUserTypes");
        try {
            List<String> userTypes = null;
            Query query = em.createQuery("SELECT DISTINCT ut.type from UserTypeEntity ut");
            if (query.getResultList().size() > 0) {
                userTypes = (List<String>) query.getResultList();
            }
            return userTypes;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void addHCOrganizationAddress(Long orgId, Long addressId) {
        logger.info("addHCOrganizationAddress");
        try {
            HCOrganizationEntity org = em.find(HCOrganizationEntity.class, orgId);
            AddressEntity address = em.find(AddressEntity.class, addressId);
            org.setAddress(address);
        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    @Override
    public void addHcOrgToDoctor(Long hcOrgId, Long doctorId) {
        logger.info("addHcOrgToDoctor");
        try {
            HCProfessionalEntity doctor_aux = em.find(HCProfessionalEntity.class, doctorId);
            HCOrganizationEntity hcorg = em.find(HCOrganizationEntity.class, hcOrgId);
            hcorg.getHcProfessionals().add(doctor_aux);
            doctor_aux.setHcOrganization(hcorg);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void addPatientToHCProvider(Long doctorId, Long patientId) {
        logger.info("addPatientToHCProvider");
        try {
            HCProfessionalEntity hcprof = em.find(HCProfessionalEntity.class, doctorId);
            PatientEntity patient = em.find(PatientEntity.class, patientId);
            hcprof.getPatients().add(patient);
            patient.getHcproviders().add(hcprof);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public AddressEntity createAddress(String country, String city, String street, String number) {
        logger.info("createAddress");
        try {
            AddressEntity a = new AddressEntity();
            a.setCity(city);
            a.setCountry(country);
            a.setStreet(street);
            a.setNumber(number);
            em.persist(a);
            return a;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public HCOrganizationEntity addHCOrganization(String name, String details) {
        logger.info("addHCOrganization");
        try {
            HCOrganizationEntity org = new HCOrganizationEntity();
            org.setName(name);
            org.setDetails(details);
            em.persist(org);
            return org;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public boolean checkUniqueDoctorUser(String username) {
        logger.info("checkUniqueDoctorUser");
        try {
            Query q = em.createQuery("SELECT hcp.id FROM HCProfessionalEntity hcp WHERE hcp.user.username=:username");
            q.setParameter("username", username);
            if (!q.getResultList().isEmpty()) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long addHCProfessional(String name, String specialization, String email, String phone, String username, String password, Long userTypeId) {
        logger.info("addHCProfessional");
        try {
            HCProfessionalEntity doctor = new HCProfessionalEntity();
            doctor.setName(name);
            doctor.setSpecialization(specialization);
            doctor.setEmail(email);
            doctor.setPhone(phone);
            em.persist(doctor);
            if (checkUniqueDoctorUser(username)) {
                UserE user = new UserE();
                UserTypeEntity userType = em.find(UserTypeEntity.class, userTypeId);
                user.setUsername(username);
                user.setPassword(password);
                user.setUserType(userType);
                em.persist(user);
                doctor.setUser(user);
                return doctor.getId();
            } else {
                return null;
            }
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public boolean checkUniquePatientUser(String username) {
        logger.info("checkUniquePatientUser");
        try {
            Query q = em.createQuery("SELECT p.id FROM PatientEntity p WHERE p.user.username=:username");
            q.setParameter("username", username);
            if (!q.getResultList().isEmpty()) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long createPatient(String name, String cnp, String healthInsurance, int age, String bloodType, String ethnicity, String email, java.lang.String username, java.lang.String password) {
        logger.info("createPatient ");
        try {
            PatientEntity p = new PatientEntity();
            p.setName(name);
            p.setCnp(cnp);
            p.setHealthInsurance(healthInsurance);
            p.setAge(age);
            p.setBloodType(bloodType);
            p.setEthnicity(ethnicity);
            p.setEmail(email);
            em.persist(p);
            if (checkUniquePatientUser(username)) {
                UserE user = new UserE();
                user.setUsername(username);
                user.setPassword(password);
                em.persist(user);
                p.setUser(user);
                return p.getId();
            } else {
                return null;
            }
        } catch (Exception ex) {
            throw new EJBException(ex);
        }
    }

    @Override
    public Long findDoctorByName(String name) {
        Long hcpId = null;
        Query query = em.createQuery("SELECT hcprof.id from HCProviderEntity hcprof WHERE hcprof.name=:name");
        query.setParameter("name", name);
        if (query.getResultList().size() > 0) {
            hcpId = (Long) query.getResultList().get(0);
        }
        return hcpId;
    }

    @Override
    public List<String> getHCProviders() {
        logger.info("getHCProviders");
        try {
            List<String> doctors = null;
            Query query = em.createQuery("SELECT DISTINCT hcprof.name from HCProfessionalEntity hcprof");
            if (query.getResultList().size() > 0) {
                doctors = (List<String>) query.getResultList();
            }
            return doctors;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long getPatientIdByName(java.lang.String name) {
        logger.info("getPatientIdByName");
        try {
            Long patientId = null;
            Query q = em.createQuery("SELECT p.id FROM PatientEntity p WHERE p.name=:name");
            q.setParameter("name", name);
            if (!q.getResultList().isEmpty()) {
                patientId = (Long) q.getResultList().get(0);
            }
            return patientId;
        } catch (Exception e) {
            throw new EJBException(e);
        }

    }

    @Override
    public void addAddressToPatient(Long patientId, Long addressId) {
        logger.info("addAddressToPatient");
        try {
            PatientEntity patient = em.find(PatientEntity.class, patientId);
            AddressEntity address = em.find(AddressEntity.class, addressId);
            patient.setAddress(address);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<HCProfessionalEntity> getAllDoctors() {
        logger.info("getAllDoctors");
        try {
            List<HCProfessionalEntity> hcProfs = null;
            Query q = em.createQuery("SELECT hcp FROM HCProfessionalEntity hcp");
            if (!q.getResultList().isEmpty()) {
                hcProfs = (List<HCProfessionalEntity>) q.getResultList();
            }
            return hcProfs;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<PatientEntity> getAllPatients() {
        logger.info("getAllPatients");
        try {
            List<PatientEntity> patients = null;
            Query q = em.createQuery("SELECT p FROM PatientEntity p");
            if (!q.getResultList().isEmpty()) {
                patients = (List<PatientEntity>) q.getResultList();
            }
            return patients;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long createAdminUser(String password) {
        logger.info("createAdminUser");
        try {
            UserE userAdmin = new UserE();
            userAdmin.setUsername("Admin");
            userAdmin.setPassword(password);
            em.persist(userAdmin);
            return userAdmin.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long checkAdminLogin(String password) {
        logger.info("checkAdminLogin");
        try {
            Query q = em.createQuery("SELECT u.id FROm UserE u where u.username=:admin AND u.password=:pas");
            q.setParameter("pas", password);
            q.setParameter("admin", "Admin");
            if (!q.getResultList().isEmpty()) {
                Long adminId = (Long) q.getResultList().get(0);
                return adminId;
            }
            return null;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
}
