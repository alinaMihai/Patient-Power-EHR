/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionBeans;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import persistence.AccessControlListEntity;
import persistence.AddressEntity;
import persistence.ContactEntity;
import persistence.EpisodeOfCareEntity2;
import persistence.HCOrganizationEntity;
import persistence.HCProfessionalEntity;
import persistence.MedicineEntity;
import persistence.PatientEntity;
import persistence.PlannedPharmacotherapyEntity;
import persistence.PlannedProcedureEntity;
import persistence.QualitativeObservationEntity;
import persistence.QuantitativeObservationEntity;
import persistence.SymptomEntity;
import persistence.UserE;
import persistence.UserTypeEntity;
import remoteInterfaces.AdminSession;
import remoteInterfaces.EditEOCSession;

/**
 *
 * @author Alina
 */
@Stateless
public class EditEOCSessionBean implements EditEOCSession {

    @PersistenceContext(unitName = "Electronic_HealthCare_Record-ejbPU")
    private EntityManager em;
    private static final Logger logger = Logger.getLogger("ehr.request.RequestBean");
    @EJB
    private AdminSession ehr_ref_admin;

    public void persist(Object object) {
        em.persist(object);
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public void updateProcedure(Long procedureId, String code, String name, String state, String date_op, String time_op, String notes) {
        logger.info("updateProcedure");
        try {
            PlannedProcedureEntity procedure = em.find(PlannedProcedureEntity.class, procedureId);
            procedure.setCode(code);
            procedure.setName(name);
            procedure.setDate_op(date_op);
            procedure.setTime_op(time_op);
            procedure.setStateHCI(state);
            procedure.setNotes(notes);
            em.merge(procedure);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void updateQualitativeObservation(Long qualObsId, String code, String name, String state, String date_op, String time_op, String notes, String description) {
        logger.info("updateQualitativeObservation");
        try {
            QualitativeObservationEntity qq = em.find(QualitativeObservationEntity.class, qualObsId);
            qq.setCode(code);
            qq.setName(name);
            qq.setDate_op(date_op);
            qq.setTime_op(time_op);
            qq.setNotes(notes);
            qq.setDescription(description);
            qq.setStateHCI(state);
            em.merge(qq);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void updateQuantitativeObservation(Long quanObsId, String code, String name, String state, String date_op, String time_op, String measurement, String description) {
        logger.info("updateQuantitativeObservation");
        try {
            QuantitativeObservationEntity qq = em.find(QuantitativeObservationEntity.class, quanObsId);
            qq.setCode(code);
            qq.setName(name);
            qq.setDate_op(date_op);
            qq.setTime_op(time_op);
            qq.setMeasurementQ(measurement);
            qq.setDescription(description);
            qq.setStateHCI(state);
            em.merge(qq);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void updatePharmacotherapy(Long phId, String name, String state, String date_op, String time_op) {
        logger.info("updatePharmacotherapy");
        try {
            PlannedPharmacotherapyEntity pp = em.find(PlannedPharmacotherapyEntity.class, phId);
            pp.setName(name);
            pp.setDate_op(date_op);
            pp.setTime_op(time_op);
            pp.setStateHCI(state);
            em.merge(pp);
        } catch (Exception e) {
            throw new EJBException(e);

        }
    }

    @Override
    public void updateMedicine(Long medId, String name, String code, String priceUnit, double price, String strength,
            String dose, String howTaken, String resonForTaking, String dateStarted, String dateStopped) {
        logger.info("updateMedicine");
        try {
            MedicineEntity medicine = em.find(MedicineEntity.class, medId);
            medicine.setName(name);
            medicine.setCode(code);
            medicine.setPrice_unit(priceUnit);
            medicine.setPrice(price);
            medicine.setStrength(strength);
            medicine.setDose(dose);
            medicine.setHowTaken(howTaken);
            medicine.setReasonForTaking(resonForTaking);
            medicine.setDateStarted(dateStarted);
            medicine.setDateStopped(dateStopped);
            em.merge(medicine);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void updateSymptom(Long symptomId, String name, String description,
            String frequency, String status, String apperance, String disapperance) {
        logger.info("updateSymptom");
        try {
            SymptomEntity symptom = em.find(SymptomEntity.class, symptomId);
            symptom.setName(name);
            symptom.setDescription(description);
            symptom.setFrequency(frequency);
            symptom.setStatus(status);
            symptom.setAppearance_date(apperance);
            symptom.setDisappearance_date(disapperance);
            em.persist(symptom);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void updateEOC(Long eocId, String startdate, String starttime, String enddate, String endtime, String code) {
        logger.info("updateEOC");
        try {
            EpisodeOfCareEntity2 eoc = em.find(EpisodeOfCareEntity2.class, eocId);
            eoc.setStartDate(startdate);
            eoc.setStartTime(starttime);
            eoc.setEndDate(enddate);
            eoc.setEndTime(endtime);
            eoc.setCode(code);
            em.merge(eoc);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void editEncounter(Long encounterId, String code, String consult_date, String consult_time, String consult_type) {
        logger.info("editEncounter");
        try {
            ContactEntity encounter = em.find(ContactEntity.class, encounterId);
            encounter.setCode(code);
            encounter.setConsult_date(consult_date);
            encounter.setConsult_time(consult_time);
            encounter.setConsult_type(consult_type);
            em.merge(encounter);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public boolean updateDoctorDetails(Long userId, Long doctorId, String name, String specialization, String email, String phone, String username, String password, Long userTypeId) {
        logger.info("updateDoctorDetails");
        try {
            HCProfessionalEntity doctor = em.find(HCProfessionalEntity.class, doctorId);
            doctor.setName(name);
            doctor.setSpecialization(specialization);
            doctor.setEmail(email);
            doctor.setPhone(phone);
            UserE user = em.find(UserE.class, userId);
            UserTypeEntity userType = em.find(UserTypeEntity.class, userTypeId);
            if (!user.getUsername().equals(username)) {
                logger.info("updateDoctorDetails" + user.getUsername().equals(username));
                if (!ehr_ref_admin.checkUniqueDoctorUser(username)) {
                    return false;
                } else {
                    user.setUsername(username);
                    user.setPassword(password);
                    user.setUserType(userType);
                    em.merge(user);
                    em.merge(doctor);
                    return true;
                }
            } else {
                user.setPassword(password);
                user.setUserType(userType);
                em.merge(user);
                em.merge(doctor);
                return true;
            }


        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void updateAddress(Long addressId, String country, String city, String street, String number) {
        logger.info("updateAddress");
        try {
            AddressEntity a = em.find(AddressEntity.class, addressId);
            a.setCity(city);
            a.setCountry(country);
            a.setStreet(street);
            a.setNumber(number);
            em.merge(a);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void updateHCOrganization(Long hcOrgId, String name, String details) {
        logger.info("updateHCOrganization");
        try {

            HCOrganizationEntity org = em.find(HCOrganizationEntity.class, hcOrgId);
            org.setName(name);
            org.setDetails(details);
            em.merge(org);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public boolean updatePatient(Long userId, Long patientId, String name, String cnp, String healthInsurance, int age,
            String bloodType, String ethnicity, String email, java.lang.String username,
            java.lang.String password) {
        logger.info("updatePatient");
        try {
            PatientEntity p = em.find(PatientEntity.class, patientId);
            p.setName(name);
            p.setCnp(cnp);
            p.setHealthInsurance(healthInsurance);
            p.setAge(age);
            p.setBloodType(bloodType);
            p.setEthnicity(ethnicity);
            p.setEmail(email);
            UserE user = em.find(UserE.class, userId);
            if (!user.getUsername().equals(username)) {
                if (!ehr_ref_admin.checkUniquePatientUser(username)) {
                    return false;
                } else {
                    user.setUsername(username);
                    user.setPassword(password);
                    em.merge(user);
                    em.merge(p);
                    return true;
                }
            } else {
                user.setPassword(password);
                em.merge(user);
                em.merge(p);
                return true;
            }

        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long getUserIdOfDoctor(Long doctorId) {
        logger.info("getUserIdOfDoctor");
        try {
            Long userId = null;
            Query q = em.createQuery("SELECT hcp.user.id FROM HCProfessionalEntity hcp WHERE hcp.id=:id");
            q.setParameter("id", doctorId);
            if (!q.getResultList().isEmpty()) {
                userId = (Long) q.getResultList().get(0);
            }
            return userId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long getUserIdOfPatient(Long patientId) {
        logger.info("getUserIdOfPatient");
        try {
            Long userId = null;
            Query q = em.createQuery("SELECT p.user.id FROM PatientEntity p WHERE p.id=:id");
            q.setParameter("id", patientId);
            if (!q.getResultList().isEmpty()) {
                userId = (Long) q.getResultList().get(0);
            }
            return userId;
        } catch (Exception e) {
            throw new EJBException(e);
        }

    }

    @Override
    public Long getHCOrgIdOfDoctor(Long doctorId) {
        logger.info("getHCOrgIdOfDoctor");
        try {
            Long hcOrgId = null;
            Query q = em.createQuery("SELECT hcp.hcOrganization.id FROM HCProfessionalEntity hcp WHERE hcp.id=:id");
            q.setParameter("id", doctorId);
            if (!q.getResultList().isEmpty()) {
                hcOrgId = (Long) q.getResultList().get(0);
            }
            return hcOrgId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long getAddressIdOfHCOrg(Long hcOrgId) {
        logger.info("getAddressIdOfHCOrg");
        try {
            Long addressId = null;
            Query q = em.createQuery("SELECT hco.address.id FROM HCOrganizationEntity hco WHERE hco.id=:id");
            q.setParameter("id", hcOrgId);
            if (!q.getResultList().isEmpty()) {
                addressId = (Long) q.getResultList().get(0);
            }
            return addressId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long getAddressOfPatient(Long patientId) {
        logger.info("getAddressOfPatient");
        try {
            Long addressId = null;
            Query q = em.createQuery("SELECT p.address.id FROM PatientEntity p WHERE p.id=:id");
            q.setParameter("id", patientId);
            if (!q.getResultList().isEmpty()) {
                addressId = (Long) q.getResultList().get(0);
            }
            return addressId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void updateACL(Long aclId, Long userTypeId, Long userEntityId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete) {
        logger.info("updateACL");
        try {
            AccessControlListEntity acl = em.find(AccessControlListEntity.class, aclId);
            if (userTypeId != null) {
                UserTypeEntity userType = em.find(UserTypeEntity.class, userTypeId);
                acl.setUserType(userType);
            } else if (userEntityId != null) {
                UserE user = em.find(UserE.class, userEntityId);
                acl.setUser(user);
            }
            acl.setCanView(canView);
            acl.setCanInsert(canInsert);
            acl.setCanUpdate(canUpdate);
            acl.setCanDelete(canDelete);
            em.merge(acl);

        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<Long> getACLsOfEOC(Long eocId) {
        logger.info("getACLsOfEOC");
        try {
            List<Long> acls = null;
            Query q = em.createQuery("SELECT acl.id FROM EpisodeOfCareEntity2 eoc JOIN eoc.acls acl WHERE eoc.id=:id");
            q.setParameter("id", eocId);
            if (!q.getResultList().isEmpty()) {
                acls = (List<Long>) q.getResultList();
            }
            return acls;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    @Override
 public List<Long> getACLsOfCCP(Long ccpId) {
        logger.info("getACLsOfCCP");
        try {
            List<Long> acls = null;
            Query q = em.createQuery("SELECT acl.id FROM CustomizedCarePlanEntity ccp JOIN ccp.acls acl WHERE ccp.id=:id");
            q.setParameter("id", ccpId);
            if (!q.getResultList().isEmpty()) {
                acls = (List<Long>) q.getResultList();
            }
            return acls;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    @Override
    public List<String> getACLDetails(Long aclId) {
        logger.info("getACLDetails");
        try {
            List<String> aclDetails = new ArrayList<String>();
            Query q = em.createQuery("SELECT acl FROM AccessControlListEntity acl WHERE acl.id=:id");
            q.setParameter("id", aclId);
            if (!q.getResultList().isEmpty()) {
                AccessControlListEntity acl = (AccessControlListEntity) q.getResultList().get(0);
                if (acl.getUser() != null) {
                    Query qu = em.createQuery("SELECT hcp.name FROM HCProfessionalEntity hcp WHERE hcp.user.id=:id");
                    qu.setParameter("id", acl.getUser().getId());
                    if (!qu.getResultList().isEmpty()) {
                        String doctorName = (String) qu.getResultList().get(0);
                        aclDetails.add(doctorName);
                    }

                } else {
                    aclDetails.add("null");
                }
                if (acl.getUserType() != null) {
                    aclDetails.add(acl.getUserType().getType() + "");
                } else {

                    aclDetails.add("null");
                }
                aclDetails.add(acl.isCanView() + "");
                aclDetails.add(acl.isCanInsert() + "");
                aclDetails.add(acl.isCanDelete() + "");
                aclDetails.add(acl.isCanUpdate() + "");

            }
            return aclDetails;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void editAdminUser(Long adminId, String password) {
        logger.info("editAdminUser");
        try {
            UserE user = em.find(UserE.class, adminId);
            user.setPassword(password);
            em.merge(user);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
}
