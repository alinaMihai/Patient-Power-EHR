/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionBeans;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import persistence.AccessControlListEntity;
import persistence.AddressEntity;
import persistence.ContactEntity;
import persistence.CustomizedCarePlanEntity;
import persistence.DiseaseEntity2;
import persistence.EpisodeOfCareEntity2;
import persistence.GeneralCarePlanEntity;
import persistence.HCOrganizationEntity;
import persistence.HCProfessionalEntity;
import persistence.MedicineEntity;
import persistence.PatientEntity;
import persistence.PlannedHCitemEntity;
import persistence.PlannedPharmacotherapyEntity;
import persistence.PlannedProcedureEntity;
import persistence.QualitativeObservationEntity;
import persistence.QuantitativeObservationEntity;
import persistence.SymptomEntity;
import remoteInterfaces.DoctorSession;

/**
 *
 * @author Alina
 */
@Stateless
public class DoctorSessionBean implements DoctorSession {
    
    @PersistenceContext(unitName = "Electronic_HealthCare_Record-ejbPU")
    private EntityManager em;
    
    public void persist(Object object) {
        em.persist(object);
    }
    private static final Logger logger = Logger.getLogger("ehr.request.RequestBean");
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public Long login(String username, String password) {
        logger.info("login");
        try {
            Long doctorUserId = null;
            Query q = em.createQuery("SELECT hcp.user.id FROM HCProfessionalEntity hcp WHERE hcp.user.username=:username AND hcp.user.password=:password");
            q.setParameter("username", username);
            q.setParameter("password", password);
            if (!q.getResultList().isEmpty()) {
                doctorUserId = (Long) q.getResultList().get(0);
            }
            return doctorUserId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<Long> getPatients() {
        logger.info("getPatients");
        try {
            List<Long> patients = null;
            Query q = em.createQuery("SELECT DISTINCT p.id FROM PatientEntity p ");
            if (!q.getResultList().isEmpty()) {
                patients = (List<Long>) q.getResultList();
            }
            return patients;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
   public List<String> getPatientNames() {
        logger.info("getPatientNames");
        try {
            List<String> names = null;
            Query q = em.createQuery("Select pat.name FROM PatientEntity pat");
           // q.setParameter("id", id);
            if (!q.getResultList().isEmpty()) {
                names = (List<String>) q.getResultList();
            }
            return names;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<String> getPatientInfo(Long patientId) {
        logger.info(" getPatientInfo");
        try {
            List<String> patientInfo = null;
            Query q = em.createQuery("SELECT p FROM PatientEntity p WHERE p.id=:id");
            q.setParameter("id", patientId);
            if (!q.getResultList().isEmpty()) {
                patientInfo = new ArrayList<String>();
                PatientEntity patient = (PatientEntity) q.getResultList().get(0);
                patientInfo.add(patient.getName());
                patientInfo.add(patient.getCnp());
                patientInfo.add(patient.getHealthInsurance());
                patientInfo.add(patient.getAge() + "");
                patientInfo.add(patient.getBloodType());
                patientInfo.add(patient.getEthnicity());
                patientInfo.add(patient.getEmail());
                patientInfo.add(patient.getId() + "");
                AddressEntity address = patient.getAddress();
                
                if (address != null) {
                    patientInfo.add(address.getCity());
                    patientInfo.add(address.getCountry());
                    patientInfo.add(address.getStreet());
                    patientInfo.add(address.getNumber());
                    
                }
            }
            return patientInfo;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long getHCOrgIdOfDoctor(Long doctorId) {
        logger.info("getHCOrgIdOfDoctor");
        try {
            Long hcOrgId = null;
            Query q = em.createQuery("SELECT hcp.hcOrganization.id FROM HCProfessionalEntity hcp WHERE hcp.id=:doctorId");
            q.setParameter("doctorId", doctorId);
            if (!q.getResultList().isEmpty()) {
                hcOrgId = (Long) q.getResultList().get(0);
            }
            return hcOrgId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long addCustomizedCarePlan(Long EOCId, Long HCProviderId, Long ContactId) {
        logger.info("addCustomizedCarePlan");
        try {
            EpisodeOfCareEntity2 eoc = em.find(EpisodeOfCareEntity2.class, EOCId);
            HCProfessionalEntity hcp;
            hcp = em.find(HCProfessionalEntity.class, HCProviderId);
            ContactEntity encounter;
            encounter = em.find(ContactEntity.class, ContactId);
            CustomizedCarePlanEntity ccp = new CustomizedCarePlanEntity();
            ccp.setEpisodeOfCare(eoc);
            ccp.setHcProfessional(hcp);
            ccp.setEncounter(encounter);
            em.persist(ccp);
            hcp.getCustomizedCarePlans().add(ccp);
            encounter.setCustomizedCarePlanEntity(ccp);
            return ccp.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void addDisease(Long eocId, Long diseaseId) {
        logger.info("addDisease");
        try {
            EpisodeOfCareEntity2 eoc = em.find(EpisodeOfCareEntity2.class, eocId);
            DiseaseEntity2 disease = em.find(DiseaseEntity2.class, diseaseId);
            eoc.setDisease(disease);
            disease.getEpisodesOfCare().add(eoc);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long addEncounter(String code, Long patientId, Long doctorId, Long orgId, String consult_date, String consult_time, String consult_type) {
        logger.info("addEncounter");
        try {
            ContactEntity encounter = new ContactEntity();
            PatientEntity patient = em.find(PatientEntity.class, patientId);
            HCProfessionalEntity doctor = em.find(HCProfessionalEntity.class, doctorId);
            HCOrganizationEntity org = em.find(HCOrganizationEntity.class, orgId);
            encounter.setCode(code);
            encounter.setConsult_date(consult_date);
            encounter.setConsult_time(consult_time);
            encounter.setConsult_type(consult_type);
            encounter.setHcProfessional(doctor);
            encounter.setHcOrganization(org);
            encounter.setPatient_contact(patient);
            em.persist(encounter);
            
            patient.getEncounters().add(encounter);
            return encounter.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long addGeneralCarePlan(Long EOCid) {
        logger.info("addGeneralCarePlan");
        try {
            EpisodeOfCareEntity2 eoc = em.find(EpisodeOfCareEntity2.class, EOCid);
            GeneralCarePlanEntity gcp = new GeneralCarePlanEntity();
            gcp.setEpisodeOfCare(eoc);
            em.persist(gcp);
            eoc.setGeneralCarePlan(gcp);
            return gcp.getId();
            
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public PlannedPharmacotherapyEntity addGeneralPharmacotherapy(Long generalCarePlanId, String name) {
        logger.info("addGeneralPharmacotherapy");
        try {
            GeneralCarePlanEntity gcp = em.find(GeneralCarePlanEntity.class, generalCarePlanId);
            PlannedPharmacotherapyEntity pp = new PlannedPharmacotherapyEntity();
            pp.setName(name);
            pp.setGeneralCarePlan(gcp);
            em.persist(pp);
            gcp.getPlannedHCitems().add(pp);
            return pp;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public PlannedProcedureEntity addGeneralProcedure(Long generalCarePlanId, String code, String name, String notes) {
        logger.info("addGeneralProcedure");
        try {
            GeneralCarePlanEntity gcp = em.find(GeneralCarePlanEntity.class, generalCarePlanId);
            PlannedProcedureEntity procedure = new PlannedProcedureEntity();
            procedure.setCode(code);
            procedure.setName(name);
            procedure.setNotes(notes);
            procedure.setGeneralCarePlan(gcp);
            em.persist(procedure);
            gcp.getPlannedHCitems().add(procedure);
            return procedure;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public QualitativeObservationEntity addGeneralQualitativeObservation(Long generalCarePlanId, String code, String name, String notes, String description) {
        logger.info("addGeneralQualitativeObservation");
        try {
            GeneralCarePlanEntity gcp = em.find(GeneralCarePlanEntity.class, generalCarePlanId);
            QualitativeObservationEntity qo = new QualitativeObservationEntity();
            qo.setCode(code);
            qo.setName(name);
            qo.setDescription(description);
            qo.setNotes(notes);
            qo.setGeneralCarePlan(gcp);
            em.persist(qo);
            gcp.getPlannedHCitems().add(qo);
            return qo;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public QuantitativeObservationEntity addGeneralQuantitativeObservation(Long generalCarePlanId, String code, String name, String measurement, String description) {
        logger.info("addGeneralQuantitativeObservation");
        try {
            GeneralCarePlanEntity gcp = em.find(GeneralCarePlanEntity.class, generalCarePlanId);
            QuantitativeObservationEntity qo = new QuantitativeObservationEntity();
            qo.setCode(code);
            qo.setName(name);
            qo.setMeasurementQ(measurement);
            qo.setDescription(description);
            qo.setGeneralCarePlan(gcp);
            em.persist(qo);
            
            gcp.getPlannedHCitems().add(qo);
            return qo;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long addMedicine(Long PharmacotherapyId, String name, String code, String priceUnit, double price, String strength, String dose, String howTaken, String resonForTaking, String dateStarted, String dateStopped) {
        logger.info("addMedicine");
        try {
            PlannedPharmacotherapyEntity pp = em.find(PlannedPharmacotherapyEntity.class, PharmacotherapyId);
            MedicineEntity medicine = new MedicineEntity();
            medicine.setName(name);
            medicine.setCode(code);
            medicine.setPrice_unit(priceUnit);
            medicine.setPrice(price);
            medicine.setStrength(strength);
            medicine.setDose(dose);
            medicine.setHowTaken(howTaken);
            medicine.setReasonForTaking(resonForTaking);
            medicine.setDateStarted(dateStarted);
            medicine.setDateStopped(dateStopped);
            medicine.setPlannedPharmacotherapy(pp);
            em.persist(medicine);
            
            pp.getMedicines().add(medicine);
            return medicine.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long addPharmacotherapy(Long customizedCarePlanId, String name, String state, String date_op, String time_op) {
        logger.info("addPharmacotherapy");
        try {
            CustomizedCarePlanEntity ccp = em.find(CustomizedCarePlanEntity.class, customizedCarePlanId);
            PlannedPharmacotherapyEntity pp = new PlannedPharmacotherapyEntity();
            pp.setName(name);
            pp.setDate_op(date_op);
            pp.setTime_op(time_op);
            pp.setStateHCI(state);
            pp.setCustomizedCarePlan(ccp);
            em.persist(pp);
            
            ccp.getPlannedHCitems().add(pp);
            return pp.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void addProcedure(Long customizedCarePlanId, String code, String name, String state, String date_op, String time_op, String notes) {
        logger.info("addProcedure");
        try {
            CustomizedCarePlanEntity ccp = em.find(CustomizedCarePlanEntity.class, customizedCarePlanId);
            PlannedProcedureEntity procedure = new PlannedProcedureEntity();
            procedure.setCode(code);
            procedure.setName(name);
            procedure.setDate_op(date_op);
            procedure.setTime_op(time_op);
            procedure.setStateHCI(state);
            procedure.setNotes(notes);
            procedure.setCustomizedCarePlan(ccp);
            em.persist(procedure);
            ccp.getPlannedHCitems().add(procedure);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void addQualitativeObservation(Long customizedCarePlanId, String code, String name, String state, String date_op, String time_op, String notes, String description) {
        logger.info("addQualitativeObservation");
        try {
            CustomizedCarePlanEntity ccp = em.find(CustomizedCarePlanEntity.class, customizedCarePlanId);
            QualitativeObservationEntity qq = new QualitativeObservationEntity();
            qq.setCode(code);
            qq.setName(name);
            qq.setDate_op(date_op);
            qq.setTime_op(time_op);
            qq.setNotes(notes);
            qq.setDescription(description);
            qq.setStateHCI(state);
            qq.setCustomizedCarePlan(ccp);
            em.persist(qq);
            
            ccp.getPlannedHCitems().add(qq);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void addQuantitativeObservation(Long customizedCarePlanId, String code, String name, String state, String date_op, String time_op, String measurement, String description) {
        logger.info("addQuantitativeObservation");
        try {
            CustomizedCarePlanEntity ccp = em.find(CustomizedCarePlanEntity.class, customizedCarePlanId);
            QuantitativeObservationEntity qq = new QuantitativeObservationEntity();
            qq.setCode(code);
            qq.setName(name);
            qq.setDate_op(date_op);
            qq.setTime_op(time_op);
            qq.setMeasurementQ(measurement);
            qq.setDescription(description);
            qq.setStateHCI(state);
            qq.setCustomizedCarePlan(ccp);
            em.persist(qq);
            
            ccp.getPlannedHCitems().add(qq);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public void addSymptom(Long diseaseId, Long symptomId) {
        logger.info("addSymptom");
        try {
            DiseaseEntity2 disease = em.find(DiseaseEntity2.class, diseaseId);
            SymptomEntity symptom = em.find(SymptomEntity.class, symptomId);
            disease.getSymptoms().add(symptom);
            symptom.setDisease(disease);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long createDisease(String diagnostic) {
        logger.info("createDisease");
        try {
            DiseaseEntity2 disease = new DiseaseEntity2();
            disease.setDiagnostic(diagnostic);
            em.persist(disease);
            return disease.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long createEOC(String startdate, String starttime, String enddate, String endtime, String code) {
        logger.info("createEOC");
        try {
            EpisodeOfCareEntity2 eoc = new EpisodeOfCareEntity2();
            eoc.setStartDate(startdate);
            eoc.setStartTime(starttime);
            eoc.setEndDate(enddate);
            eoc.setEndTime(endtime);
            eoc.setCode(code);
            em.persist(eoc);
            return eoc.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long createSymptom(String name, String description, String frequency, String status, String apperance, String disapperance) {
        logger.info("createSymptom");
        try {
            SymptomEntity symptom = new SymptomEntity();
            symptom.setName(name);
            symptom.setDescription(description);
            symptom.setFrequency(frequency);
            symptom.setStatus(status);
            symptom.setAppearance_date(apperance);
            symptom.setDisappearance_date(disapperance);
            em.persist(symptom);
            return symptom.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<String> getDiagnostics() {
        logger.info("getDiagnostics");
        try {
            List<String> diagnostics = null;
            Query query = em.createQuery("SELECT DISTINCT d.diagnostic from DiseaseEntity2 d");
            if (query.getResultList().size() > 0) {
                diagnostics = (List<String>) query.getResultList();
            }
            return diagnostics;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    public Long getDiseaseId(String diagnostic) {
        logger.info("getDiseaseId");
        try {
            Query query = em.createQuery("SELECT d.id from DiseaseEntity2 d WHERE d.diagnostic=:diagnostic");
            query.setParameter("diagnostic", diagnostic);
            Long diseaseId = null;
            
            if (query.getResultList().size() > 0) {
                diseaseId = (Long) query.getResultList().get(0);
            }
            return diseaseId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<PlannedHCitemEntity> getGeneralHCItemsOfDisease(String diagnostic) {
        logger.info("getGeneralHCItemsOfDisease");
        try {
            List<PlannedHCitemEntity> hcItems = null;
            Query q = em.createQuery("SELECT DISTINCT hci FROM GeneralCarePlanEntity gcp JOIN gcp.plannedHCitems hci WHERE gcp.episodeOfCare.disease.diagnostic=:diagnostic");
            q.setParameter("diagnostic", diagnostic);
            if (!q.getResultList().isEmpty()) {
                hcItems = (List<PlannedHCitemEntity>) q.getResultList();
            }
            return hcItems;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<MedicineEntity> getMedicinesOfPharmacotherapy(Long pharmacotherapyId) {
        logger.info("getMedicinesOfPharmacotherapy");
        try {
            List<MedicineEntity> medicines = null;
            Query q = em.createQuery("SELECT DISTINCT m FROM PlannedPharmacotherapyEntity pp JOIN pp.medicines m WHERE pp.id=:phId");
            q.setParameter("phId", pharmacotherapyId);
            if (!q.getResultList().isEmpty()) {
                medicines = (List<MedicineEntity>) q.getResultList();
            }
            return medicines;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<SymptomEntity> getGeneralSymptomsOfDisease(String diagnostic) {
        logger.info("getGeneralSymptomsOfDisease");
        try {
            Long diseaseId = getDiseaseId(diagnostic);
            List<SymptomEntity> symptoms = null;
            Query q = em.createQuery("SELECT DISTINCT s FROM DiseaseEntity2 d JOIN d.symptoms s WHERE d.id=:id");
            q.setParameter("id", diseaseId);
            if (!q.getResultList().isEmpty()) {
                symptoms = (List<SymptomEntity>) q.getResultList();
            }
            return symptoms;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public AccessControlListEntity getByUserAndEOC(Long userId, Long eocId) {
        logger.info("getByUserAndEOC");
        try {
            AccessControlListEntity acl = null;
            Query q = em.createQuery("SELECT acl FROM AccessControlListEntity acl WHERE acl.user.id=:userId AND acl.episodeOfCare.id=:eocId");
            q.setParameter("userId", userId);
            q.setParameter("eocId", eocId);
            if (!q.getResultList().isEmpty()) {
                acl = (AccessControlListEntity) q.getResultList().get(0);
            }
            return acl;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public AccessControlListEntity getByUserAndCCP(Long userId, Long ccpId) {
        logger.info("getByUserAndCCP");
        try {
            AccessControlListEntity acl = null;
            Query q = em.createQuery("SELECT acl FROM AccessControlListEntity acl WHERE acl.user.id=:userId AND acl.hcService.id=:Id");
            q.setParameter("userId", userId);
            q.setParameter("Id", ccpId);
            if (!q.getResultList().isEmpty()) {
                acl = (AccessControlListEntity) q.getResultList().get(0);
            }
            return acl;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public AccessControlListEntity getByUserTypeAndEOC(Long userTypeId, Long eocId) {
        logger.info("getByUserTypeAndEOC");
        try {
            AccessControlListEntity acl = null;
            Query q = em.createQuery("SELECT acl FROM AccessControlListEntity acl WHERE acl.userType.id=:userTypeId AND acl.episodeOfCare.id=:eocId");
            q.setParameter("userTypeId", userTypeId);
            q.setParameter("eocId", eocId);
            if (!q.getResultList().isEmpty()) {
                acl = (AccessControlListEntity) q.getResultList().get(0);
            }
            return acl;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public AccessControlListEntity getByUserTypeAndCCP(Long userTypeId, Long ccpId) {
        logger.info("getByUserTypeAndCCP");
        try {
            AccessControlListEntity acl = null;
            Query q = em.createQuery("SELECT acl FROM AccessControlListEntity acl WHERE acl.userType.id=:userTypeId AND acl.hcService=:Id");
            q.setParameter("userTypeId", userTypeId);
            q.setParameter("Id", ccpId);
            if (!q.getResultList().isEmpty()) {
                acl = (AccessControlListEntity) q.getResultList().get(0);
            }
            return acl;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long getUserTypeIdofUser(Long userId) {
        logger.info("getUserTypeIdofUser");
        try {
            Long userTypeId = null;
            Query q = em.createQuery("SELECT u.userType.id FROM UserE u WHERE u.id=:userId");
            q.setParameter("userId", userId);
            if (!q.getResultList().isEmpty()) {
                userTypeId = (Long) q.getResultList().get(0);
            }
            return userTypeId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<String> getEOCDetails(Long eocId) {
        logger.info("getEOCDetails");
        try {
            EpisodeOfCareEntity2 eoc = em.find(EpisodeOfCareEntity2.class, eocId);
            String diagnostic = null;
            Long diseaseId = null;
            DiseaseEntity2 disease;
            Query q = em.createQuery("SELECT eoc.disease FROM EpisodeOfCareEntity2 eoc WHERE eoc.id=:id");
            q.setParameter("id", eocId);
            if (!q.getResultList().isEmpty()) {
                disease = (DiseaseEntity2) q.getResultList().get(0);
                diagnostic = disease.getDiagnostic();
                diseaseId = disease.getId();
            }
            List<String> eocDetails = new ArrayList<String>();
            eocDetails.add(eoc.getId() + "");
            eocDetails.add(eoc.getCode());
            eocDetails.add(eoc.getStartDate());
            eocDetails.add(eoc.getStartTime());
            eocDetails.add(eoc.getEndDate());
            eocDetails.add(eoc.getEndTime());
            eocDetails.add(diagnostic);
            eocDetails.add(diseaseId + "");
            return eocDetails;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<String> getCCPDetails(Long ccpId) {
        logger.info("getCCPDetails");
        try {
            String encounterName;
            String encounterDate;
            ContactEntity encounter;
            List<String> ccpDetails = new ArrayList<String>();
            Query q = em.createQuery("SELECT ccp.encounter FROM CustomizedCarePlanEntity ccp  WHERE ccp.id=:id");
            q.setParameter("id", ccpId);
            if (!q.getResultList().isEmpty()) {
                encounter = (ContactEntity) q.getResultList().get(0);
                encounterDate = encounter.getConsult_date();
                encounterName = encounter.getConsult_type();
                ccpDetails.add(encounterName);
                ccpDetails.add(encounterDate);
                ccpDetails.add(encounter.getConsult_time());
                ccpDetails.add(encounter.getCode());  
                ccpDetails.add(encounter.getId()+"");
            }
                    
            return ccpDetails;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<Long> getEncounterOfEOC(Long eocId) {
        logger.info("getEncounterOfEOC");
        try {
            List<Long> encounterIds = null;
            Query q = em.createQuery("SELECT DISTINCT e.id FROM EpisodeOfCareEntity2 eoc JOIN eoc.carePlans ccp JOIN ccp.encounter e WHERE eoc.id=:id");
            q.setParameter("id", eocId);
            if (!q.getResultList().isEmpty()) {
                encounterIds = (List<Long>) q.getResultList();
            }
            return encounterIds;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<String> getEncounterDetails(Long encounterId) {
        logger.info("getEncounterDetailsOfEOC");
        try {
            List<String> encounterDetails = new ArrayList<String>();
            ContactEntity encounter = null;
            Query q = em.createQuery("SELECT e FROM ContactEntity e WHERE e.id=:eId");
            q.setParameter("eId", encounterId);
            if (!q.getResultList().isEmpty()) {
                encounter = (ContactEntity) q.getResultList().get(0);
            }
            encounterDetails.add(encounter.getId() + "");
            encounterDetails.add(encounter.getCode());
            encounterDetails.add(encounter.getConsult_date());
            encounterDetails.add(encounter.getConsult_time());
            encounterDetails.add(encounter.getConsult_type());
            return encounterDetails;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public String getHCProfessionalNameOfCCP(Long ccpId) {
        logger.info("getHCProfessionalNameOfCCP");
        try {
            String hcProfessionalName;
            CustomizedCarePlanEntity ccp = null;
            Query q = em.createQuery("SELECT ccp FROM CustomizedCarePlanEntity ccp JOIN FETCH ccp.plannedHCitems WHERE ccp.id=:id");
            q.setParameter("id", ccpId);
            if (!q.getResultList().isEmpty()) {
                ccp = (CustomizedCarePlanEntity) q.getResultList().get(0);
            }
            hcProfessionalName = ccp.getHcProfessional().getName();
            int size = ccp.getPlannedHCitems().size();
            
            return hcProfessionalName;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<PlannedHCitemEntity> getHCItemsOfCustomizedCarePlan(Long ccpId) {
        logger.info("getHCItemsOfCustomizedCarePlan");
        try {
            List<PlannedHCitemEntity> hcItems = null;
            Query q = em.createQuery("Select DISTINCT hci FROM CustomizedCarePlanEntity ccp Join ccp.plannedHCitems hci WHERE ccp.id=:id");
            q.setParameter("id", ccpId);
            if (!q.getResultList().isEmpty()) {
                hcItems = (List<PlannedHCitemEntity>) q.getResultList();
            }
            return hcItems;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<SymptomEntity> getSymptomsOfDisease(Long diseaseId) {
        logger.info("getSymptomsOfDisease");
        try {
            List<SymptomEntity> symptoms = null;
            Query q = em.createQuery("SELECT DISTINCT s FROM DiseaseEntity2 d JOIN d.symptoms s WHERE d.id=:id");
            q.setParameter("id", diseaseId);
            if (!q.getResultList().isEmpty()) {
                symptoms = (List<SymptomEntity>) q.getResultList();
            }
            return symptoms;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public String getHCProfessionalNamebyUserId(Long userId) {
        logger.info("getHCProfessionalNamebyUserId");
        try {
            String name = null;
            Query q = em.createQuery("SELECT hcp.name FROM HCProfessionalEntity hcp WHERE hcp.user.id=:id");
            q.setParameter("id", userId);
            if (!q.getResultList().isEmpty()) {
                name = (String) q.getResultList().get(0);
            }
            return name;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<Long> getPatientsOfDoctor(Long doctorId) {
        logger.info("getPatientsOfDoctor");
        try {
            List<Long> patientsIds = null;
            Query q = em.createQuery("SELECT p.id FROM HCProfessionalEntity hcp JOIN hcp.patients p WHERE hcp.id=:id");
            q.setParameter("id", doctorId);
            if (!q.getResultList().isEmpty()) {
                patientsIds = (List<Long>) q.getResultList();
            }
            return patientsIds;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public List<Long> getGeneralCarePlans() {
        logger.info("getGeneralCarePlans");
        try {
            List<Long> gcpIds = null;
            Query q = em.createQuery("SELECT gcp.id FROM GeneralCarePlanEntity gcp");
            if (!q.getResultList().isEmpty()) {
                gcpIds = (List<Long>) q.getResultList();
            }
            return gcpIds;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public String getDiagnosticOfGCP(Long gcpId) {
        logger.info("getDiagnosticOfGCP");
        try {
            String diagonstic = null;
            Query q = em.createQuery("SELECT gcp.episodeOfCare.disease.diagnostic FROM GeneralCarePlanEntity gcp WHERE gcp.id=:id");
            q.setParameter("id", gcpId);
            if (!q.getResultList().isEmpty()) {
                diagonstic = (String) q.getResultList().get(0);
            }
            return diagonstic;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
    
    @Override
    public Long getDiseaseIdOfDiagnostic(String diagnostic) {
        logger.info("getDiseaseIdOfDiagnostic");
        try {
            Long diseaseId = null;
            Query q = em.createQuery("SELECT d.id FROM DiseaseEntity2 d WHERE d.diagnostic=:diagnostic");
            q.setParameter("diagnostic", diagnostic);
            if (!q.getResultList().isEmpty()) {
                diseaseId = (Long) q.getResultList().get(0);
            }
            return diseaseId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
}
