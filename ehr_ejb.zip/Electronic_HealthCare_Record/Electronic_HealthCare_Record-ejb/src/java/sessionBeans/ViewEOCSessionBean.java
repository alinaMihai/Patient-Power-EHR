/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionBeans;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import persistence.AccessControlListEntity;
import persistence.AddressEntity;
import persistence.ContactEntity;
import persistence.CustomizedCarePlanEntity;
import persistence.EpisodeOfCareEntity2;
import persistence.HCProfessionalEntity;
import persistence.PatientEntity;
import persistence.UserE;
import persistence.UserTypeEntity;
import remoteInterfaces.ViewEOCSession;

/**
 *
 * @author Alina
 */
@Stateless
public class ViewEOCSessionBean implements ViewEOCSession {

    @PersistenceContext(unitName = "Electronic_HealthCare_Record-ejbPU")
    private EntityManager em;
    private static final Logger logger = Logger.getLogger("ehr.request.RequestBean");

    public void persist(Object object) {
        em.persist(object);
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public Long getUserDoctorId(java.lang.Long userId) {
        logger.info("getUserDoctorId");
        try {
            Long doctorId = null;
            Query q = em.createQuery("SELECT hcp.id FROM HCProfessionalEntity hcp WHERE hcp.user.id=:userId");
            q.setParameter("userId", userId);
            if (!q.getResultList().isEmpty()) {
                doctorId = (Long) q.getResultList().get(0);
            }
            return doctorId;

        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long getCustomizedCarePlan(Long encounterId) {
        logger.info("getCustomizedCarePlan");
        try {
            ContactEntity encounter = em.find(ContactEntity.class, encounterId);
            CustomizedCarePlanEntity ccp = encounter.getCustomizedCarePlanEntity();
            return ccp.getId();

        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public java.util.List<ContactEntity> getEncountersOfPatient(java.lang.Long patientId) {
        logger.info("getEncountersOfPatient");
        try {
            List<ContactEntity> encounters = null;
            Query q = em.createQuery("SELECT DISTINCT e FROM PatientEntity p JOIN p.encounters e WHERE p.id=:patientId");
            q.setParameter("patientId", patientId);
            if (!q.getResultList().isEmpty()) {
                encounters = (List<ContactEntity>) q.getResultList();
            }
            return encounters;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long createACLforUser(java.lang.Long userEntityId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete) {
        logger.info("createACLforUser");
        try {
            AccessControlListEntity acl = new AccessControlListEntity();
            UserE user = em.find(UserE.class, userEntityId);
            acl.setCanView(canView);
            acl.setCanInsert(canInsert);
            acl.setCanUpdate(canUpdate);
            acl.setCanDelete(canDelete);
            acl.setUser(user);
            em.persist(acl);
            user.getAcls().add(acl);
            return acl.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void addACLtoEOC(java.lang.Long eocId, java.lang.Long aclId) {
        logger.info("addACLtoEOC");
        try {
            EpisodeOfCareEntity2 eoc = em.find(EpisodeOfCareEntity2.class, eocId);
            AccessControlListEntity acl = em.find(AccessControlListEntity.class, aclId);
            eoc.getAcls().add(acl);
            acl.setEpisodeOfCare(eoc);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public void addACLtoCCP(java.lang.Long ccpId, java.lang.Long aclId) {
        logger.info("addACLtoCCP");
        try {
            CustomizedCarePlanEntity ccp = em.find(CustomizedCarePlanEntity.class, ccpId);
            AccessControlListEntity acl = em.find(AccessControlListEntity.class, aclId);
            ccp.getAcls().add(acl);
            acl.setHcService(ccp);
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<Long> getCCPofEOC(Long eocId) {
        logger.info("getCCPofEOC");
        try {
            List<Long> ccpIds = null;
            Query q = em.createQuery("SELECT ccp.id FROM CustomizedCarePlanEntity ccp WHERE ccp.episodeOfCare.id=:id ");
            q.setParameter("id", eocId);
            if (!q.getResultList().isEmpty()) {
                ccpIds = (List<Long>) q.getResultList();
            }
            return ccpIds;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<Long> getEOCs_Of_Patient(Long patientId) {
        logger.info("getEOCsOfPatient");
        try {
            List<Long> eocIds = null;
            Query q = em.createQuery("SELECT DISTINCT eoc.id FROM PatientEntity p Join p.encounters e Join e.customizedCarePlanEntity h Join h.episodeOfCare eoc WHERE p.id=:id");
            q.setParameter("id", patientId);
            if (!q.getResultList().isEmpty()) {
                eocIds = (List<Long>) q.getResultList();
            }
            return eocIds;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public String findDoctorName(Long doctorId) {
        logger.info("findDoctorName");
        try {
            String name = null;
            Query q = em.createQuery("SELECT hcp.name FROM HCProfessionalEntity hcp WHERE hcp.id=:id");
            q.setParameter("id", doctorId);
            if (!q.getResultList().isEmpty()) {
                name = (String) q.getResultList().get(0);
            }
            return name;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long findUserPatientId(java.lang.Long userId) {
        logger.info("findUserPatientId");
        try {
            Long patientId = null;
            Query q = em.createQuery("SELECT p.id FROM PatientEntity p WHERE p.user.id=:id");
            q.setParameter("id", userId);
            if (!q.getResultList().isEmpty()) {
                patientId = (Long) q.getResultList().get(0);
            }
            return patientId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public java.util.List<Long> getDoctorUsers() {
        logger.info("getDoctorUsers");
        try {
            List<Long> userIds = null;
            Query q = em.createQuery("SELECT hcp.user.id FROM HCProfessionalEntity hcp");
            if (!q.getResultList().isEmpty()) {
                userIds = (List<Long>) q.getResultList();
            }
            return userIds;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public String getDoctorNameByEncounter(java.lang.Long encounterId) {
        logger.info("getDoctorNameByEncounter");
        try {
            String doctorName = null;
            Query q = em.createQuery("SELECT c.hcProfessional.name FROM ContactEntity c WHERE c.id=:id");
            q.setParameter("id", encounterId);
            if (!q.getResultList().isEmpty()) {
                doctorName = (String) q.getResultList().get(0);
            }
            return doctorName;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public java.util.List<String> getPatientById(java.lang.Long id) {
        logger.info("getPatientById");
        try {
            PatientEntity p;
            List<String> patientDetails = null;
            String country = null, city = null, street = null, number = null;
            Query q = em.createQuery("SELECT p FROM PatientEntity p JOIN FETCH p.address WHERE p.id=:id");
            q.setParameter("id", id);
            if (!q.getResultList().isEmpty()) {
                p = (PatientEntity) q.getResultList().get(0);
                AddressEntity address = p.getAddress();
                patientDetails = new ArrayList<String>();
                patientDetails.add(p.getName());
                patientDetails.add(p.getCnp());
                patientDetails.add(p.getHealthInsurance());
                patientDetails.add(p.getAge() + "");
                patientDetails.add(p.getBloodType());
                patientDetails.add(p.getEthnicity());
                patientDetails.add(p.getEmail());
                patientDetails.add(p.getId() + "");
                if (address != null) {
                    city = address.getCity();
                    country = address.getCountry();
                    street = address.getStreet();
                    number = address.getNumber();
                }
                patientDetails.add(city);
                patientDetails.add(country);
                patientDetails.add(street);
                patientDetails.add(number);
                patientDetails.add(p.getUser().getUsername());
                patientDetails.add(p.getUser().getPassword());

            }
            return patientDetails;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long loginPatient(String username, String password) {
        logger.info("loginPatient");
        try {
            Long userId = null;
            Query q = em.createQuery("SELECT p.user.id FROM PatientEntity p WHERE p.user.username=:name AND p.user.password=:pass");
            q.setParameter("name", username);
            q.setParameter("pass", password);
            if (!q.getResultList().isEmpty()) {
                userId = (Long) q.getResultList().get(0);
            }
            return userId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long userIdByDoctorName(java.lang.String doctorName) {
        logger.info("userIdByDoctorName");
        try {
            Long userId = null;
            Query q = em.createQuery("SELECT hcp.user.id FROM HCProfessionalEntity hcp WHERE hcp.name=:dn");
            q.setParameter("dn", doctorName);
            if (!q.getResultList().isEmpty()) {
                userId = (Long) q.getResultList().get(0);
            }
            return userId;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public Long createACL(Long userTypeId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete) {
        logger.info("createACL");
        try {
            AccessControlListEntity acl = new AccessControlListEntity();
            UserTypeEntity userType = em.find(UserTypeEntity.class, userTypeId);
            acl.setCanView(canView);
            acl.setCanInsert(canInsert);
            acl.setCanUpdate(canUpdate);
            acl.setCanDelete(canDelete);
            acl.setUserType(userType);
            em.persist(acl);
            userType.getAcls().add(acl);
            return acl.getId();
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<String> getHCProfessionalDetailsByHCProfessionalName(String hcProfessionalName) {
        logger.info("getHCProfessionalByName");
        try {
            HCProfessionalEntity hcp = null;
            String country = null, city = null, street = null, number = null;
            List<String> hcpDetails = new ArrayList<String>();
            Query q = em.createQuery("SELECT hcp FROM HCProfessionalEntity hcp  WHERE hcp.name=:name");
            q.setParameter("name", hcProfessionalName);
            if (!q.getResultList().isEmpty()) {
                hcp = (HCProfessionalEntity) q.getResultList().get(0);
            }
            AddressEntity address = hcp.getHcOrganization().getAddress();
            hcpDetails.add(hcp.getName());
            hcpDetails.add(hcp.getSpecialization());
            hcpDetails.add(hcp.getPhone());
            hcpDetails.add(hcp.getEmail());
            if (hcp.getUser().getUserType() != null) {
                hcpDetails.add(hcp.getUser().getUserType().getType());
            } else {
                hcpDetails.add("null");
            }
            hcpDetails.add(hcp.getHcOrganization().getName());
            hcpDetails.add(hcp.getHcOrganization().getDetails());
            if (address != null) {
                city = address.getCity();
                country = address.getCountry();
                street = address.getStreet();
                number = address.getNumber();
            }
            hcpDetails.add(city);
            hcpDetails.add(country);
            hcpDetails.add(street);
            hcpDetails.add(number);
            // username, password
            hcpDetails.add(hcp.getUser().getUsername());
            hcpDetails.add(hcp.getUser().getPassword());
            return hcpDetails;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<Long> getDoctorsOfPatient(Long patientId) {
        logger.info("getDoctorsOfPatient");
        try {
            List<Long> doctors = null;

            Query q = em.createQuery("SELECT hcp.id FROM PatientEntity p JOIN p.hcproviders hcp WHERE p.id=:id");
            q.setParameter("id", patientId);
            if (!q.getResultList().isEmpty()) {
                doctors = (List<Long>) q.getResultList();
            }
            return doctors;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }

    @Override
    public List<Long> getPatientsOfDoctor(Long doctorId) {
        logger.info("getPatientsOfDoctor");
        try {
            List<Long> patients = null;

            Query q = em.createQuery("SELECT p.id FROM HCProfessionalEntity hcp JOIN hcp.patients p WHERE hcp.id=:id");
            q.setParameter("id", doctorId);
            if (!q.getResultList().isEmpty()) {
                patients = (List<Long>) q.getResultList();
            }
            return patients;
        } catch (Exception e) {
            throw new EJBException(e);
        }
    }
}
