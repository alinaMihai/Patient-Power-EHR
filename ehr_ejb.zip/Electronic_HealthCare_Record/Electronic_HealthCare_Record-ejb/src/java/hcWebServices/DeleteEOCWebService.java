/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hcWebServices;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import remoteInterfaces.DeleteEOCSession;

/**
 *
 * @author Alina
 */
@WebService(serviceName = "DeleteEOCWebService")
@Stateless()
public class DeleteEOCWebService {
    
    @EJB
    private DeleteEOCSession ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "deleteEOC")
    public int deleteEOC(@WebParam(name = "eocId") Long eocId) {
        return ejbRef.deleteEOC(eocId);
    }
    
    @WebMethod(operationName = "deleteProcedure")
    @Oneway
    public void deleteProcedure(@WebParam(name = "procedureId") Long procedureId) {
        ejbRef.deleteProcedure(procedureId);
    }
    
    @WebMethod(operationName = "deleteQualObs")
    @Oneway
    public void deleteQualObs(@WebParam(name = "qualObsId") Long qualObsId) {
        ejbRef.deleteQualObs(qualObsId);
    }
    
    @WebMethod(operationName = "deleteQuanObs")
    @Oneway
    public void deleteQuanObs(@WebParam(name = "quanObsId") Long quanObsId) {
        ejbRef.deleteQuanObs(quanObsId);
    }
    
    @WebMethod(operationName = "deleteMedicine")
    @Oneway
    public void deleteMedicine(@WebParam(name = "medId") Long medId) {
        ejbRef.deleteMedicine(medId);
    }
    
    @WebMethod(operationName = "deletePharmacotherapy")
    @Oneway
    public void deletePharmacotherapy(@WebParam(name = "phId") Long phId) {
        ejbRef.deletePharmacotherapy(phId);
    }
    
    @WebMethod(operationName = "deleteSymptom")
    @Oneway
    public void deleteSymptom(@WebParam(name = "symptomid") Long symptomid) {
        ejbRef.deleteSymptom(symptomid);
    }
    
    @WebMethod(operationName = "deleteEncounter")
    @Oneway
    public void deleteEncounter(@WebParam(name = "encounterId") Long encounterId) {
        ejbRef.deleteEncounter(encounterId);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "deleteDoctor")
    @Oneway
    public void deleteDoctor(@WebParam(name = "doctorId") Long doctorId) {
        ejbRef.deleteDoctor(doctorId);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "deletePatient")
    @Oneway
    public void deletePatient(@WebParam(name = "patientId") Long patientId) {
        ejbRef.deletePatient(patientId);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "deleteACL")
    @Oneway
    public void deleteACL(@WebParam(name = "aclId") Long aclId) {
        ejbRef.deleteACL(aclId);
    }
    
    @WebMethod(operationName = "deleteGeneralCarePlan")
    @Oneway
    public void deleteGeneralCarePlan(@WebParam(name = "gcpId") Long gcpId) {
        ejbRef.deleteGeneralCarePlan(gcpId);
    }
    
    @WebMethod(operationName = "deleteCCP")
    @Oneway
    public void deleteCCP(@WebParam(name = "ccpId") Long ccpId) {
        ejbRef.deleteCCP(ccpId);
    }
    
    @WebMethod(operationName = "removePatientFromDoctorList")
    @Oneway
    public void removePatientFromDoctorList(@WebParam(name = "patientId") Long patientId, @WebParam(name = "doctorId") Long doctorId) {
        ejbRef.removePatientFromDoctorList(patientId, doctorId);
    }
    
    @WebMethod(operationName = "removeUserType")
    @Oneway
    public void removeUserType(@WebParam(name = "userTypeName") String userTypeName) {
        ejbRef.removeUserType(userTypeName);
    }
}
