/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hcWebServices;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import remoteInterfaces.DeleteEOCSession;
import remoteInterfaces.EditEOCSession;

/**
 *
 * @author Alina
 */
@WebService(serviceName = "EditEOCWebService")
@Stateless()
public class EditEOCWebService {

    @EJB
    private EditEOCSession ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")
    @EJB
    private DeleteEOCSession ejbRef_delete;

    @WebMethod(operationName = "updateProcedure")
    @Oneway
    public void updateProcedure(@WebParam(name = "procedureId") Long procedureId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "state") String state, @WebParam(name = "date_op") String date_op, @WebParam(name = "time_op") String time_op, @WebParam(name = "notes") String notes) {
        ejbRef.updateProcedure(procedureId, code, name, state, date_op, time_op, notes);
    }

    @WebMethod(operationName = "updateQualitativeObservation")
    @Oneway
    public void updateQualitativeObservation(@WebParam(name = "qualObsId") Long qualObsId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "state") String state, @WebParam(name = "date_op") String date_op, @WebParam(name = "time_op") String time_op, @WebParam(name = "notes") String notes, @WebParam(name = "description") String description) {
        ejbRef.updateQualitativeObservation(qualObsId, code, name, state, date_op, time_op, notes, description);
    }

    @WebMethod(operationName = "updateQuantitativeObservation")
    @Oneway
    public void updateQuantitativeObservation(@WebParam(name = "quanObsId") Long quanObsId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "state") String state, @WebParam(name = "date_op") String date_op, @WebParam(name = "time_op") String time_op, @WebParam(name = "measurement") String measurement, @WebParam(name = "description") String description) {
        ejbRef.updateQuantitativeObservation(quanObsId, code, name, state, date_op, time_op, measurement, description);
    }

    @WebMethod(operationName = "updatePharmacotherapy")
    @Oneway
    public void updatePharmacotherapy(@WebParam(name = "phId") Long phId, @WebParam(name = "name") String name, @WebParam(name = "state") String state, @WebParam(name = "date_op") String date_op, @WebParam(name = "time_op") String time_op) {
        ejbRef.updatePharmacotherapy(phId, name, state, date_op, time_op);
    }

    @WebMethod(operationName = "updateMedicine")
    @Oneway
    public void updateMedicine(@WebParam(name = "medId") Long medId, @WebParam(name = "name") String name, @WebParam(name = "code") String code, @WebParam(name = "priceUnit") String priceUnit, @WebParam(name = "price") double price, @WebParam(name = "strength") String strength, @WebParam(name = "dose") String dose, @WebParam(name = "howTaken") String howTaken, @WebParam(name = "resonForTaking") String resonForTaking, @WebParam(name = "dateStarted") String dateStarted, @WebParam(name = "dateStopped") String dateStopped) {
        ejbRef.updateMedicine(medId, name, code, priceUnit, price, strength, dose, howTaken, resonForTaking, dateStarted, dateStopped);
    }

    @WebMethod(operationName = "updateSymptom")
    @Oneway
    public void updateSymptom(@WebParam(name = "symptomId") Long symptomId, @WebParam(name = "name") String name, @WebParam(name = "description") String description, @WebParam(name = "frequency") String frequency, @WebParam(name = "status") String status, @WebParam(name = "apperance") String apperance, @WebParam(name = "disapperance") String disapperance) {
        ejbRef.updateSymptom(symptomId, name, description, frequency, status, apperance, disapperance);
    }

    @WebMethod(operationName = "updateEOC")
    @Oneway
    public void updateEOC(@WebParam(name = "eocId") Long eocId, @WebParam(name = "startdate") String startdate, @WebParam(name = "starttime") String starttime, @WebParam(name = "enddate") String enddate, @WebParam(name = "endtime") String endtime, @WebParam(name = "code") String code) {
        ejbRef.updateEOC(eocId, startdate, starttime, enddate, endtime, code);
    }

    @WebMethod(operationName = "editEncounter")
    @Oneway
    public void editEncounter(@WebParam(name = "encounterId") Long encounterId, @WebParam(name = "code") String code, @WebParam(name = "consult_date") String consult_date, @WebParam(name = "consult_time") String consult_time, @WebParam(name = "consult_type") String consult_type) {
        ejbRef.editEncounter(encounterId, code, consult_date, consult_time, consult_type);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "updateDoctorDetails")
    public boolean updateDoctorDetails(@WebParam(name = "userId") Long userId, @WebParam(name = "doctorId") Long doctorId, @WebParam(name = "name") String name, @WebParam(name = "specialization") String specialization, @WebParam(name = "email") String email, @WebParam(name = "phone") String phone, @WebParam(name = "username") String username, @WebParam(name = "password") String password, @WebParam(name = "userTypeId") Long userTypeId) {
        return ejbRef.updateDoctorDetails(userId, doctorId, name, specialization, email, phone, username, password, userTypeId);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "updateAddress")
    @Oneway
    public void updateAddress(@WebParam(name = "addressId") Long addressId, @WebParam(name = "country") String country, @WebParam(name = "city") String city, @WebParam(name = "street") String street, @WebParam(name = "number") String number) {
        ejbRef.updateAddress(addressId, country, city, street, number);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "updateHCOrganization")
    @Oneway
    public void updateHCOrganization(@WebParam(name = "hcOrgId") Long hcOrgId, @WebParam(name = "name") String name, @WebParam(name = "details") String details) {
        ejbRef.updateHCOrganization(hcOrgId, name, details);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "updatePatient")
    public boolean updatePatient(@WebParam(name = "userId") Long userId, @WebParam(name = "patientId") Long patientId,
            @WebParam(name = "name") String name, @WebParam(name = "cnp") String cnp,
            @WebParam(name = "healthInsurance") String healthInsurance, @WebParam(name = "age") int age,
            @WebParam(name = "bloodType") String bloodType, @WebParam(name = "ethnicity") String ethnicity,
            @WebParam(name = "email") String email, @WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        return ejbRef.updatePatient(userId, patientId, name, cnp, healthInsurance, age, bloodType, ethnicity, email, username, password);
    }

    @WebMethod(operationName = "getUserIdOfDoctor")
    public Long getUserIdOfDoctor(@WebParam(name = "doctorId") Long doctorId) {
        return ejbRef.getUserIdOfDoctor(doctorId);
    }

    @WebMethod(operationName = "getHCOrgIdOfDoctor")
    public Long getHCOrgIdOfDoctor(@WebParam(name = "doctorId") Long doctorId) {
        return ejbRef.getHCOrgIdOfDoctor(doctorId);
    }

    @WebMethod(operationName = "getAddressIdOfHCOrg")
    public Long getAddressIdOfHCOrg(@WebParam(name = "hcOrgId") Long hcOrgId) {
        return ejbRef.getAddressIdOfHCOrg(hcOrgId);
    }

    @WebMethod(operationName = "getUserIdOfPatient")
    public Long getUserIdOfPatient(@WebParam(name = "patientId") Long patientId) {
        return ejbRef.getUserIdOfPatient(patientId);
    }

    @WebMethod(operationName = "getAddressOfPatient")
    public Long getAddressOfPatient(@WebParam(name = "patientId") Long patientId) {
        return ejbRef.getAddressOfPatient(patientId);
    }

    @WebMethod(operationName = "updateACL")
    public void updateACL(@WebParam(name = "aclId") Long aclId, @WebParam(name = "userTypeId") Long userTypeId, @WebParam(name = "userEntityId") Long userEntityId, @WebParam(name = "canView") boolean canView, @WebParam(name = "canInsert") boolean canInsert,
            @WebParam(name = "canUpdate") boolean canUpdate, @WebParam(name = "canDelete") boolean canDelete) {
        ejbRef.updateACL(aclId, userTypeId, userEntityId, canView, canInsert, canUpdate, canDelete);
    }

    @WebMethod(operationName = "getACLsOfEOC")
    public java.util.List<Long> getACLsOfEOC(@WebParam(name = "eocId") java.lang.Long eocId) {
        return ejbRef.getACLsOfEOC(eocId);
    }

    @WebMethod(operationName = "getACLDetails")
    public List<String> getACLDetails(@WebParam(name = "aclId") Long aclId) {
        return ejbRef.getACLDetails(aclId);
    }

    @WebMethod(operationName = "deleteACL")
    @Oneway
    public void deleteACL(@WebParam(name = "aclId") Long aclId) {
        ejbRef_delete.deleteACL(aclId);
    }

    @WebMethod(operationName = "editAdminUser")
     @Oneway
   public void editAdminUser(@WebParam(name = "adminId")Long adminId,@WebParam(name = "password") String password) {
      ejbRef.editAdminUser(adminId, password);
   }
    
    @WebMethod(operationName = "getACLsOfCCP")
    public List<Long> getACLsOfCCP(@WebParam(name = "ccpId") Long ccpId) {
        return ejbRef.getACLsOfCCP(ccpId);
    }
}
