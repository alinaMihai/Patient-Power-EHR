/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hcWebServices;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import persistence.AccessControlListEntity;
import persistence.MedicineEntity;
import persistence.PlannedHCitemEntity;
import persistence.PlannedPharmacotherapyEntity;
import persistence.PlannedProcedureEntity;
import persistence.QualitativeObservationEntity;
import persistence.QuantitativeObservationEntity;
import persistence.SymptomEntity;
import remoteInterfaces.DoctorSession;

/**
 *
 * @author Alina
 */
@WebService(serviceName = "DoctorWebService")
@Stateless()
public class DoctorWebService {

    @EJB
    private DoctorSession ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "login")
    public Long login(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        return ejbRef.login(username, password);
    }

    @WebMethod(operationName = "getPatients")
    public List<Long> getPatients() {
        return ejbRef.getPatients();
    }

    @WebMethod(operationName = "getPatientNames")
    public List<String> getPatientNames() {
        return ejbRef.getPatientNames();
    }

    @WebMethod(operationName = "getPatientInfo")
    public List<String> getPatientInfo(@WebParam(name = "patientId") Long patientId) {
        return ejbRef.getPatientInfo(patientId);
    }

    @WebMethod(operationName = "getHCOrgIdOfDoctor")
    public Long getHCOrgIdOfDoctor(@WebParam(name = "doctorId") Long doctorId) {
        return ejbRef.getHCOrgIdOfDoctor(doctorId);
    }

    @WebMethod(operationName = "addCustomizedCarePlan")
    public Long addCustomizedCarePlan(@WebParam(name = "EOCId") Long EOCId, @WebParam(name = "HCProviderId") Long HCProviderId, @WebParam(name = "ContactId") Long ContactId) {
        return ejbRef.addCustomizedCarePlan(EOCId, HCProviderId, ContactId);
    }

    @WebMethod(operationName = "addDisease")
    @Oneway
    public void addDisease(@WebParam(name = "eocId") Long eocId, @WebParam(name = "diseaseId") Long diseaseId) {
        ejbRef.addDisease(eocId, diseaseId);
    }

    @WebMethod(operationName = "addEncounter")
    public Long addEncounter(@WebParam(name = "code") String code, @WebParam(name = "patientId") Long patientId, @WebParam(name = "doctorId") Long doctorId, @WebParam(name = "orgId") Long orgId, @WebParam(name = "consult_date") String consult_date, @WebParam(name = "consult_time") String consult_time, @WebParam(name = "consult_type") String consult_type) {
        return ejbRef.addEncounter(code, patientId, doctorId, orgId, consult_date, consult_time, consult_type);
    }

    @WebMethod(operationName = "addGeneralCarePlan")
    public Long addGeneralCarePlan(@WebParam(name = "EOCid") Long EOCid) {
        return ejbRef.addGeneralCarePlan(EOCid);
    }

    @WebMethod(operationName = "addGeneralPharmacotherapy")
    public PlannedPharmacotherapyEntity addGeneralPharmacotherapy(@WebParam(name = "generalCarePlanId") Long generalCarePlanId, @WebParam(name = "name") String name) {
        return ejbRef.addGeneralPharmacotherapy(generalCarePlanId, name);
    }

    @WebMethod(operationName = "addGeneralProcedure")
    public PlannedProcedureEntity addGeneralProcedure(@WebParam(name = "generalCarePlanId") Long generalCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "notes") String notes) {
        return ejbRef.addGeneralProcedure(generalCarePlanId, code, name, notes);
    }

    @WebMethod(operationName = "addGeneralQualitativeObservation")
    public QualitativeObservationEntity addGeneralQualitativeObservation(@WebParam(name = "generalCarePlanId") Long generalCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "notes") String notes, @WebParam(name = "description") String description) {
        return ejbRef.addGeneralQualitativeObservation(generalCarePlanId, code, name, notes, description);
    }

    @WebMethod(operationName = "addGeneralQuantitativeObservation")
    public QuantitativeObservationEntity addGeneralQuantitativeObservation(@WebParam(name = "generalCarePlanId") Long generalCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "measurement") String measurement, @WebParam(name = "description") String description) {
        return ejbRef.addGeneralQuantitativeObservation(generalCarePlanId, code, name, measurement, description);
    }

    @WebMethod(operationName = "addMedicine")
    public Long addMedicine(@WebParam(name = "PharmacotherapyId") Long PharmacotherapyId, @WebParam(name = "name") String name, @WebParam(name = "code") String code, @WebParam(name = "priceUnit") String priceUnit, @WebParam(name = "price") double price, @WebParam(name = "strength") String strength, @WebParam(name = "dose") String dose, @WebParam(name = "howTaken") String howTaken, @WebParam(name = "resonForTaking") String resonForTaking, @WebParam(name = "dateStarted") String dateStarted, @WebParam(name = "dateStopped") String dateStopped) {
        return ejbRef.addMedicine(PharmacotherapyId, name, code, priceUnit, price, strength, dose, howTaken, resonForTaking, dateStarted, dateStopped);
    }

    @WebMethod(operationName = "addPharmacotherapy")
    public Long addPharmacotherapy(@WebParam(name = "customizedCarePlanId") Long customizedCarePlanId, @WebParam(name = "name") String name, @WebParam(name = "state") String state, @WebParam(name = "date_op") String date_op, @WebParam(name = "time_op") String time_op) {
        return ejbRef.addPharmacotherapy(customizedCarePlanId, name, state, date_op, time_op);
    }

    @WebMethod(operationName = "addProcedure")
    @Oneway
    public void addProcedure(@WebParam(name = "customizedCarePlanId") Long customizedCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "state") String state, @WebParam(name = "date_op") String date_op, @WebParam(name = "time_op") String time_op, @WebParam(name = "notes") String notes) {
        ejbRef.addProcedure(customizedCarePlanId, code, name, state, date_op, time_op, notes);
    }

    @WebMethod(operationName = "addQualitativeObservation")
    @Oneway
    public void addQualitativeObservation(@WebParam(name = "customizedCarePlanId") Long customizedCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "state") String state, @WebParam(name = "date_op") String date_op, @WebParam(name = "time_op") String time_op, @WebParam(name = "notes") String notes, @WebParam(name = "description") String description) {
        ejbRef.addQualitativeObservation(customizedCarePlanId, code, name, state, date_op, time_op, notes, description);
    }

    @WebMethod(operationName = "addQuantitativeObservation")
    @Oneway
    public void addQuantitativeObservation(@WebParam(name = "customizedCarePlanId") Long customizedCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "state") String state, @WebParam(name = "date_op") String date_op, @WebParam(name = "time_op") String time_op, @WebParam(name = "measurement") String measurement, @WebParam(name = "description") String description) {
        ejbRef.addQuantitativeObservation(customizedCarePlanId, code, name, state, date_op, time_op, measurement, description);
    }

    @WebMethod(operationName = "addSymptom")
    @Oneway
    public void addSymptom(@WebParam(name = "diseaseId") Long diseaseId, @WebParam(name = "symptomId") Long symptomId) {
        ejbRef.addSymptom(diseaseId, symptomId);
    }

    @WebMethod(operationName = "createDisease")
    public Long createDisease(@WebParam(name = "diagnostic") String diagnostic) {
        return ejbRef.createDisease(diagnostic);
    }

    @WebMethod(operationName = "createEOC")
    public Long createEOC(@WebParam(name = "startdate") String startdate, @WebParam(name = "starttime") String starttime, @WebParam(name = "enddate") String enddate, @WebParam(name = "endtime") String endtime, @WebParam(name = "code") String code) {
        return ejbRef.createEOC(startdate, starttime, enddate, endtime, code);
    }

    @WebMethod(operationName = "createSymptom")
    public Long createSymptom(@WebParam(name = "name") String name, @WebParam(name = "description") String description, @WebParam(name = "frequency") String frequency, @WebParam(name = "status") String status, @WebParam(name = "apperance") String apperance, @WebParam(name = "disapperance") String disapperance) {
        return ejbRef.createSymptom(name, description, frequency, status, apperance, disapperance);
    }

    @WebMethod(operationName = "getDiagnostics")
    public List<String> getDiagnostics() {
        return ejbRef.getDiagnostics();
    }

    @WebMethod(operationName = "getGeneralHCItemsOfDisease")
    public List<PlannedHCitemEntity> getGeneralHCItemsOfDisease(@WebParam(name = "diagnostic") String diagnostic) {
        return ejbRef.getGeneralHCItemsOfDisease(diagnostic);
    }

    @WebMethod(operationName = "getMedicinesOfPharmacotherapy")
    public List<MedicineEntity> getMedicinesOfPharmacotherapy(@WebParam(name = "pharmacotherapyId") Long pharmacotherapyId) {
        return ejbRef.getMedicinesOfPharmacotherapy(pharmacotherapyId);
    }

    @WebMethod(operationName = "getGeneralSymptomsOfDisease")
    public List<SymptomEntity> getGeneralSymptomsOfDisease(@WebParam(name = "diagnostic") String diagnostic) {
        return ejbRef.getGeneralSymptomsOfDisease(diagnostic);
    }

    @WebMethod(operationName = "getByUserAndEOC")
    public AccessControlListEntity getByUserAndEOC(@WebParam(name = "userId") Long userId, @WebParam(name = "eocId") Long eocId) {
        return ejbRef.getByUserAndEOC(userId, eocId);
    }

    @WebMethod(operationName = "getByUserAndCCP")
    public AccessControlListEntity getByUserAndCCP(@WebParam(name = "userId") Long userId, @WebParam(name = "ccpId") Long ccpId) {
        return ejbRef.getByUserAndCCP(userId, ccpId);
    }

    @WebMethod(operationName = "getByUserTypeAndEOC")
    public AccessControlListEntity getByUserTypeAndEOC(@WebParam(name = "userTypeId") Long userTypeId, @WebParam(name = "eocId") Long eocId) {
        return ejbRef.getByUserTypeAndEOC(userTypeId, eocId);
    }

    @WebMethod(operationName = "getByUserTypeAndCCP")
    public AccessControlListEntity getByUserTypeAndCCP(@WebParam(name = "userTypeId") Long userTypeId, @WebParam(name = "ccpId") Long ccpId) {
        return ejbRef.getByUserTypeAndEOC(userTypeId, ccpId);
    }

    @WebMethod(operationName = "getUserTypeIdofUser")
    public Long getUserTypeIdofUser(@WebParam(name = "userId") Long userId) {
        return ejbRef.getUserTypeIdofUser(userId);
    }

    @WebMethod(operationName = "getEOCDetails")
    public java.util.List<java.lang.String> getEOCDetails(@WebParam(name = "eocId") java.lang.Long eocId) {
        return ejbRef.getEOCDetails(eocId);
    }

    @WebMethod(operationName = "getEncounterOfEOC")
    public List<Long> getEncounterOfEOC(@WebParam(name = "eocId") Long eocId) {
        return ejbRef.getEncounterOfEOC(eocId);
    }

    @WebMethod(operationName = "getEncounterDetails")
    public List<String> getEncounterDetails(@WebParam(name = "encounterId") Long encounterId) {
        return ejbRef.getEncounterDetails(encounterId);
    }

    @WebMethod(operationName = "getHCProfessionalNameOfCCP")
    public String getHCProfessionalNameOfCCP(@WebParam(name = "ccpId") Long ccpId) {
        return ejbRef.getHCProfessionalNameOfCCP(ccpId);
    }

    @WebMethod(operationName = "getHCItemsOfCustomizedCarePlan")
    public List<PlannedHCitemEntity> getHCItemsOfCustomizedCarePlan(@WebParam(name = "ccpId") Long ccpId) {
        return ejbRef.getHCItemsOfCustomizedCarePlan(ccpId);
    }

    @WebMethod(operationName = "getSymptomsOfDisease")
    public List<SymptomEntity> getSymptomsOfDisease(@WebParam(name = "diseaseId") Long diseaseId) {
        return ejbRef.getSymptomsOfDisease(diseaseId);
    }

    @WebMethod(operationName = "getHCProfessionalNamebyUserId")
    public String getHCProfessionalNamebyUserId(@WebParam(name = "userId") Long userId) {
        return ejbRef.getHCProfessionalNamebyUserId(userId);
    }

    @WebMethod(operationName = "getPatientsOfDoctor")
    public List<Long> getPatientsOfDoctor(@WebParam(name = "doctorId") Long doctorId) {
        return ejbRef.getPatientsOfDoctor(doctorId);
    }

    @WebMethod(operationName = "getGeneralCarePlans")
    public List<Long> getGeneralCarePlans() {
        return ejbRef.getGeneralCarePlans();
    }

    @WebMethod(operationName = "getDiagnosticOfGCP")
    public String getDiagnosticOfGCP(@WebParam(name = "gcpId") Long gcpId) {
        return ejbRef.getDiagnosticOfGCP(gcpId);
    }

    @WebMethod(operationName = "getDiseaseIdOfDiagnostic")
    public Long getDiseaseIdOfDiagnostic(@WebParam(name = "diagnostic") String diagnostic) {
        return ejbRef.getDiseaseIdOfDiagnostic(diagnostic);
    }

    @WebMethod(operationName = "getCCPDetails")
    public List<String> getCCPDetails(@WebParam(name = "ccpId") Long ccpId) {
        return ejbRef.getCCPDetails(ccpId);
    }
}
