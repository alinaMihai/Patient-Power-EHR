/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hcWebServices;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import persistence.ContactEntity;
import persistence.MedicineEntity;
import persistence.PlannedHCitemEntity;
import persistence.PlannedPharmacotherapyEntity;
import persistence.PlannedProcedureEntity;
import persistence.QualitativeObservationEntity;
import persistence.QuantitativeObservationEntity;
import persistence.SymptomEntity;
import remoteInterfaces.AdminSession;
import remoteInterfaces.DoctorSession;
import remoteInterfaces.ViewEOCSession;

/**
 *
 * @author Alina
 */
@WebService(serviceName = "ViewEOCWebService")
@Stateless()
public class ViewEOCWebService {

    @EJB
    private ViewEOCSession ejbRef;// Add business logic below. (Right-click in editor and choose
    @EJB
    private AdminSession ejbRef_admin;
    @EJB
    private DoctorSession ejbRef_doc;
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "getUserDoctorId")
    public Long getUserDoctorId(@WebParam(name = "userId") Long userId) {
        return ejbRef.getUserDoctorId(userId);
    }

    @WebMethod(operationName = "getCustomizedCarePlan")
    public Long getCustomizedCarePlan(@WebParam(name = "encounterId") Long encounterId) {
        return ejbRef.getCustomizedCarePlan(encounterId);
    }

    @WebMethod(operationName = "getEncountersOfPatient")
    public java.util.List<ContactEntity> getEncountersOfPatient(@WebParam(name = "patientId") java.lang.Long patientId) {
        return ejbRef.getEncountersOfPatient(patientId);
    }

    @WebMethod(operationName = "createACLforUser")
    public Long createACLforUser(@WebParam(name = "userEntityId") java.lang.Long userEntityId,
            @WebParam(name = "canView") boolean canView, @WebParam(name = "canInsert") boolean canInsert,
            @WebParam(name = "canUpdate") boolean canUpdate,
            @WebParam(name = "canDelete") boolean canDelete) {
        return ejbRef.createACLforUser(userEntityId, canView, canInsert, canUpdate, canDelete);
    }

    @WebMethod(operationName = "addACLtoEOC")
    public void addACLtoEOC(@WebParam(name = "eocId") java.lang.Long eocId, @WebParam(name = "aclId") java.lang.Long aclId) {
        ejbRef.addACLtoEOC(eocId, aclId);
    }

    @WebMethod(operationName = "getEOCs_Of_Patient")
    public List<Long> getEOCs_Of_Patient(@WebParam(name = "patientId") Long patientId) {
        return ejbRef.getEOCs_Of_Patient(patientId);
    }

    @WebMethod(operationName = "findDoctorName")
    public java.lang.String findDoctorName(@WebParam(name = "doctorId") java.lang.Long doctorId) {
        return ejbRef.findDoctorName(doctorId);
    }

    @WebMethod(operationName = "findUserPatientId")
    public java.lang.Long findUserPatientId(@WebParam(name = "userId") java.lang.Long userId) {
        return ejbRef.findUserPatientId(userId);
    }

    @WebMethod(operationName = "getDoctorUsers")
    public java.util.List<java.lang.Long> getDoctorUsers() {
        return ejbRef.getDoctorUsers();
    }

    @WebMethod(operationName = "getDoctorNameByEncounter")
    public java.lang.String getDoctorNameByEncounter(@WebParam(name = "encounterId") java.lang.Long encounterId) {
        return ejbRef.getDoctorNameByEncounter(encounterId);
    }

    @WebMethod(operationName = "getPatientById")
    public java.util.List<java.lang.String> getPatientById(@WebParam(name = "id") java.lang.Long id) {
        return ejbRef.getPatientById(id);
    }

    @WebMethod(operationName = "loginPatient")
    public java.lang.Long loginPatient(@WebParam(name = "name") java.lang.String username, @WebParam(name = "password") java.lang.String password) {
        return ejbRef.loginPatient(username, password);
    }

    @WebMethod(operationName = "userIdByDoctorName")
    public java.lang.Long userIdByDoctorName(@WebParam(name = "doctorName") java.lang.String doctorName) {
        return ejbRef.userIdByDoctorName(doctorName);
    }

    @WebMethod(operationName = "createACL")
    public Long createACL(@WebParam(name = "userTypeId") Long userTypeId,
            @WebParam(name = "canView") boolean canView, @WebParam(name = "canInsert") boolean canInsert,
            @WebParam(name = "canUpdate") boolean canUpdate, @WebParam(name = "canDelete") boolean canDelete) {
        return ejbRef.createACL(userTypeId, canView, canInsert, canUpdate, canDelete);
    }

    @WebMethod(operationName = "getMedicinesOfPharmacotherapy")
    public List<MedicineEntity> getMedicinesOfPharmacotherapy(@WebParam(name = "pharmacotherapyId") Long pharmacotherapyId) {
        return ejbRef_doc.getMedicinesOfPharmacotherapy(pharmacotherapyId);
    }

    @WebMethod(operationName = "getSymptomsOfDisease")
    public List<SymptomEntity> getSymptomsOfDisease(@WebParam(name = "diseaseId") Long diseaseId) {
        return ejbRef_doc.getSymptomsOfDisease(diseaseId);
    }

    @WebMethod(operationName = "getUserTypeId")
    public Long getUserTypeId(@WebParam(name = "type") String type) {
        return ejbRef_admin.getUserTypeId(type);
    }

    @WebMethod(operationName = "getUserTypes")
    public List<String> getUserTypes() {
        return ejbRef_admin.getUserTypes();
    }

    @WebMethod(operationName = "getHCItemsOfCustomizedCarePlan")
    public List<PlannedHCitemEntity> getHCItemsOfCustomizedCarePlan(@WebParam(name = "ccpId") Long ccpId) {
        return ejbRef_doc.getHCItemsOfCustomizedCarePlan(ccpId);
    }

    @WebMethod(operationName = "getEOCDetails")
    public java.util.List<java.lang.String> getEOCDetails(@WebParam(name = "eocId") java.lang.Long eocId) {
        return ejbRef_doc.getEOCDetails(eocId);
    }

    @WebMethod(operationName = "addGeneralPharmacotherapy")
    public PlannedPharmacotherapyEntity addGeneralPharmacotherapy(@WebParam(name = "generalCarePlanId") Long generalCarePlanId, @WebParam(name = "name") String name) {
        return ejbRef_doc.addGeneralPharmacotherapy(generalCarePlanId, name);
    }

    @WebMethod(operationName = "addGeneralProcedure")
    public PlannedProcedureEntity addGeneralProcedure(@WebParam(name = "generalCarePlanId") Long generalCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "notes") String notes) {
        return ejbRef_doc.addGeneralProcedure(generalCarePlanId, code, name, notes);
    }

    @WebMethod(operationName = "addGeneralQualitativeObservation")
    public QualitativeObservationEntity addGeneralQualitativeObservation(@WebParam(name = "generalCarePlanId") Long generalCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "notes") String notes, @WebParam(name = "description") String description) {
        return ejbRef_doc.addGeneralQualitativeObservation(generalCarePlanId, code, name, notes, description);
    }

    @WebMethod(operationName = "addGeneralQuantitativeObservation")
    public QuantitativeObservationEntity addGeneralQuantitativeObservation(@WebParam(name = "generalCarePlanId") Long generalCarePlanId, @WebParam(name = "code") String code, @WebParam(name = "name") String name, @WebParam(name = "measurement") String measurement, @WebParam(name = "description") String description) {
        return ejbRef_doc.addGeneralQuantitativeObservation(generalCarePlanId, code, name, measurement, description);
    }

    @WebMethod(operationName = "getEncounterOfEOC")
    public List<Long> getEncounterOfEOC(@WebParam(name = "eocId") Long eocId) {
        return ejbRef_doc.getEncounterOfEOC(eocId);
    }

    @WebMethod(operationName = "getEncounterDetails")
    public List<String> getEncounterDetails(@WebParam(name = "encounterId") Long encounterId) {
        return ejbRef_doc.getEncounterDetails(encounterId);
    }

    @WebMethod(operationName = "getHCProfessionalNameOfCCP")
    public String getHCProfessionalNameOfCCP(@WebParam(name = "ccpId") Long ccpId) {
        return ejbRef_doc.getHCProfessionalNameOfCCP(ccpId);
    }

    @WebMethod(operationName = "getHCProfessionalDetailsByHCProfessionalName")
    public List<String> getHCProfessionalDetailsByHCProfessionalName(@WebParam(name = "hcProfessionalName") String hcProfessionalName) {
        return ejbRef.getHCProfessionalDetailsByHCProfessionalName(hcProfessionalName);
    }

    @WebMethod(operationName = "addACLtoCCP")
    public void addACLtoCCP(@WebParam(name = "ccpId") java.lang.Long ccpId, @WebParam(name = "aclId") java.lang.Long aclId) {
        ejbRef.addACLtoCCP(ccpId, aclId);
    }

    @WebMethod(operationName = "getCCPsofEOC")
    public java.util.List<java.lang.Long> getCCPofEOC(@WebParam(name = "eocId") java.lang.Long eocId) {
        return ejbRef.getCCPofEOC(eocId);
    }

    @WebMethod(operationName = "getCCPDetails")
    public List<String> getCCPDetails(@WebParam(name = "ccpId") Long ccpId) {
        return ejbRef_doc.getCCPDetails(ccpId);
    }

    @WebMethod(operationName = "getDoctorsOfPatient")
    public List<Long> getDoctorsOfPatient(@WebParam(name = "patientId") Long patientId) {
        return ejbRef.getDoctorsOfPatient(patientId);
    }

    @WebMethod(operationName = "getPatientsOfDoctor")
    public List<Long> getPatientsOfDoctor(@WebParam(name = "doctorId") Long doctorId) {
        return ejbRef.getPatientsOfDoctor(doctorId);
    }
}
