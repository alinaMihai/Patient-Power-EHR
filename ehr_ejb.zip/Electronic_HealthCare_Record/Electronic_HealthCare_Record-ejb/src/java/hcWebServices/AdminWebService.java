/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hcWebServices;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import persistence.AddressEntity;
import persistence.HCOrganizationEntity;
import persistence.HCProfessionalEntity;
import persistence.PatientEntity;
import remoteInterfaces.AdminSession;
import remoteInterfaces.DoctorSession;
import remoteInterfaces.ViewEOCSession;

/**
 *
 * @author Alina
 */
@WebService(serviceName = "AdminWebService")
@Stateless()
public class AdminWebService {

    @EJB
    private AdminSession ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")
    @EJB
    private ViewEOCSession ejbRef_view;
    @EJB
    private DoctorSession ejbRef_doctor;

    @WebMethod(operationName = "createUserType")
    @Oneway
    public void createUserType(@WebParam(name = "type") String type) {
        ejbRef.createUserType(type);
    }

    @WebMethod(operationName = "getUserTypeId")
    public Long getUserTypeId(@WebParam(name = "type") String type) {
        return ejbRef.getUserTypeId(type);
    }

    @WebMethod(operationName = "getUserTypes")
    public List<String> getUserTypes() {
        return ejbRef.getUserTypes();
    }

    @WebMethod(operationName = "addHCOrganizationAddress")
    @Oneway
    public void addHCOrganizationAddress(@WebParam(name = "orgId") Long orgId, @WebParam(name = "addressId") Long addressId) {
        ejbRef.addHCOrganizationAddress(orgId, addressId);
    }

    @WebMethod(operationName = "addHcOrgToDoctor")
    @Oneway
    public void addHcOrgToDoctor(@WebParam(name = "hcOrgId") Long hcOrgId, @WebParam(name = "doctorId") Long doctorId) {
        ejbRef.addHcOrgToDoctor(hcOrgId, doctorId);
    }

    @WebMethod(operationName = "addPatientToHCProvider")
    @Oneway
    public void addPatientToHCProvider(@WebParam(name = "doctorId") Long doctorId, @WebParam(name = "patientId") Long patientId) {
        ejbRef.addPatientToHCProvider(doctorId, patientId);
    }

    @WebMethod(operationName = "createAddress")
    public AddressEntity createAddress(@WebParam(name = "country") String country, @WebParam(name = "city") String city, @WebParam(name = "street") String street, @WebParam(name = "number") String number) {
        return ejbRef.createAddress(country, city, street, number);
    }

    @WebMethod(operationName = "addHCOrganization")
    public HCOrganizationEntity addHCOrganization(@WebParam(name = "name") String name, @WebParam(name = "details") String details) {
        return ejbRef.addHCOrganization(name, details);
    }

    @WebMethod(operationName = "addHCProfessional")
    public Long addHCProfessional(@WebParam(name = "name") String name, @WebParam(name = "specialization") String specialization, @WebParam(name = "email") String email, @WebParam(name = "phone") String phone, @WebParam(name = "username") String username, @WebParam(name = "password") String password, @WebParam(name = "userTypeId") Long userTypeId) {
        return ejbRef.addHCProfessional(name, specialization, email, phone, username, password, userTypeId);
    }

    @WebMethod(operationName = "createPatient")
    public Long createPatient(@WebParam(name = "name") String name, @WebParam(name = "cnp") String cnp,
            @WebParam(name = "healthInsurance") String healthInsurance,
            @WebParam(name = "age") int age, @WebParam(name = "bloodType") String bloodType,
            @WebParam(name = "ethnicity") String ethnicity, @WebParam(name = "email") String email,
            @WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        return ejbRef.createPatient(name, cnp, healthInsurance, age, bloodType, ethnicity, email, username, password);
    }

    @WebMethod(operationName = "findDoctorByName")
    public Long findDoctorByName(@WebParam(name = "name") String name) {
        return ejbRef.findDoctorByName(name);
    }

    @WebMethod(operationName = "getHCProviders")
    public List<String> getHCProviders() {
        return ejbRef.getHCProviders();
    }

    @WebMethod(operationName = "getPatientIdByName")
    public Long getPatientIdByName(@WebParam(name = "name") String name) {
        return ejbRef.getPatientIdByName(name);
    }

    @WebMethod(operationName = "addAddressToPatient")
    @Oneway
    public void addAddressToPatient(@WebParam(name = "patientId") Long patientId, @WebParam(name = "addressId") Long addressId) {
        ejbRef.addAddressToPatient(patientId, addressId);
    }

    @WebMethod(operationName = "getAllDoctors")
    public List<HCProfessionalEntity> getAllDoctors() {
        return ejbRef.getAllDoctors();
    }

    @WebMethod(operationName = "getAllPatients")
    public List<PatientEntity> getAllPatients() {
        return ejbRef.getAllPatients();
    }

    @WebMethod(operationName = "getHCProfessionalDetailsByHCProfessionalName")
    public List<String> getHCProfessionalDetailsByHCProfessionalName(@WebParam(name = "hcProfessionalName") String hcProfessionalName) {
        return ejbRef_view.getHCProfessionalDetailsByHCProfessionalName(hcProfessionalName);
    }

    @WebMethod(operationName = "getPatientById")
    public java.util.List<java.lang.String> getPatientById(@WebParam(name = "id") java.lang.Long id) {
        return ejbRef_view.getPatientById(id);
    }

    @WebMethod(operationName = "getPatients")
    public List<Long> getPatients() {
        return ejbRef_doctor.getPatients();
    }

    @WebMethod(operationName = "getPatientNames")
    public List<String> getPatientNames() {
        return ejbRef_doctor.getPatientNames();
    }

    @WebMethod(operationName = "createAdminUser")
    public Long createAdminUser(@WebParam(name = "password") String password) {
        return ejbRef.createAdminUser(password);
    }

    @WebMethod(operationName = "checkAdminLogin")
    public Long checkAdminLogin(@WebParam(name = "password") java.lang.String password) {
        return ejbRef.checkAdminLogin(password);
    }

    @WebMethod(operationName = "getDoctorsOfPatient")
    public List<Long> getDoctorsOfPatient(@WebParam(name = "patientId") Long patientId) {
        return ejbRef_view.getDoctorsOfPatient(patientId);
    }

    @WebMethod(operationName = "getPatientsOfDoctor")
    public List<Long> getPatientsOfDoctor(@WebParam(name = "doctorId") Long doctorId) {
        return ejbRef_view.getPatientsOfDoctor(doctorId);
    }
}
