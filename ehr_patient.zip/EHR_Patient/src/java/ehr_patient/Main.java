/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient;

import com.digitprop.tonic.TonicLookAndFeel;
import ehr_patient.interfaces.Login;
import javax.swing.JFrame;
import javax.swing.UIManager;

/**
 *
 * @author Alina
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // String lookAndFeel = "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel";
        try {
            UIManager.setLookAndFeel(new TonicLookAndFeel());
            JFrame.setDefaultLookAndFeelDecorated(true);
        } catch (Exception e) {
            System.out.println("Nimbus isn't available");
        }
        Login frame = new Login("Login");
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setResizable(false);
    }
}
