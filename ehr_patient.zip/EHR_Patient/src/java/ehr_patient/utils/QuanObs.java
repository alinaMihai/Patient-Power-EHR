/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import hcwebservices.QuantitativeObservationEntity;






/**
 *
 * @author Alina
 */
public class QuanObs extends QuantitativeObservationEntity {

    @Override
    public String toString(){
    return this.name;}
   
}
