/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import ehr_patient.Controller;
import ehr_patient.interfaces.ACLsOfEOC;
import ehr_patient.interfaces.EditACL;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class ACLTreeAction extends MouseAdapter {

    private DefaultMutableTreeNode selectionNode;
    protected JTree tree;
    private ACLstr acl;
    private Controller command;

    public ACLTreeAction(JTree l) {
        this.tree = l;
        this.command = Controller.getInstance();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isRightMouseButton(e)) {
            int selRow = tree.getRowForLocation(e.getX(), e.getY());
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            acl = (ACLstr) selectionNode.getUserObject();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
                if (selectionNode.getAllowsChildren() == false) {
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                        JPopupMenu menu = new JPopupMenu();
                        JMenuItem jt1 = new JMenuItem("Edit Access Control List");
                        jt1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {

                                EditACL frame = new EditACL("Edit ACL");
                                frame.getCanView_checkbox().setSelected(acl.isCanView());
                                frame.getCanInsert_checkbox().setSelected(acl.isCanInsert());
                                frame.getCanUpdate_checkbox().setSelected(acl.isCanUpdate());
                                frame.getCanDelete_checkbox().setSelected(acl.isCanDelete());
                                if (acl.getUsername() != null) {
                                    frame.getUser_usergroup_tf().setText(acl.getUsername());
                                    frame.getUser_usergroup_tf().setEditable(false);
                                } else if (acl.getUserType() != null) {
                                    frame.getUser_usergroup_tf().setText(acl.getUserType());
                                    frame.getUser_usergroup_tf().setEditable(false);
                                }
                                frame.setLocationRelativeTo(null);
                                frame.setResizable(false);
                                frame.setVisible(true);
                            }
                        });
                        menu.add(jt1);

                        JMenuItem jt2 = new JMenuItem("Delete Access Control List");
                        jt2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete ACL", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                    command.deleteACL(acl.getId());
                                    ACLsOfEOC.getModel().removeNodeFromParent(selectionNode);
                                    ACLsOfEOC.getModel().reload();
                                    for (int i = 0; i < ACLsOfEOC.getAclsTree().getRowCount(); i++) {
                                        ACLsOfEOC.getAclsTree().expandRow(i);
                                    }
                                }
                            }
                        });
                        menu.add(jt2);
                        menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                    }
                }
            }
        }
    }

