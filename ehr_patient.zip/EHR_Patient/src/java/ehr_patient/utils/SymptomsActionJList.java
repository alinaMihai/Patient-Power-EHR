/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import ehr_patient.interfaces.ViewSymptom;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JList;
import javax.swing.ListModel;

/**
 *
 * @author Alina
 */
public class SymptomsActionJList extends MouseAdapter {
    
    protected JList list;
    
    public SymptomsActionJList(JList l) {
        list = l;
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            int index = list.locationToIndex(e.getPoint());
            ListModel dlm = list.getModel();
            Symptom item = (Symptom) dlm.getElementAt(index);
            list.ensureIndexIsVisible(index);
            // JOptionPane.showMessageDialog(null, "Double clicked on " + item);
            ViewSymptom frame = new ViewSymptom("View Symptom");
            frame.getTitle_lb().setText(item.getName());
            frame.getName_tf().setText(item.getName());
            frame.getName_tf().setEditable(false);
            frame.getDescription_ta().setText(item.getDescription());
            frame.getDescription_ta().setEditable(false);
            frame.getAppearance_date_tf().setText(item.getAppearanceDate());
            frame.getAppearance_date_tf().setEditable(false);
            frame.getDisapperance_date_tf().setText(item.getDisappearanceDate());
            frame.getDisapperance_date_tf().setEditable(false);
            frame.getState_tf().setText(item.getStatus());
            frame.getState_tf().setEditable(false);
            frame.getFrequency_tf().setText(item.getFrequency());
            frame.getFrequency_tf().setEditable(false);
            frame.setResizable(false);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            
        }
    }
}
