/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import ehr_patient.interfaces.ACL_for_CCP.CreateACL_for_CCP;
import ehr_patient.interfaces.ACLsOfEOC;
import ehr_patient.interfaces.EpisodeOfCareFrame;
import ehr_patient.interfaces.ViewEOC;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class EOCJTreeClickAction extends MouseAdapter {

    protected JTree tree;

    public EOCJTreeClickAction(JTree tree) {
        this.tree = tree;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isRightMouseButton(e)) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            final DefaultMutableTreeNode selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (selectionNode.getAllowsChildren() == false) {
                if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem jt1 = new JMenuItem("View Episode of Care ");
                    jt1.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {

                            ViewEOC frame = new ViewEOC("View EOC");
                            DefaultMutableTreeNode eocSelectedNode = (DefaultMutableTreeNode) EpisodeOfCareFrame.getEOCTree().getLastSelectedPathComponent();
                            EOCStr eoc = (EOCStr) eocSelectedNode.getUserObject();
                            frame.getTitle_lb().setText(eoc.getDiagnostic());
                            frame.getCode_tf().setText(eoc.getCode());
                            frame.getCode_tf().setEditable(false);
                            frame.getStart_date_tf().setText(eoc.getStartDate());
                            frame.getStart_date_tf().setEditable(false);
                            frame.getStart_time_tf().setText(eoc.getStartTime());
                            frame.getStart_time_tf().setEditable(false);
                            frame.getEnd_date_tf().setText(eoc.getEndDate());
                            frame.getEnd_date_tf().setEditable(false);
                            frame.getEnd_time_tf().setText(eoc.getEndTime());
                            frame.getEnd_time_tf().setEditable(false);
                            frame.getDiagnostic_tf().setText(eoc.getDiagnostic());
                            frame.getDiagnostic_tf().setEditable(false);
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        }
                    });
                    menu.add(jt1);
                    JMenuItem jt2 = new JMenuItem("Access Control Lists of Episode of Care");
                    jt2.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            ACLsOfEOC frame = new ACLsOfEOC("ACLs");
                            EOCStr eoc = (EOCStr) selectionNode.getUserObject();
                            frame.getTitle_lb().setText("Access Control Lists of " + eoc.getDiagnostic());
                            frame.setLocationRelativeTo(null);
                            frame.setResizable(false);
                            frame.setVisible(true);
                        }
                    });
                    menu.add(jt2);
                    JMenuItem jt3 = new JMenuItem("Create ACL for a Healthcare service");
                    jt3.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            CreateACL_for_CCP frame = new CreateACL_for_CCP("Create ACL for a HCService");
                            frame.setLocationRelativeTo(null);
                            frame.setResizable(false);
                            frame.setVisible(true);
                        }
                    });
                    menu.add(jt3);
                    menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                }
            }
        }
    }
}

