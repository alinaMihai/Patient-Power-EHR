/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

/**
 *
 * @author Alina
 */
public class EncounterStr {

    private String code;
    private String consult_date;
    private String consult_time;
    private String consult_type;
    private Long id;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getConsult_date() {
        return consult_date;
    }

    public void setConsult_date(String consult_date) {
        this.consult_date = consult_date;
    }

    public String getConsult_time() {
        return consult_time;
    }

    public void setConsult_time(String consult_time) {
        this.consult_time = consult_time;
    }

    public String getConsult_type() {
        return consult_type;
    }

    public void setConsult_type(String consult_type) {
        this.consult_type = consult_type;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Encounter on " + consult_date;
    }
}
