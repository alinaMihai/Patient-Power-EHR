/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import hcwebservices.PlannedProcedureEntity;

/**
 *
 * @author Alina
 */
public class Procedure extends PlannedProcedureEntity {

    @Override
    public String toString() {
        return this.name;
    }
}
