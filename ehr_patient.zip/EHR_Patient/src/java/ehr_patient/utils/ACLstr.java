/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

/**
 *
 * @author Alina
 */
public class ACLstr {

    private Long id;
    private String Username;
    private String UserType;
    private boolean canView;
    private boolean canInsert;
    private boolean canUpdate;
    private boolean canDelete;
    private String encounterType;
    private String encounterDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isCanView() {
        return canView;
    }

    public void setCanView(boolean canView) {
        this.canView = canView;
    }

    public boolean isCanInsert() {
        return canInsert;
    }

    public void setCanInsert(boolean canInsert) {
        this.canInsert = canInsert;
    }

    public boolean isCanUpdate() {
        return canUpdate;
    }

    public void setCanUpdate(boolean canUpdate) {
        this.canUpdate = canUpdate;
    }

    public boolean isCanDelete() {
        return canDelete;
    }

    public void setCanDelete(boolean canDelete) {
        this.canDelete = canDelete;
    }

    public String getUsername() {
        return Username;
    }

    public String getUserType() {
        return UserType;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public void setUserType(String UserType) {
        this.UserType = UserType;
    }

    public String getEncounterType() {
        return encounterType;
    }

    public void setEncounterType(String encounterType) {
        this.encounterType = encounterType;
    }

    public String getEncounterDate() {
        return encounterDate;
    }

    public void setEncounterDate(String encounterDate) {
        this.encounterDate = encounterDate;
    }

    @Override
    public String toString() {
        String name = null;
        if (Username != null) {
            name = Username;
            if (encounterDate != null && encounterType != null) {
                name += " for HCService on: " + encounterDate + " type " + encounterType;
            }
        }
        if (UserType != null) {
            name = UserType+" group";
            if (encounterDate != null && encounterType != null) {
                name += " for HCService on: " + encounterDate + " type " + encounterType;
            }
        }
        return "ACL id: " + id + " for " + name;
    }
}
