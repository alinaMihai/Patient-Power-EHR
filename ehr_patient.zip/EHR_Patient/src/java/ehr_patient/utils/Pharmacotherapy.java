/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import hcwebservices.PlannedPharmacotherapyEntity;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alina
 */
public class Pharmacotherapy extends PlannedPharmacotherapyEntity {

    private List<MedicineS> medicines;

    public Pharmacotherapy() {
        medicines = new ArrayList<MedicineS>();
    }

    public List<MedicineS> getMedicines() {
        return medicines;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
