/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import ehr_patient.interfaces.ViewMedicine;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class ViewMedicineDoubleClickTreeAction extends MouseAdapter {

    protected JTree tree;

    public ViewMedicineDoubleClickTreeAction(JTree tree) {
        this.tree = tree;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int selRow = tree.getRowForLocation(e.getX(), e.getY());
        if (e.getClickCount() == 2) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            DefaultMutableTreeNode selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (selRow > 0) {
                if (selectionNode.getAllowsChildren() == false) {
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                      MedicineS med = (MedicineS) selectionNode.getUserObject();
                         ViewMedicine frame = new ViewMedicine("View Medicine");
                         frame.getTitle_lb().setText(med.getName());
                         frame.getCode_tf().setText(med.getCode());
                         frame.getCode_tf().setEditable(false);
                         frame.getName_tf().setText(med.getName());
                         frame.getName_tf().setEditable(false);
                         frame.getDateStarted_tf().setText(med.getDateStarted());
                         frame.getDateStarted_tf().setEditable(false);
                         frame.getDateStopped_tf().setText(med.getDateStopped());
                         frame.getDateStopped_tf().setEditable(false);
                         frame.getStrength_tf().setText(med.getStrength());
                         frame.getStrength_tf().setEditable(false);
                         frame.getHowTaken_tf().setText(med.getHowTaken());
                         frame.getHowTaken_tf().setEditable(false);
                         frame.getReasonForTaking_ta().setText(med.getReasonForTaking());
                         frame.getDose_ta().setText(med.getDose());
                         frame.getPrice_tf().setText(med.getPrice() + "");
                         frame.getPrice_tf().setEditable(false);
                         frame.getPrice_unit_cb().setSelectedItem(med.getPriceUnit());
                         frame.getPrice_unit_cb().setEnabled(false);
                         frame.setLocationRelativeTo(null);
                         frame.setVisible(true);
                         frame.setResizable(false);

                    }
                }
            }
        }
    }
}
