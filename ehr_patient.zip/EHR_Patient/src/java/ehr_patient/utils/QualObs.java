/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import hcwebservices.QualitativeObservationEntity;

/**
 *
 * @author Alina
 */
public class QualObs extends QualitativeObservationEntity {

    @Override
    public String toString() {
        return this.name;
    }
}
