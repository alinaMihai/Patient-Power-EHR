/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import ehr_patient.interfaces.ViewEncounter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JList;
import javax.swing.ListModel;

/**
 *
 * @author Alina
 */
public class EncounterActionList extends MouseAdapter {

    protected JList list;

    public EncounterActionList(JList l) {
        list = l;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            int index = list.locationToIndex(e.getPoint());
            ListModel dlm = list.getModel();
            EncounterStr item = (EncounterStr) dlm.getElementAt(index);
            list.ensureIndexIsVisible(index);
            ViewEncounter frame = new ViewEncounter("View Encounter");
            frame.getTitle_lb().setText(item.getConsult_type());
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            frame.setResizable(false);

        }
    }
}
