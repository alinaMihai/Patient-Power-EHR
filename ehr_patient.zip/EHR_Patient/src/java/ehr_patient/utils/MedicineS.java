/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import hcwebservices.MedicineEntity;

/**
 *
 * @author Alina
 */
public class MedicineS extends MedicineEntity {

    @Override
    public String toString() {
        return super.name;
    }
}
