/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import ehr_patient.interfaces.ViewPharmacotherapy;
import ehr_patient.interfaces.ViewProcedure;
import ehr_patient.interfaces.ViewQualitativeObservation;
import ehr_patient.interfaces.ViewQuantitativeObservation;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class HCItemJTreeDoubleClickAction extends MouseAdapter {
    
    protected JTree tree;
    
    public HCItemJTreeDoubleClickAction(JTree tree) {
        this.tree = tree;
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        int selRow = tree.getRowForLocation(e.getX(), e.getY());
        if (e.getClickCount() == 2) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            DefaultMutableTreeNode selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (selRow > 0) {
                if (selectionNode.getAllowsChildren() == false) {
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                        if (selectionNode.getUserObject() instanceof Procedure) {
                            Procedure p = (Procedure) selectionNode.getUserObject();
                            ViewProcedure frame = new ViewProcedure("View Procedure");
                            frame.getTitle_lb().setText(p.getName());
                            frame.getCode_tf().setText(p.getCode());
                            frame.getCode_tf().setEditable(false);
                            frame.getName_tf().setText(p.getName());
                            frame.getName_tf().setEditable(false);
                            frame.getDate_tf().setText(p.getDateOp());
                            frame.getDate_tf().setEditable(false);
                            frame.getTime_tf().setText(p.getTimeOp());
                            frame.getTime_tf().setEditable(false);
                            frame.getState_tf().setText(p.getStateHCI());
                            frame.getState_tf().setEditable(false);
                            frame.getProcedure_notes_ta().setText(p.getNotes());
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                            frame.setResizable(false);
                            
                        }
                        if (selectionNode.getUserObject() instanceof QualObs) {
                            QualObs qo = (QualObs) selectionNode.getUserObject();
                            ViewQualitativeObservation frame = new ViewQualitativeObservation("View Qualitative Observation");
                            frame.getTitle_lb().setText(qo.getName());
                            frame.getCode_tf().setText(qo.getCode());
                            frame.getName_tf().setText(qo.getName());
                            frame.getDate_tf().setText(qo.getDateOp());
                            frame.getTime_tf().setText(qo.getTimeOp());
                            frame.getState_tf().setText(qo.getStateHCI());
                            frame.getNotes_ta().setText(qo.getNotes());
                            frame.getDescription_tf().setText(qo.getDescription());
                            frame.getCode_tf().setEditable(false);
                            frame.getName_tf().setEditable(false);
                            frame.getDate_tf().setEditable(false);
                            frame.getTime_tf().setEditable(false);
                            frame.getState_tf().setEditable(false);
                            frame.getDescription_tf().setEditable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                            frame.setResizable(false);
                        }
                        if (selectionNode.getUserObject() instanceof QuanObs) {
                            QuanObs qo = (QuanObs) selectionNode.getUserObject();
                            ViewQuantitativeObservation frame = new ViewQuantitativeObservation("View Quantitative Observation");
                            frame.getTitle_lb().setText(qo.getName());
                            frame.getCode_tf().setText(qo.getCode());
                            frame.getName_tf().setText(qo.getName());
                            frame.getDate_tf().setText(qo.getDateOp());
                            frame.getTime_tf().setText(qo.getTimeOp());
                            frame.getState_tf().setText(qo.getStateHCI());
                            frame.getMeasurement_ta().setText(qo.getMeasurementQ());
                            frame.getDescription_ta().setText(qo.getDescription());
                            frame.getCode_tf().setEditable(false);
                            frame.getName_tf().setEditable(false);
                            frame.getDate_tf().setEditable(false);
                            frame.getTime_tf().setEditable(false);
                            frame.getState_tf().setEditable(false);
                            frame.setLocationRelativeTo(null);
                            frame.getMeasurement_ta().setEditable(false);
                            frame.setVisible(true);
                            frame.setResizable(false);
                        }
                 
                        
                        if (selectionNode.getUserObject() instanceof Pharmacotherapy) {
                            Pharmacotherapy ph = (Pharmacotherapy) selectionNode.getUserObject();
                            ViewPharmacotherapy frame = new ViewPharmacotherapy("View Pharmacotherapy");
                            frame.getTitle_label().setText(ph.getName());
                            frame.getTime_tf().setText(ph.getTimeOp());
                            frame.getState_tf().setText(ph.getStateHCI());
                            frame.getName_tf().setText(ph.getName());
                            frame.getDate_tf().setText(ph.getDateOp());
                            frame.getName_tf().setEditable(false);
                            frame.getDate_tf().setEditable(false);
                            frame.getTime_tf().setEditable(false);
                            frame.getState_tf().setEditable(false);
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                            
                        }
                    }
                }
            }
        }
    }
}
