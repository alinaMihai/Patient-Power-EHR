/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import hcwebservices.SymptomEntity;




/**
 *
 * @author Alina
 */
public class Symptom extends SymptomEntity {

    @Override
    public String toString() {
        return super.name;
    }
}
