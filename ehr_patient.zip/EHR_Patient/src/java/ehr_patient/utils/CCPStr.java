/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.utils;

import hcwebservices.CustomizedCarePlanEntity;

/**
 *
 * @author Alina
 */
public class CCPStr extends CustomizedCarePlanEntity {

    String encounter_date;
    String encounter_type;
    String encounter_code;
    Long encounter_id;
   String encounter_time;
    public String getEncounter_date() {
        return encounter_date;
    }

    public void setEncounter_date(String encounter_date) {
        this.encounter_date = encounter_date;
    }

    public String getEncounter_type() {
        return encounter_type;
    }

    public void setEncounter_type(String encounter_type) {
        this.encounter_type = encounter_type;
    }

    public String getEncounter_code() {
        return encounter_code;
    }

    public void setEncounter_code(String encounter_code) {
        this.encounter_code = encounter_code;
    }

    public Long getEncounter_id() {
        return encounter_id;
    }

    public void setEncounter_id(Long encounter_id) {
        this.encounter_id = encounter_id;
    }

    public String getEncounter_time() {
        return encounter_time;
    }

    public void setEncounter_time(String encounter_time) {
        this.encounter_time = encounter_time;
    }

    @Override
    public String toString() {
        return "HCService on: " + encounter_date + " type " + encounter_type;
    }
}
