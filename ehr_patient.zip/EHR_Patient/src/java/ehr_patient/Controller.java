/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient;

import hcwebservices.EpisodeOfCareEntity2;

/**
 *
 * @author Alina
 */
public class Controller {

    private static class SingletonHolder {

        private static final Controller INSTANCE = new Controller();
    }

    public static Controller getInstance() {
        return SingletonHolder.INSTANCE;
    }
    hcwebservices.ViewEOCWebService_Service service = new hcwebservices.ViewEOCWebService_Service();
    hcwebservices.ViewEOCWebService port = service.getViewEOCWebServicePort();

    public void addACLtoEOC(java.lang.Long eocId, java.lang.Long aclId) {
        port.addACLtoEOC(eocId, aclId);
    }

    public Long createACL(java.lang.Long userTypeId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete) {
        return port.createACL(userTypeId, canView, canInsert, canUpdate, canDelete);
    }

    public Long createACLforUser(java.lang.Long userEntityId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete) {
        return port.createACLforUser(userEntityId, canView, canInsert, canUpdate, canDelete);
    }

    public String findDoctorName(java.lang.Long doctorId) {
        return port.findDoctorName(doctorId);
    }

    public Long findUserPatientId(java.lang.Long userId) {
        return port.findUserPatientId(userId);
    }

    public Long getCustomizedCarePlan(java.lang.Long encounterId) {
        return port.getCustomizedCarePlan(encounterId);
    }

    public String getDoctorNameByEncounter(java.lang.Long encounterId) {
        return port.getDoctorNameByEncounter(encounterId);
    }

    public java.util.List<java.lang.Long> getDoctorUsers() {
        return port.getDoctorUsers();
    }

    public java.util.List<java.lang.Long> getEOCsOfPatient(java.lang.Long patientId) {
        return port.getEOCsOfPatient(patientId);
    }

    public java.util.List<hcwebservices.ContactEntity> getEncountersOfPatient(java.lang.Long patientId) {
        return port.getEncountersOfPatient(patientId);
    }

    public java.util.List<hcwebservices.MedicineEntity> getMedicinesOfPharmacotherapy(java.lang.Long pharmacotherapyId) {
        return port.getMedicinesOfPharmacotherapy(pharmacotherapyId);
    }

    public java.util.List<java.lang.String> getPatientById(java.lang.Long id) {
        return port.getPatientById(id);
    }

    public java.util.List<hcwebservices.SymptomEntity> getSymptomsOfDisease(java.lang.Long diseaseId) {
        return port.getSymptomsOfDisease(diseaseId);
    }

    public Long getUserDoctorId(java.lang.Long userId) {
        return port.getUserDoctorId(userId);
    }

    public Long getUserTypeId(java.lang.String type) {
        return port.getUserTypeId(type);
    }

    public java.util.List<java.lang.String> getUserTypes() {
        return port.getUserTypes();
    }

    public Long loginPatient(java.lang.String name, java.lang.String password) {
        return port.loginPatient(name, password);
    }

    public Long userIdByDoctorName(java.lang.String doctorName) {
        return port.userIdByDoctorName(doctorName);
    }

    public java.util.List<hcwebservices.PlannedHCitemEntity> getHCItemsOfCustomizedCarePlan(java.lang.Long ccpId) {
        return port.getHCItemsOfCustomizedCarePlan(ccpId);
    }

    public java.util.List<java.lang.String> getEOCDetails(java.lang.Long eocId) {
        return port.getEOCDetails(eocId);
    }

    public java.util.List<java.lang.String> getEncounterDetails(java.lang.Long encounterId) {
        return port.getEncounterDetails(encounterId);
    }

    public java.util.List<java.lang.Long> getEncounterOfEOC(java.lang.Long eocId) {
        return port.getEncounterOfEOC(eocId);
    }

    public java.util.List<java.lang.String> getHCProfessionalDetailsByHCProfessionalName(java.lang.String hcProfessionalName) {
        return port.getHCProfessionalDetailsByHCProfessionalName(hcProfessionalName);
    }

    public String getHCProfessionalNameOfCCP(java.lang.Long ccpId) {
        return port.getHCProfessionalNameOfCCP(ccpId);
    }

    public java.util.List<Long> getACLsOfEOC(java.lang.Long eocId) {
        hcwebservices.EditEOCWebService_Service servicex = new hcwebservices.EditEOCWebService_Service();
        hcwebservices.EditEOCWebService portx = servicex.getEditEOCWebServicePort();
        return portx.getACLsOfEOC(eocId);
    }

    public void updateACL(java.lang.Long aclId, java.lang.Long userTypeId, java.lang.Long userEntityId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete) {
        hcwebservices.EditEOCWebService_Service servicex = new hcwebservices.EditEOCWebService_Service();
        hcwebservices.EditEOCWebService portx = servicex.getEditEOCWebServicePort();
        portx.updateACL(aclId, userTypeId, userEntityId, canView, canInsert, canUpdate, canDelete);
    }

    public java.util.List<java.lang.String> getACLDetails(java.lang.Long aclId) {
        hcwebservices.EditEOCWebService_Service servicex = new hcwebservices.EditEOCWebService_Service();
        hcwebservices.EditEOCWebService portx = servicex.getEditEOCWebServicePort();
        return portx.getACLDetails(aclId);
    }

    public void deleteACL(java.lang.Long aclId) {
        hcwebservices.EditEOCWebService_Service servicex = new hcwebservices.EditEOCWebService_Service();
        hcwebservices.EditEOCWebService portx = servicex.getEditEOCWebServicePort();
        portx.deleteACL(aclId);
    }

    public void addACLtoCCP(java.lang.Long ccpId, java.lang.Long aclId) {
        port.addACLtoCCP(ccpId, aclId);
    }

    public java.util.List<java.lang.Long> getCCPsofEOC(java.lang.Long eocId) {
        return port.getCCPsofEOC(eocId);
    }

    public java.util.List<java.lang.Long> getACLsOfCCP(java.lang.Long ccpId) {
        hcwebservices.EditEOCWebService_Service servicex = new hcwebservices.EditEOCWebService_Service();
        hcwebservices.EditEOCWebService portx = servicex.getEditEOCWebServicePort();
        return portx.getACLsOfCCP(ccpId);
    }

    public java.util.List<java.lang.String> getCCPDetails(java.lang.Long ccpId) {
        return port.getCCPDetails(ccpId);
    }
}
