/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.interfaces;

import ehr_patient.Controller;
import ehr_patient.utils.EOCStr;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author Alina
 */
public class CreateACL extends javax.swing.JFrame {

    /**
     * Creates new form CreateACL
     */
    private String doctorName;
    private String userType;
    private boolean canView;
    private boolean canInsert;
    private boolean canUpdate;
    private boolean canDelete;
    private static Controller command;
    private static DefaultListModel eoc_listModel;
    private ArrayList<String> userTypes;
    private ArrayList<Long> users;

    public CreateACL(String name) {
        super(name);
        command = Controller.getInstance();
        eoc_listModel = new DefaultListModel();
        initComponents();
        List<Long> eocIds = command.getEOCsOfPatient(Login.getPacientId());
        if (!eocIds.isEmpty()) {
            for (Long eId : eocIds) {
                ArrayList<String> eocDetails = (ArrayList<String>) command.getEOCDetails(eId);
                EOCStr eoc = new EOCStr();
                eoc.setId(Long.parseLong(eocDetails.get(0)));
                eoc.setCode(eocDetails.get(1));
                eoc.setStartDate(eocDetails.get(2));
                eoc.setStartTime(eocDetails.get(3));
                eoc.setEndDate(eocDetails.get(4));
                eoc.setEndTime(eocDetails.get(5));
                eoc.setDiagnostic(eocDetails.get(6));
                eoc.setDiseaseId(Long.parseLong(eocDetails.get(7)));
                eoc_listModel.addElement(eoc);

            }
        }


        userTypes = (ArrayList<String>) command.getUserTypes();
        if (userTypes != null) {

            for (String ut : userTypes) {
                userType_cb.addItem(ut);
            }
        }
        userType_cb.setSelectedItem(null);
        userType_cb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JComboBox cb = (JComboBox) ae.getSource();
                userType = (String) cb.getSelectedItem();
                user_cb.setSelectedItem(null);
                userType_cb.setSelectedItem(userType);
            }
        });
        users = (ArrayList<Long>) command.getDoctorUsers();
        if (users != null) {
            for (Long u : users) {
                Long doctorId = command.getUserDoctorId(u);
                String adoctorName = command.findDoctorName(doctorId);
                user_cb.addItem(adoctorName);
            }
        }
        user_cb.setSelectedItem(null);
        user_cb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JComboBox cb = (JComboBox) ae.getSource();
                doctorName = (String) cb.getSelectedItem();
                userType_cb.setSelectedItem(null);
                user_cb.setSelectedItem(doctorName);

            }
        });



        canView_checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb = (JCheckBox) ae.getSource();
                canView = (boolean) cb.isSelected();
            }
        });
        canInsert_checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb = (JCheckBox) ae.getSource();
                canInsert = (boolean) cb.isSelected();
            }
        });
        canUpdate_checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb = (JCheckBox) ae.getSource();
                canUpdate = (boolean) cb.isSelected();
            }
        });
        canDelete_checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb = (JCheckBox) ae.getSource();
                canDelete = (boolean) cb.isSelected();
            }
        });



    }

    public void setData() {
        canView = canView_checkbox.isSelected();
        canInsert = canInsert_checkbox.isSelected();
        canUpdate = canUpdate_checkbox.isSelected();
        canDelete = canDelete_checkbox.isSelected();
        doctorName = (String) user_cb.getSelectedItem();
        userType = (String) userType_cb.getSelectedItem();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        user_cb = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        userType_cb = new javax.swing.JComboBox();
        canView_checkbox = new javax.swing.JCheckBox();
        canInsert_checkbox = new javax.swing.JCheckBox();
        canUpdate_checkbox = new javax.swing.JCheckBox();
        canDelete_checkbox = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        cancel_bt = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        eoc_list = new javax.swing.JList(eoc_listModel);
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("                                        Create Access Control List");

        jLabel2.setText("User");

        jLabel3.setText("User Group");

        canView_checkbox.setText("can View");
        canView_checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                canView_checkboxActionPerformed(evt);
            }
        });

        canInsert_checkbox.setText("can Insert");

        canUpdate_checkbox.setText("can Update");

        canDelete_checkbox.setText("can Delete");

        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        cancel_bt.setText("Cancel");
        cancel_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_btActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(eoc_list);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("or");

        jLabel5.setText("Choose a user or a user group");

        jLabel6.setText("Select an episode of care");

        jLabel7.setText("Allow rights");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 93, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cancel_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel5)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(102, 102, 102)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel3)
                                                    .addComponent(jLabel2))
                                                .addGap(28, 28, 28)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(9, 9, 9)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                            .addComponent(canDelete_checkbox)
                                                            .addComponent(canUpdate_checkbox)
                                                            .addComponent(canInsert_checkbox)
                                                            .addComponent(canView_checkbox)))
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(user_cb, 0, 169, Short.MAX_VALUE)
                                                        .addComponent(userType_cb, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(115, 115, 115)
                                        .addComponent(jLabel4)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(31, 31, 31)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(user_cb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jLabel4)
                .addGap(1, 1, 1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(userType_cb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(27, 27, 27)
                .addComponent(jLabel7)
                .addGap(5, 5, 5)
                .addComponent(canView_checkbox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(canInsert_checkbox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(canUpdate_checkbox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(canDelete_checkbox)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(cancel_bt))
                .addGap(36, 36, 36))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void canView_checkboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_canView_checkboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_canView_checkboxActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        setData();
        Long userTypeId;
        Long userId = command.userIdByDoctorName(doctorName);
        EOCStr eoc = (EOCStr) eoc_list.getSelectedValue();

        if (userType != null) {
            userTypeId = command.getUserTypeId(userType);
            Long aclId = command.createACL(userTypeId, canView, canInsert, canUpdate, canDelete);
            command.addACLtoEOC(eoc.getId(), aclId);
            JOptionPane.showMessageDialog(null, "Access controll list successfully created");
        } else {
            try {
                Long aclId = command.createACLforUser(userId, canView, canInsert, canUpdate, canDelete);
                command.addACLtoEOC(eoc.getId(), aclId);
            } catch (Exception ex) {
                Logger.getLogger(CreateACL.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Access controll list successfully created");
        }

    }//GEN-LAST:event_jButton1ActionPerformed
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void cancel_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_btActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_cancel_btActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;


                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CreateACL.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CreateACL.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CreateACL.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CreateACL.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CreateACL("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox canDelete_checkbox;
    private javax.swing.JCheckBox canInsert_checkbox;
    private javax.swing.JCheckBox canUpdate_checkbox;
    private javax.swing.JCheckBox canView_checkbox;
    private javax.swing.JButton cancel_bt;
    private javax.swing.JList eoc_list;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox userType_cb;
    private javax.swing.JComboBox user_cb;
    // End of variables declaration//GEN-END:variables
}
