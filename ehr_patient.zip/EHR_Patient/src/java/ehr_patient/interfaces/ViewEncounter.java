/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.interfaces;

import ehr_patient.Controller;
import ehr_patient.interfaces.ACL_for_CCP.CreateACL_for_CCP;
import ehr_patient.utils.CCPStr;
import ehr_patient.utils.EncounterStr;
import ehr_patient.utils.HCItemJTreeDoubleClickAction;
import ehr_patient.utils.MedicineS;
import ehr_patient.utils.Pharmacotherapy;
import ehr_patient.utils.Procedure;
import ehr_patient.utils.QualObs;
import ehr_patient.utils.QuanObs;
import hcwebservices.MedicineEntity;
import hcwebservices.PlannedHCitemEntity;
import hcwebservices.PlannedPharmacotherapyEntity;
import hcwebservices.PlannedProcedureEntity;
import hcwebservices.QualitativeObservationEntity;
import hcwebservices.QuantitativeObservationEntity;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

/**
 *
 * @author Alina
 */
public class ViewEncounter extends javax.swing.JFrame {

    /**
     * Creates new form ViewEncounter
     */
    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    private static JTree hcItemsTree;
    private static DefaultMutableTreeNode groupP;
    private static DefaultMutableTreeNode groupPh;
    private static DefaultMutableTreeNode groupQualObs;
    private static DefaultMutableTreeNode groupQuanObs;
    private EncounterStr encounterStr;
    private static Controller command;
    private static String hcProfName;
    private Long ccpId;

    public ViewEncounter(String name) {
        super(name);
        command = Controller.getInstance();

        List<PlannedHCitemEntity> hcItems;
        top = new DefaultMutableTreeNode("HC Items");
        hcItemsTree = new JTree(top);
        model = (DefaultTreeModel) hcItemsTree.getModel();
        hcItemsTree.setRootVisible(false);
        hcItemsTree.setShowsRootHandles(true);
        model = (DefaultTreeModel) hcItemsTree.getModel();
        groupP = new DefaultMutableTreeNode("Procedures", true);
        model.insertNodeInto(groupP, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupQualObs = new DefaultMutableTreeNode("Qualitative Observations", true);
        model.insertNodeInto(groupQualObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupQuanObs = new DefaultMutableTreeNode("Quantitative Observations", true);
        model.insertNodeInto(groupQuanObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupPh = new DefaultMutableTreeNode("Pharmacotherapy", true);
        model.insertNodeInto(groupPh, top, top.getChildCount());
        model.nodeStructureChanged(top);

        hcItemsTree.addMouseListener(new HCItemJTreeDoubleClickAction(hcItemsTree));
        initComponents();
        // CCPStr ccp = (CCPStr) CustomizedCarePlansFrame.getCcps_list().getSelectedValue();
        if (this.getTitle().equals("View Encounter")) {
            encounterStr = (EncounterStr) ViewEOC.getEncounters_list().getSelectedValue();

            ccpId = command.getCustomizedCarePlan(encounterStr.getId());
            getCode_tf().setText(encounterStr.getCode());
            getCode_tf().setEditable(false);
            getConsult_date_tf().setText(encounterStr.getConsult_date());
            getConsult_date_tf().setEditable(false);
            getConsult_time_tf().setText(encounterStr.getConsult_time());
            getConsult_time_tf().setEditable(false);
            getConsult_type_tf().setText(encounterStr.getConsult_type());
            getConsult_type_tf().setEditable(false);
        } else if (this.getTitle().equals("View HCService")) {
            CCPStr ccp = (CCPStr) CreateACL_for_CCP.getHcService_list().getSelectedValue();
            ccpId = ccp.getId();
        }


        if (ccpId != null) {
            hcProfName = command.getHCProfessionalNameOfCCP(ccpId); // initialize lay relationship attempt
            getHcProvider_tf().setText(hcProfName);
            getHcProvider_tf().setEditable(false);
            hcItems = command.getHCItemsOfCustomizedCarePlan(ccpId);
            if (hcItems != null) {
                retrieveHCItemTree(model, hcItems, groupP, groupQualObs, groupQuanObs, groupPh);
            }
        }




        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
            hcItemsTree.expandRow(i);
        }
        List<DefaultMutableTreeNode> groups = new ArrayList<DefaultMutableTreeNode>();
        groups.add(groupP);
        groups.add(groupQualObs);
        groups.add(groupQuanObs);
        groups.add(groupPh);
        removeUnusedGroups(model, groups);
    }

    public static void retrieveHCItemTree(DefaultTreeModel model, List<PlannedHCitemEntity> hcItems, DefaultMutableTreeNode groupP,
            DefaultMutableTreeNode groupQualObs, DefaultMutableTreeNode groupQuanObs, DefaultMutableTreeNode groupPh) {
        List<DefaultMutableTreeNode> groups = new ArrayList<DefaultMutableTreeNode>();
        DefaultMutableTreeNode pastProcedures = new DefaultMutableTreeNode("In the past", true);
        DefaultMutableTreeNode futureProcedures = new DefaultMutableTreeNode("In the future", true);

        DefaultMutableTreeNode pastQualObs = new DefaultMutableTreeNode("In the past", true);
        DefaultMutableTreeNode futureQualObs = new DefaultMutableTreeNode("In the future", true);

        DefaultMutableTreeNode pastQuanObs = new DefaultMutableTreeNode("In the past", true);
        DefaultMutableTreeNode futureQuanObs = new DefaultMutableTreeNode("In the future", true);

        DefaultMutableTreeNode pastPh = new DefaultMutableTreeNode("In the past", true);
        DefaultMutableTreeNode futurePh = new DefaultMutableTreeNode("In the future", true);

        groups.add(pastProcedures);
        groups.add(futureProcedures);
        groupP.add(pastProcedures);
        groupP.add(futureProcedures);

        groupQuanObs.add(pastQuanObs);
        groupQuanObs.add(futureQuanObs);
        groups.add(futureQuanObs);
        groups.add(pastQuanObs);

        groupQualObs.add(pastQualObs);
        groupQualObs.add(futureQualObs);
        groups.add(futureQualObs);
        groups.add(pastQualObs);

        groupPh.add(pastPh);
        groups.add(pastPh);
        groupPh.add(futurePh);
        groups.add(futurePh);

        List<MedicineEntity> medicines;
        if (!hcItems.isEmpty()) {
            for (PlannedHCitemEntity phciI : hcItems) {
                if (phciI instanceof PlannedProcedureEntity) {
                    PlannedProcedureEntity phci = (PlannedProcedureEntity) phciI;
                    Procedure procedure = new Procedure();
                    procedure.setName(phci.getName());
                    procedure.setCode(phci.getCode());
                    procedure.setDateOp(phci.getDateOp());
                    procedure.setStateHCI(phci.getStateHCI());
                    procedure.setTimeOp(phci.getTimeOp());
                    procedure.setNotes(phci.getNotes());
                    procedure.setId(phci.getId());
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(procedure, false);
                    if (phci.getStateHCI().equals("past")) {
                        pastProcedures.add(item);
                    } else if (phci.getStateHCI().equals("future")) {
                        futureProcedures.add(item);

                    }
                }
                if (phciI instanceof QualitativeObservationEntity) {
                    QualitativeObservationEntity phci = (QualitativeObservationEntity) phciI;
                    QualObs qualObs = new QualObs();
                    qualObs.setName(phci.getName());
                    qualObs.setCode(phci.getCode());
                    qualObs.setDateOp(phci.getDateOp());
                    qualObs.setStateHCI(phci.getStateHCI());
                    qualObs.setTimeOp(phci.getTimeOp());
                    qualObs.setNotes(phci.getNotes());
                    qualObs.setDescription(phci.getDescription());
                    qualObs.setId(phci.getId());
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(qualObs, false);
                    if (phci.getStateHCI().equals("past")) {
                        pastQualObs.add(item);
                    } else if (phci.getStateHCI().equals("future")) {
                        futureQualObs.add(item);
                    }
                }
                if (phciI instanceof QuantitativeObservationEntity) {
                    QuantitativeObservationEntity phci = (QuantitativeObservationEntity) phciI;
                    QuanObs quanObs = new QuanObs();
                    quanObs.setName(phci.getName());
                    quanObs.setCode(phci.getCode());
                    quanObs.setDateOp(phci.getDateOp());
                    quanObs.setStateHCI(phci.getStateHCI());
                    quanObs.setTimeOp(phci.getTimeOp());
                    quanObs.setMeasurementQ(phci.getMeasurementQ());
                    quanObs.setDescription(phci.getDescription());
                    quanObs.setId(phci.getId());
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(quanObs, false);
                    if (phci.getStateHCI().equals("past")) {
                        pastQuanObs.add(item);
                    } else if (phci.getStateHCI().equals("future")) {
                        futureQuanObs.add(item);
                    }

                }
                if (phciI instanceof PlannedPharmacotherapyEntity) {
                    PlannedPharmacotherapyEntity phci = (PlannedPharmacotherapyEntity) phciI;
                    Pharmacotherapy pharmacotherapy = new Pharmacotherapy();
                    pharmacotherapy.setId(phci.getId());
                    pharmacotherapy.setName(phci.getName());
                    pharmacotherapy.setDateOp(phci.getDateOp());
                    pharmacotherapy.setStateHCI(phci.getStateHCI());
                    pharmacotherapy.setTimeOp(phci.getTimeOp());
                    medicines = command.getMedicinesOfPharmacotherapy(phci.getId());
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(pharmacotherapy, false);
                    if (phci.getStateHCI().equals("past")) {
                        pastPh.add(item);
                    } else if (phci.getStateHCI().equals("future")) {
                        futurePh.add(item);
                    }

                    if (!medicines.isEmpty()) {
                        for (MedicineEntity m : medicines) {
                            MedicineS med = new MedicineS();
                            med.setCode(m.getCode());
                            med.setName(m.getName());
                            med.setDose(m.getDose());
                            med.setStrength(m.getStrength());
                            med.setHowTaken(m.getHowTaken());
                            med.setReasonForTaking(m.getReasonForTaking());
                            med.setDateStarted(m.getDateStarted());
                            med.setDateStopped(m.getDateStopped());
                            med.setPrice(m.getPrice());
                            med.setPriceUnit(m.getPriceUnit());
                            med.setId(m.getId());
                            pharmacotherapy.getMedicines().add(med);
                        }
                    }
                }
            }
        }

        removeUnusedGroups(model, groups);

    }

    public static void removeUnusedGroups(DefaultTreeModel model, List<DefaultMutableTreeNode> groups) {
        for (DefaultMutableTreeNode group : groups) {
            if (group.getChildCount() == 0) {
                model.removeNodeFromParent(group);
            }
        }
    }

    public static JTextField getCode_tf() {
        return code_tf;
    }

    public static JTextField getConsult_date_tf() {
        return consult_date_tf;
    }

    public static JTextField getConsult_time_tf() {
        return consult_time_tf;
    }

    public static JTextField getConsult_type_tf() {
        return consult_type_tf;
    }

    public static JTextField getHcProvider_tf() {
        return hcProvider_tf;
    }

    public static String getHcProfName() {
        return hcProfName;
    }

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static JTree getHcItemsTree() {
        return hcItemsTree;
    }

    public JLabel getTitle_lb() {
        return title_lb;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        title_lb = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        code_tf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        consult_date_tf = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        consult_time_tf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        consult_type_tf = new javax.swing.JTextField();
        ok_bt = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        hcItems_tree = hcItemsTree;
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        hcProvider_tf = new javax.swing.JTextField();
        hcdetails_bt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_lb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_lb.setText("View  Encounter");

        jLabel2.setText("Code");

        jLabel3.setText("Consult Date");

        jLabel4.setText("Consult Time");

        jLabel5.setText("Consult Type");

        ok_bt.setText("close window");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(hcItems_tree);

        jLabel7.setText("Healthcare services, double click a healthcare service to see details");

        jLabel8.setText("HC Provider");

        hcdetails_bt.setText("View Healthcare Provider");
        hcdetails_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hcdetails_btActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(279, 279, 279)
                        .addComponent(title_lb))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(254, 254, 254)
                        .addComponent(ok_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(274, 274, 274))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(hcProvider_tf)
                        .addGap(83, 83, 83)
                        .addComponent(hcdetails_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(110, 110, 110))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(code_tf)
                            .addComponent(consult_time_tf)
                            .addComponent(consult_type_tf)
                            .addComponent(consult_date_tf, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(title_lb)
                .addGap(36, 36, 36)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(code_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(consult_date_tf)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(consult_time_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(consult_type_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(hcProvider_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(hcdetails_bt))
                .addGap(33, 33, 33)
                .addComponent(ok_bt)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed
        // TODO add your handling code here:

        this.setVisible(false);
    }//GEN-LAST:event_ok_btActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void hcdetails_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hcdetails_btActionPerformed
        // TODO add your handling code here:
        ViewDoctorDetails frame = new ViewDoctorDetails("View Healthcare Provider");
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);
    }//GEN-LAST:event_hcdetails_btActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewEncounter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewEncounter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewEncounter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewEncounter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewEncounter("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JTextField code_tf;
    private static javax.swing.JTextField consult_date_tf;
    private static javax.swing.JTextField consult_time_tf;
    private static javax.swing.JTextField consult_type_tf;
    private javax.swing.JTree hcItems_tree;
    private static javax.swing.JTextField hcProvider_tf;
    private javax.swing.JButton hcdetails_bt;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton ok_bt;
    private javax.swing.JLabel title_lb;
    // End of variables declaration//GEN-END:variables
}
