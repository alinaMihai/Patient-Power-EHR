/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.interfaces.ACL_for_CCP;

import ehr_patient.Controller;
import ehr_patient.interfaces.EpisodeOfCareFrame;
import ehr_patient.interfaces.ViewEncounter;
import ehr_patient.utils.CCPStr;
import ehr_patient.utils.EOCStr;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ListModel;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author Alina
 */
public class CreateACL_for_CCP extends javax.swing.JFrame {

    /**
     * Creates new form CreateACL_for_CCP
     */
    private String doctorName;
    private String userType;
    private boolean canView;
    private boolean canInsert;
    private boolean canUpdate;
    private boolean canDelete;
    private static Controller command;
    private static DefaultListModel ccp_listModel;
    private ArrayList<String> userTypes;
    private ArrayList<Long> users;

    public CreateACL_for_CCP(String name) {
        super(name);
        command = Controller.getInstance();
        ccp_listModel = new DefaultListModel();
        initComponents();
        DefaultMutableTreeNode selectedEOCNode = (DefaultMutableTreeNode) EpisodeOfCareFrame.getEOCTree().getLastSelectedPathComponent();
        EOCStr selectedEOC = (EOCStr) selectedEOCNode.getUserObject();
        List<Long> ccpIds = command.getCCPsofEOC(selectedEOC.getId());
        if (!ccpIds.isEmpty()) {
            for (Long ccpId : ccpIds) {
                try {
                    ArrayList<String> ccpDetails = (ArrayList<String>) command.getCCPDetails(ccpId);
                    CCPStr ccp = new CCPStr();
                    ccp.setId(ccpId);
                    ccp.setEncounter_type(ccpDetails.get(0));
                    ccp.setEncounter_date(ccpDetails.get(1));
                    ccp.setEncounter_time(ccpDetails.get(2));
                    ccp.setEncounter_code(ccpDetails.get(3));
                    ccp.setEncounter_id(Long.parseLong(ccpDetails.get(4)));
                    ccp_listModel.addElement(ccp);

                } catch (Exception ex) {
                    Logger.getLogger(CreateACL_for_CCP.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        hcService_list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = hcService_list.locationToIndex(e.getPoint());
                    ListModel dlm = hcService_list.getModel();
                    CCPStr item = (CCPStr) dlm.getElementAt(index);
                    hcService_list.ensureIndexIsVisible(index);
                    ViewEncounter frame = new ViewEncounter("View HCService");
                    ViewEncounter.getCode_tf().setText(item.getEncounter_code());
                    frame.getTitle_lb().setText(item.getEncounter_type());
                    ViewEncounter.getConsult_type_tf().setText(item.getEncounter_type());
                    ViewEncounter.getConsult_time_tf().setText(item.getEncounter_time());
                    ViewEncounter.getConsult_date_tf().setText(item.getEncounter_date());
                    ViewEncounter.getCode_tf().setEditable(false);
                    ViewEncounter.getConsult_date_tf().setEditable(false);
                    ViewEncounter.getConsult_time_tf().setEditable(false);
                    ViewEncounter.getConsult_type_tf().setEditable(false);
                    frame.setResizable(false);
                    frame.setLocationRelativeTo(null);
                    frame.setVisible(true);
                }

            }
        });



        userTypes = (ArrayList<String>) command.getUserTypes();
        if (userTypes != null) {

            for (String ut : userTypes) {
                userType_cb.addItem(ut);
            }
        }
        userType_cb.setSelectedItem(null);
        userType_cb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JComboBox cb = (JComboBox) ae.getSource();
                userType = (String) cb.getSelectedItem();
                user_cb.setSelectedItem(null);
                userType_cb.setSelectedItem(userType);
            }
        });
        users = (ArrayList<Long>) command.getDoctorUsers();
        if (users != null) {
            for (Long u : users) {
                Long doctorId = command.getUserDoctorId(u);
                String adoctorName = command.findDoctorName(doctorId);
                user_cb.addItem(adoctorName);
            }
        }
        user_cb.setSelectedItem(null);
        user_cb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JComboBox cb = (JComboBox) ae.getSource();
                doctorName = (String) cb.getSelectedItem();
                userType_cb.setSelectedItem(null);
                user_cb.setSelectedItem(doctorName);

            }
        });



        canView_checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb = (JCheckBox) ae.getSource();
                canView = (boolean) cb.isSelected();
            }
        });
        canInsert_checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb = (JCheckBox) ae.getSource();
                canInsert = (boolean) cb.isSelected();
            }
        });
        canUpdate_checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb = (JCheckBox) ae.getSource();
                canUpdate = (boolean) cb.isSelected();
            }
        });
        canDelete_checkbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JCheckBox cb = (JCheckBox) ae.getSource();
                canDelete = (boolean) cb.isSelected();
            }
        });



    }

    public void setData() {
        canView = canView_checkbox.isSelected();
        canInsert = canInsert_checkbox.isSelected();
        canUpdate = canUpdate_checkbox.isSelected();
        canDelete = canDelete_checkbox.isSelected();
        doctorName = (String) user_cb.getSelectedItem();
        userType = (String) userType_cb.getSelectedItem();
    }

    public static JList getHcService_list() {
        return hcService_list;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        user_cb = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        userType_cb = new javax.swing.JComboBox();
        canView_checkbox = new javax.swing.JCheckBox();
        canInsert_checkbox = new javax.swing.JCheckBox();
        canUpdate_checkbox = new javax.swing.JCheckBox();
        canDelete_checkbox = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        hcService_list = new javax.swing.JList(ccp_listModel);
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Create Access Control List");

        jLabel2.setText("User");

        jLabel3.setText("User Group");

        canView_checkbox.setText("can View");
        canView_checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                canView_checkboxActionPerformed(evt);
            }
        });

        canInsert_checkbox.setText("can Insert");

        canUpdate_checkbox.setText("can Update");

        canDelete_checkbox.setText("can Delete");

        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(hcService_list);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("or");

        jLabel5.setText("Choose a user or a user group");

        jLabel6.setText("Select a hcService");

        jLabel7.setText("Allow rights");

        jLabel8.setText("Double click a Healthcare service to see details");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(jLabel4))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2))
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(canDelete_checkbox)
                                    .addComponent(canUpdate_checkbox)
                                    .addComponent(canInsert_checkbox)
                                    .addComponent(canView_checkbox)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(user_cb, 0, 169, Short.MAX_VALUE)
                                        .addComponent(userType_cb, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5)
                                .addComponent(jLabel8))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(140, 140, 140)
                        .addComponent(jLabel1)))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addGap(7, 7, 7)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(user_cb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jLabel4)
                .addGap(1, 1, 1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(userType_cb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(canView_checkbox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(canInsert_checkbox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(canUpdate_checkbox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(canDelete_checkbox)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void canView_checkboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_canView_checkboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_canView_checkboxActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        setData();
        Long userTypeId;
        Long userId = command.userIdByDoctorName(doctorName);
        CCPStr ccp = (CCPStr) hcService_list.getSelectedValue();

        if (userType != null) {
            userTypeId = command.getUserTypeId(userType);
            Long aclId = command.createACL(userTypeId, canView, canInsert, canUpdate, canDelete);
            command.addACLtoCCP(ccp.getId(), aclId);
            JOptionPane.showMessageDialog(null, "Access controll list successfully created");
        } else {
            try {
                Long aclId = command.createACLforUser(userId, canView, canInsert, canUpdate, canDelete);
                command.addACLtoCCP(ccp.getId(), aclId);
            } catch (Exception ex) {
                Logger.getLogger(CreateACL_for_CCP.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Access control list successfully created");
        }

    }//GEN-LAST:event_jButton1ActionPerformed
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;


                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CreateACL_for_CCP.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CreateACL_for_CCP.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CreateACL_for_CCP.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CreateACL_for_CCP.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CreateACL_for_CCP("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox canDelete_checkbox;
    private javax.swing.JCheckBox canInsert_checkbox;
    private javax.swing.JCheckBox canUpdate_checkbox;
    private javax.swing.JCheckBox canView_checkbox;
    private static javax.swing.JList hcService_list;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox userType_cb;
    private javax.swing.JComboBox user_cb;
    // End of variables declaration//GEN-END:variables
}
