/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ehr_patient.interfaces;

import ehr_patient.Controller;
import ehr_patient.utils.ACLTreeAction;
import ehr_patient.utils.ACLstr;
import ehr_patient.utils.EOCStr;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

/**
 *
 * @author Alina
 */
public class ACLsOfEOC extends javax.swing.JFrame {

    private static Controller command;
    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    protected static JTree aclsTree;

    /**
     * Creates new form ACLsOfEOC
     */
    public ACLsOfEOC(String name) {
        super(name);
        command = Controller.getInstance();

        //   acl_list.addMouseListener(new ACLTreeAction(acl_list));
        top = new DefaultMutableTreeNode("ACLs");
        aclsTree = new JTree(top);
        model = (DefaultTreeModel) aclsTree.getModel();
        aclsTree.setRootVisible(false);
        aclsTree.setShowsRootHandles(true);

        aclsTree.addMouseListener(new ACLTreeAction(aclsTree));
        initComponents();
        DefaultMutableTreeNode selectedEOC = (DefaultMutableTreeNode) EpisodeOfCareFrame.getEOCTree().getLastSelectedPathComponent();
        EOCStr eoc = (EOCStr) selectedEOC.getUserObject();
        Long eocId = eoc.getId();

        List<Long> ccpIds = command.getCCPsofEOC(eocId);
        if (!ccpIds.isEmpty()) {
            for (Long ccpId : ccpIds) {
                try {
                    List<Long> acls = command.getACLsOfCCP(ccpId);
                    if (!acls.isEmpty()) {
                        ArrayList<String> ccpDetails = (ArrayList<String>) command.getCCPDetails(ccpId);
                        for (Long aclId : acls) {
                            ACLstr aclstr = new ACLstr();
                            aclstr.setId(aclId);
                            aclstr.setEncounterType(ccpDetails.get(0));
                            aclstr.setEncounterDate(ccpDetails.get(1));
                            List<String> aclDetails = command.getACLDetails(aclId);
                            if (!aclDetails.isEmpty()) {
                                if (!aclDetails.get(0).equals("null")) {
                                    aclstr.setUsername(aclDetails.get(0));
                                } else if (!aclDetails.get(1).equals("null")) {
                                    aclstr.setUserType(aclDetails.get(1));
                                }
                                aclstr.setCanView(Boolean.parseBoolean(aclDetails.get(2)));
                                aclstr.setCanInsert(Boolean.parseBoolean(aclDetails.get(3)));
                                aclstr.setCanDelete(Boolean.parseBoolean(aclDetails.get(4)));
                                aclstr.setCanUpdate(Boolean.parseBoolean(aclDetails.get(5)));
                                DefaultMutableTreeNode aclNode = new DefaultMutableTreeNode(aclstr, false);
                                //top.add(aclNode);
                                model.insertNodeInto(aclNode, top, top.getChildCount());
                                model.nodeStructureChanged(top);

                            }
                        }
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "There are no acls");
                }
            }
        }

        List<Long> acls = command.getACLsOfEOC(eocId);


        if (!acls.isEmpty()) {
            for (Long aclId : acls) {
                ACLstr aclstr = new ACLstr();
                aclstr.setId(aclId);
                List<String> aclDetails = command.getACLDetails(aclId);
                if (!aclDetails.isEmpty()) {
                    if (!aclDetails.get(0).equals("null")) {
                        aclstr.setUsername(aclDetails.get(0));
                    } else if (!aclDetails.get(1).equals("null")) {
                        aclstr.setUserType(aclDetails.get(1));
                    }
                    aclstr.setCanView(Boolean.parseBoolean(aclDetails.get(2)));
                    aclstr.setCanInsert(Boolean.parseBoolean(aclDetails.get(3)));
                    aclstr.setCanDelete(Boolean.parseBoolean(aclDetails.get(4)));
                    aclstr.setCanUpdate(Boolean.parseBoolean(aclDetails.get(5)));
                    DefaultMutableTreeNode aclNode = new DefaultMutableTreeNode(aclstr, false);

                    model.insertNodeInto(aclNode, top, top.getChildCount());
                    model.nodeStructureChanged(top);
                    //top.add(aclNode);

                    // acl_listModel.addElement(aclstr);
                }
            }
        }
        for (int i = 0; i < aclsTree.getRowCount(); i++) {
            aclsTree.expandRow(i);
        }

    }

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static JTree getAclsTree() {
        return aclsTree;
    }

    public JLabel getTitle_lb() {
        return title_lb;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        title_lb = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTree1 = aclsTree;
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_lb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_lb.setText("  Title");

        jButton1.setText("close window");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(jTree1);

        jLabel2.setText("right click an Access Control List to see options");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 497, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(167, 167, 167)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(title_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(title_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ACLsOfEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ACLsOfEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ACLsOfEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ACLsOfEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ACLsOfEOC("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTree jTree1;
    private javax.swing.JLabel title_lb;
    // End of variables declaration//GEN-END:variables
}
