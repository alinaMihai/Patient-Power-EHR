/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package episodeofcareprj;

import com.digitprop.tonic.TonicLookAndFeel;
import javax.swing.JFrame;
import javax.swing.JRootPane;
import javax.swing.UIManager;

/**
 *
 * @author Alina
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // String lookAndFeel = "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel";
        try {

            /*    WebLookAndFeel wlaf = new WebLookAndFeel();
             UIManager.setLookAndFeel(wlaf);
             */
            UIManager.setLookAndFeel(new TonicLookAndFeel());
            JFrame.setDefaultLookAndFeelDecorated(true);
            //  
            //   UIManager.setLookAndFeel(new com.nilo.plaf.nimrod.NimRODLookAndFeel());
          /*  NimRODTheme nt = new NimRODTheme();
             nt.setOpacity(255);
             UIManager.put("NimROD.dialog.icon.enabled", true);      
             NimRODLookAndFeel NimRODLF = new NimRODLookAndFeel();
             NimRODLookAndFeel.setCurrentTheme(nt);
             UIManager.setLookAndFeel(NimRODLF);
             */
        } catch (Exception e) {
            System.out.println("L&F isn't available");
        }
        Login frame = new Login("Login");

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }
}
