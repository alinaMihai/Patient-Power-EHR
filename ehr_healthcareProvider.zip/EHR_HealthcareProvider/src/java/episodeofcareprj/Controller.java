/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package episodeofcareprj;

import doctor_ws.AccessControlListEntity;
import doctor_ws.PlannedPharmacotherapyEntity;
import java.util.List;

/**
 *
 * @author Alina
 */
public class Controller {

    doctor_ws.DoctorWebService_Service service = new doctor_ws.DoctorWebService_Service();
    doctor_ws.DoctorWebService port = service.getDoctorWebServicePort();
    hcwebservices.ViewEOCWebService_Service service_view = new hcwebservices.ViewEOCWebService_Service();
    hcwebservices.ViewEOCWebService port_view = service_view.getViewEOCWebServicePort();
    hcwebservices.DeleteEOCWebService_Service service_delete = new hcwebservices.DeleteEOCWebService_Service();
    hcwebservices.DeleteEOCWebService port_delete = service_delete.getDeleteEOCWebServicePort();
    hcwebservices.EditEOCWebService_Service service_edit = new hcwebservices.EditEOCWebService_Service();
    hcwebservices.EditEOCWebService port_edit = service_edit.getEditEOCWebServicePort();

    private static class SingletonHolder {

        private static final Controller INSTANCE = new Controller();
    }

    public static Controller getInstance() {
        return SingletonHolder.INSTANCE;
    }

    public void addDisease(java.lang.Long eocId, java.lang.Long diseaseId) {
        port.addDisease(eocId, diseaseId);
    }

    public Long addEncounter(java.lang.String code, java.lang.Long patientId, java.lang.Long doctorId, java.lang.Long orgId, java.lang.String consultDate, java.lang.String consultTime, java.lang.String consultType) {
        return port.addEncounter(code, patientId, doctorId, orgId, consultDate, consultTime, consultType);
    }

    public Long addGeneralCarePlan(java.lang.Long eoCid) {
        return port.addGeneralCarePlan(eoCid);
    }

    public PlannedPharmacotherapyEntity addGeneralPharmacotherapy(java.lang.Long generalCarePlanId, java.lang.String name) {
        return port.addGeneralPharmacotherapy(generalCarePlanId, name);
    }

    public void addGeneralProcedure(java.lang.Long generalCarePlanId, java.lang.String code, java.lang.String name, String notes) {
        port.addGeneralProcedure(generalCarePlanId, code, name, notes);
    }

    public void addGeneralQualitativeObservation(java.lang.Long generalCarePlanId, java.lang.String code, java.lang.String name, java.lang.String notes, java.lang.String description) {
        port.addGeneralQualitativeObservation(generalCarePlanId, code, name, notes, description);
    }

    public void addGeneralQuantitativeObservation(java.lang.Long generalCarePlanId, java.lang.String code, java.lang.String name, java.lang.String measurement, java.lang.String description) {
        port.addGeneralQuantitativeObservation(generalCarePlanId, code, name, measurement, description);
    }

    public Long addMedicine(java.lang.Long pharmacotherapyId, java.lang.String name, java.lang.String code, java.lang.String priceUnit, double price, java.lang.String strength, java.lang.String dose, java.lang.String howTaken, java.lang.String resonForTaking, java.lang.String dateStarted, java.lang.String dateStopped) {
        return port.addMedicine(pharmacotherapyId, name, code, priceUnit, price, strength, dose, howTaken, resonForTaking, dateStarted, dateStopped);
    }

    public Long addPharmacotherapy(java.lang.Long customizedCarePlanId, java.lang.String name,
            java.lang.String state, java.lang.String dateOp, java.lang.String timeOp) {
        return port.addPharmacotherapy(customizedCarePlanId, name, state, dateOp, timeOp);
    }

    public void addProcedure(java.lang.Long customizedCarePlanId, java.lang.String code, java.lang.String name,
            java.lang.String state, java.lang.String dateOp, java.lang.String timeOp, String notes) {
        port.addProcedure(customizedCarePlanId, code, name, state, dateOp, timeOp, notes);
    }

    public void addQualitativeObservation(java.lang.Long customizedCarePlanId, java.lang.String code,
            java.lang.String name, java.lang.String state, java.lang.String dateOp, java.lang.String timeOp, java.lang.String notes, java.lang.String description) {
        port.addQualitativeObservation(customizedCarePlanId, code, name, state, dateOp, timeOp, notes, description);
    }

    public void addQuantitativeObservation(java.lang.Long customizedCarePlanId, java.lang.String code,
            java.lang.String name, java.lang.String state, java.lang.String dateOp, java.lang.String timeOp, java.lang.String measurement, java.lang.String description) {
        port.addQuantitativeObservation(customizedCarePlanId, code, name, state, dateOp, timeOp, measurement, description);
    }

    public void addSymptom(java.lang.Long diseaseId, java.lang.Long symptomId) {
        port.addSymptom(diseaseId, symptomId);
    }

    public Long createDisease(java.lang.String diagnostic) {
        return port.createDisease(diagnostic);
    }

    public Long createEOC(java.lang.String startdate, java.lang.String starttime, java.lang.String enddate, java.lang.String endtime, java.lang.String code) {
        return port.createEOC(startdate, starttime, enddate, endtime, code);
    }

    public Long createSymptom(java.lang.String name, java.lang.String description, java.lang.String frequency, java.lang.String status, java.lang.String apperance, java.lang.String disapperance) {
        return port.createSymptom(name, description, frequency, status, apperance, disapperance);
    }

    public java.util.List<java.lang.String> getDiagnostics() {
        return port.getDiagnostics();
    }

    public java.util.List<doctor_ws.PlannedHCitemEntity> getGeneralHCItemsOfDisease(java.lang.String diagnostic) {
        return port.getGeneralHCItemsOfDisease(diagnostic);
    }

    public java.util.List<doctor_ws.MedicineEntity> getMedicinesOfPharmacotherapy(java.lang.Long pharmacotherapyId) {
        return port.getMedicinesOfPharmacotherapy(pharmacotherapyId);
    }

    public java.util.List<Long> getPatients() {
        doctor_ws.DoctorWebService_Service service3 = new doctor_ws.DoctorWebService_Service();
        doctor_ws.DoctorWebService port3 = service3.getDoctorWebServicePort();
        return port3.getPatients();
    }

    public Long login(java.lang.String username, java.lang.String password) {
        return port.login(username, password);
    }

    public Long getUserDoctorId(java.lang.Long userId) {
        return port_view.getUserDoctorId(userId);
    }

    public java.util.List<java.lang.String> getPatientInfo(java.lang.Long patientId) {
        return port.getPatientInfo(patientId);
    }

    public Long getHCOrgIdOfDoctor(java.lang.Long doctorId) {
        return port.getHCOrgIdOfDoctor(doctorId);
    }

    public Long getCustomizedCarePlan(java.lang.Long encounterId) {
        return port_view.getCustomizedCarePlan(encounterId);
    }

    public java.util.List<hcwebservices.ContactEntity> getEncountersOfPatient(java.lang.Long patientId) {
        return port_view.getEncountersOfPatient(patientId);
    }

    public Long createACLforUser(java.lang.Long userEntityId, boolean canView, boolean canInsert, boolean canUpdate, boolean canDelete) {
        return port_view.createACLforUser(userEntityId, canView, canInsert, canUpdate, canDelete);
    }

    public void addACLtoEOC(java.lang.Long eocId, java.lang.Long aclId) {
        port_view.addACLtoEOC(eocId, aclId);
    }

    public AccessControlListEntity getByUserAndEOC(java.lang.Long userId, java.lang.Long eocId) {
        return port.getByUserAndEOC(userId, eocId);
    }

    public AccessControlListEntity getByUserTypeAndEOC(java.lang.Long userTypeId, java.lang.Long eocId) {
        return port.getByUserTypeAndEOC(userTypeId, eocId);
    }

    public java.util.List<java.lang.Long> getEOCsOfPatient(java.lang.Long patientId) {
        return port_view.getEOCsOfPatient(patientId);
    }

    public java.util.List<java.lang.String> getEOCDetails(java.lang.Long eocId) {
        return port.getEOCDetails(eocId);
    }

    public Long getUserTypeIdofUser(java.lang.Long userId) {
        return port.getUserTypeIdofUser(userId);
    }

    public java.util.List<doctor_ws.SymptomEntity> getGeneralSymptomsOfDisease(java.lang.String diagnostic) {
        return port.getGeneralSymptomsOfDisease(diagnostic);
    }

    public java.util.List<java.lang.Long> getEncounterOfEOC(java.lang.Long eocId) {
        return port.getEncounterOfEOC(eocId);
    }

    public java.util.List<java.lang.String> getEncounterDetails(java.lang.Long encounterId) {
        return port.getEncounterDetails(encounterId);
    }

    public java.util.List<doctor_ws.PlannedHCitemEntity> getHCItemsOfCustomizedCarePlan(java.lang.Long ccpId) {
        return port.getHCItemsOfCustomizedCarePlan(ccpId);
    }

    public java.util.List<doctor_ws.SymptomEntity> getSymptomsOfDisease(java.lang.Long diseaseId) {
        return port.getSymptomsOfDisease(diseaseId);
    }

    public List<String> getPatientNames() {
        return port.getPatientNames();
    }

    public String getHCProfessionalNamebyUserId(java.lang.Long userId) {
        return port.getHCProfessionalNamebyUserId(userId);
    }

    public java.util.List<java.lang.String> getHCProfessionalDetailsByHCProfessionalName(java.lang.String hcProfessionalName) {
        return port_view.getHCProfessionalDetailsByHCProfessionalName(hcProfessionalName);
    }

    public int deleteEOC(java.lang.Long eocId) {
        return port_delete.deleteEOC(eocId);
    }

    public Long addCustomizedCarePlan(java.lang.Long eocId, java.lang.Long hcProviderId, java.lang.Long contactId) {
        return port.addCustomizedCarePlan(eocId, hcProviderId, contactId);
    }

    public String getHCProfessionalNameOfCCP(java.lang.Long ccpId) {
        return port.getHCProfessionalNameOfCCP(ccpId);
    }

    public void editEncounter(java.lang.Long encounterId, java.lang.String code, java.lang.String consultDate, java.lang.String consultTime, java.lang.String consultType) {
        port_edit.editEncounter(encounterId, code, consultDate, consultTime, consultType);
    }

    public void updateEOC(java.lang.Long eocId, java.lang.String startdate, java.lang.String starttime, java.lang.String enddate, java.lang.String endtime, java.lang.String code) {
        port_edit.updateEOC(eocId, startdate, starttime, enddate, endtime, code);
    }

    public void updateMedicine(java.lang.Long medId, java.lang.String name, java.lang.String code, java.lang.String priceUnit, double price, java.lang.String strength, java.lang.String dose, java.lang.String howTaken, java.lang.String resonForTaking, java.lang.String dateStarted, java.lang.String dateStopped) {
        port_edit.updateMedicine(medId, name, code, priceUnit, price, strength, dose, howTaken, resonForTaking, dateStarted, dateStopped);
    }

    public void updatePharmacotherapy(java.lang.Long phId, java.lang.String name, java.lang.String state, java.lang.String dateOp, java.lang.String timeOp) {
        port_edit.updatePharmacotherapy(phId, name, state, dateOp, timeOp);
    }

    public void updateProcedure(java.lang.Long procedureId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String dateOp, java.lang.String timeOp, java.lang.String notes) {
        port_edit.updateProcedure(procedureId, code, name, state, dateOp, timeOp, notes);
    }

    public void updateQualitativeObservation(java.lang.Long qualObsId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String dateOp, java.lang.String timeOp, java.lang.String notes, java.lang.String description) {
        port_edit.updateQualitativeObservation(qualObsId, code, name, state, dateOp, timeOp, notes, description);
    }

    public void updateQuantitativeObservation(java.lang.Long quanObsId, java.lang.String code, java.lang.String name, java.lang.String state, java.lang.String dateOp, java.lang.String timeOp, java.lang.String measurement, java.lang.String description) {
        port_edit.updateQuantitativeObservation(quanObsId, code, name, state, dateOp, timeOp, measurement, description);
    }

    public void updateSymptom(java.lang.Long symptomId, java.lang.String name, java.lang.String description, java.lang.String frequency, java.lang.String status, java.lang.String apperance, java.lang.String disapperance) {
        port_edit.updateSymptom(symptomId, name, description, frequency, status, apperance, disapperance);
    }

    public void deleteEncounter(java.lang.Long encounterId) {
        port_delete.deleteEncounter(encounterId);
    }

    public void deleteMedicine(java.lang.Long medId) {
        port_delete.deleteMedicine(medId);
    }

    public void deletePharmacotherapy(java.lang.Long phId) {
        port_delete.deletePharmacotherapy(phId);
    }

    public void deleteProcedure(java.lang.Long procedureId) {
        port_delete.deleteProcedure(procedureId);
    }

    public void deleteQualObs(java.lang.Long qualObsId) {
        port_delete.deleteQualObs(qualObsId);
    }

    public void deleteQuanObs(java.lang.Long quanObsId) {
        port_delete.deleteQuanObs(quanObsId);
    }

    public void deleteSymptom(java.lang.Long symptomid) {
        port_delete.deleteSymptom(symptomid);
    }

    public java.util.List<java.lang.Long> getPatientsOfDoctor(java.lang.Long doctorId) {
        return port.getPatientsOfDoctor(doctorId);
    }

    public java.util.List<java.lang.Long> getGeneralCarePlans() {
        return port.getGeneralCarePlans();
    }

    public String getDiagnosticOfGCP(java.lang.Long gcpId) {
        return port.getDiagnosticOfGCP(gcpId);
    }

    public Long getDiseaseIdOfDiagnostic(java.lang.String diagnostic) {
        return port.getDiseaseIdOfDiagnostic(diagnostic);
    }

    public void deleteGeneralCarePlan(java.lang.Long gcpId) {
        port_delete.deleteGeneralCarePlan(gcpId);
    }

    public AccessControlListEntity getByUserAndCCP(java.lang.Long userId, java.lang.Long ccpId) {
        return port.getByUserAndCCP(userId, ccpId);
    }

    public AccessControlListEntity getByUserTypeAndCCP(java.lang.Long userTypeId, java.lang.Long ccpId) {
        return port.getByUserTypeAndCCP(userTypeId, ccpId);
    }

    public java.util.List<java.lang.Long> getCCPsofEOC(java.lang.Long eocId) {
        return port_view.getCCPsofEOC(eocId);
    }

    public java.util.List<java.lang.String> getCCPDetails(java.lang.Long ccpId) {
        return port_view.getCCPDetails(ccpId);
    }

    public void deleteCCP(java.lang.Long ccpId) {
        port_delete.deleteCCP(ccpId);
    }

}
