/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.addEncounterToEOC;

import doctor_ws.PlannedHCitemEntity;
import episodeofcareprj.Controller;
import episodeofcareprj.Login;
import interfaces.EditEOC.EditEOC;
import interfaces.ViewEOC.EpisodeOfCareFrame;
import interfaces.ViewEOC.PatientsFrame;
import interfaces.addEOC.AddEOC;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import utils.Add_In_HCItemJTreeAction;
import utils.EOCStr;
import utils.HCItemJTreeDoubleClickAction;
import utils.MedicineS;
import utils.PatientStr;
import utils.Pharmacotherapy;
import utils.Procedure;
import utils.QualObs;
import utils.QuanObs;

/**
 *
 * @author Alina
 */
public class AddEncounterToEOCframe extends javax.swing.JFrame {

    /**
     * Creates new form ViewEncounter
     */
    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    private static JTree hcItemsTree;
    private static DefaultMutableTreeNode groupP;
    private static DefaultMutableTreeNode groupO;
    private static DefaultMutableTreeNode groupPh;
    private static DefaultMutableTreeNode groupQualObs;
    private static DefaultMutableTreeNode groupQuanObs;
    private static Controller command;
    private String code;
    private String date_c;
    private String time_c;
    private String type_c;
    private static Long encounterId;
    private static Long customizedCarePlanId;
    private DefaultMutableTreeNode selectedEOCNode;
    private EOCStr eoc;
    private Long eocId;
    private String diagnostic;

    public AddEncounterToEOCframe(String name) {
        super(name);
        command = Controller.getInstance();
        List<PlannedHCitemEntity> hcItems;
        top = new DefaultMutableTreeNode("HC Items");
        hcItemsTree = new JTree(top);
        hcItemsTree.addMouseListener(new HCItemJTreeDoubleClickAction(hcItemsTree));
        hcItemsTree.addMouseListener(new Add_In_HCItemJTreeAction(hcItemsTree));
        model = (DefaultTreeModel) hcItemsTree.getModel();
        hcItemsTree.setRootVisible(false);
        hcItemsTree.setShowsRootHandles(true);
        groupP = new DefaultMutableTreeNode("Procedures", true);
        model.insertNodeInto(groupP, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupQualObs = new DefaultMutableTreeNode("Qualitative Observations", true);
        model.insertNodeInto(groupQualObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupQuanObs = new DefaultMutableTreeNode("Quantitative Observations", true);
        model.insertNodeInto(groupQuanObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupPh = new DefaultMutableTreeNode("Pharmacotherapy", true);
        model.insertNodeInto(groupPh, top, top.getChildCount());
        model.nodeStructureChanged(top);

        if (this.getTitle().equals("Add New Encounter") || this.getTitle().equals("Edit:Add Encounter")) {
            selectedEOCNode = (DefaultMutableTreeNode) EpisodeOfCareFrame.getEOCTree().getLastSelectedPathComponent();
            eoc = (EOCStr) selectedEOCNode.getUserObject();
            eocId = eoc.getId();
            diagnostic = eoc.getDiagnostic();
        }
        if (this.getTitle().equals("Add Encounter")) {
            eocId = AddEOC.getEocId();
            diagnostic = AddEOC.getDiagnostic();
        }
        hcItems = command.getGeneralHCItemsOfDisease(diagnostic);
        try {
            utils.Utils.retrieveHCItemTree(model, hcItems, groupP, groupQualObs, groupQuanObs, groupPh, " general,double click to change");
        } catch (Exception ex) {
            Logger.getLogger(AddEncounterToEOCframe.class.getName()).log(Level.SEVERE, null, ex);
        }

        initComponents();

        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
            hcItemsTree.expandRow(i);
        }
    }

    public void setData() {
        code = code_tf.getText();
        date_c = consult_date_tf.getText();
        time_c = consult_time_tf.getText();
        type_c = consult_type_tf.getText();
    }

    public static JTree getHcItemsTree() {
        return hcItemsTree;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static DefaultMutableTreeNode getGroupP() {
        return groupP;
    }

    public static DefaultMutableTreeNode getGroupPh() {
        return groupPh;
    }

    public static DefaultMutableTreeNode getGroupQualObs() {
        return groupQualObs;
    }

    public static DefaultMutableTreeNode getGroupQuanObs() {
        return groupQuanObs;
    }

    public static JTextField getCode_tf() {
        return code_tf;
    }

    public static JTextField getConsult_date_tf() {
        return consult_date_tf;
    }

    public static JTextField getConsult_time_tf() {
        return consult_time_tf;
    }

    public static JTextField getConsult_type_tf() {
        return consult_type_tf;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        code_tf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        consult_date_tf = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        consult_time_tf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        consult_type_tf = new javax.swing.JTextField();
        ok_bt = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        hcItems_tree = hcItemsTree;
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Add  Encounter");

        jLabel2.setText("Code");

        jLabel3.setText("Consult Date*");

        jLabel4.setText("Consult time");

        jLabel5.setText("Consult Type");

        ok_bt.setText("OK");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        jLabel6.setText("Healthcare services*");

        jScrollPane2.setViewportView(hcItems_tree);

        jButton1.setText("Cancel");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel7.setText("Right click a group to add new healthcare service");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ok_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(309, 309, 309)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 493, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel6)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(consult_type_tf, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE)
                                        .addComponent(consult_time_tf, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(consult_date_tf, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(code_tf, javax.swing.GroupLayout.Alignment.LEADING))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(294, 294, 294)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(68, 68, 68)))
                .addGap(124, 124, 124))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(31, 31, 31)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addGap(19, 19, 19)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(code_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(consult_date_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(consult_time_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(consult_type_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ok_bt)
                    .addComponent(jButton1))
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void addHCItemsToEncounter(DefaultMutableTreeNode top, Long customizedCarePlanId) {
        if (hcItemsTree.getRowCount() > 1) {
            for (int i = 0; i < top.getChildCount(); i++) {
                DefaultMutableTreeNode groupNode = (DefaultMutableTreeNode) top.getChildAt(i);
                String group = (String) groupNode.getUserObject();
                if (group.equals("Procedures")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode procedureNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        Procedure p = (Procedure) procedureNode.getUserObject();
                        if (p.isAdd()) {
                            command.addProcedure(customizedCarePlanId, p.getCode(), p.getName(), p.getStateHCI(),
                                    p.getDateOp(), p.getTimeOp(), p.getNotes());
                        }
                    }
                }

                if (group.equals("Qualitative Observations")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode qqNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        QualObs qq = (QualObs) qqNode.getUserObject();
                        if (qq.isAdd()) {
                            command.addQualitativeObservation(customizedCarePlanId, qq.getCode(), qq.getName(), qq.getStateHCI(),
                                    qq.getDateOp(), qq.getTimeOp(), qq.getNotes(), qq.getDescription());
                        }
                    }
                }

                if (group.equals("Quantitative Observations")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode qqNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        QuanObs qq = (QuanObs) qqNode.getUserObject();
                        if (qq.isAdd()) {
                            command.addQuantitativeObservation(customizedCarePlanId, qq.getCode(), qq.getName(), qq.getStateHCI(),
                                    qq.getDateOp(), qq.getTimeOp(), qq.getMeasurementQ(), qq.getDescription());
                        }
                    }
                }

                if (group.equals("Pharmacotherapy")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode phNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        Pharmacotherapy ph = (Pharmacotherapy) phNode.getUserObject();
                        if (ph.isAdd()) {
                            Long pharmacotherapyId = command.addPharmacotherapy(customizedCarePlanId, ph.getName(),
                                    ph.getStateHCI(), ph.getDateOp(), ph.getTimeOp());
                            if (!ph.getMedicines().isEmpty()) {
                                for (MedicineS medicine : ph.getMedicines()) {
                                    if (medicine.isAdd()) {
                                        command.addMedicine(pharmacotherapyId, medicine.getName(), medicine.getCode(), medicine.getPriceUnit(),
                                                medicine.getPrice(), medicine.getStrength(),
                                                medicine.getDose(), medicine.getHowTaken(), medicine.getReasonForTaking(),
                                                medicine.getDateStarted(), medicine.getDateStopped());

                                    }
                                }
                            }
                        } else if (!ph.getMedicines().isEmpty()) {
                            for (MedicineS medicine : ph.getMedicines()) {
                                if (medicine.isAdd()) {
                                    command.addMedicine(ph.getId(), medicine.getName(), medicine.getCode(), medicine.getPriceUnit(),
                                            medicine.getPrice(), medicine.getStrength(),
                                            medicine.getDose(), medicine.getHowTaken(), medicine.getReasonForTaking(),
                                            medicine.getDateStarted(), medicine.getDateStopped());

                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed
        // TODO add your handling code here:
        setData();
        if (!date_c.equals("")) {
            utils.EncounterStr encounterStr = new utils.EncounterStr();
            encounterStr.setCode(code);
            encounterStr.setConsultDate(date_c);
            encounterStr.setConsultTime(time_c);
            encounterStr.setConsultType(type_c);
            if (this.getTitle().equals("Add New Encounter") || this.getTitle().equals("Add Encounter")) {
                DefaultMutableTreeNode selectedPatientNode = (DefaultMutableTreeNode) PatientsFrame.getPatientsTree().getLastSelectedPathComponent();
                PatientStr patient = (PatientStr) selectedPatientNode.getUserObject();
                Long doctorId = command.getUserDoctorId(Login.getUserId());
                Long hcOrgId = command.getHCOrgIdOfDoctor(doctorId);
                encounterId = command.addEncounter(code, patient.getId(), doctorId, hcOrgId, date_c, time_c, type_c);
                customizedCarePlanId = command.addCustomizedCarePlan(eocId, doctorId, encounterId);
                encounterStr.setId(encounterId);
                addHCItemsToEncounter(top, customizedCarePlanId);
                if (this.getTitle().equals("Add Encounter")) {
                    JOptionPane.showMessageDialog(null, "Episode of care successfully created");
                } else {
                    JOptionPane.showMessageDialog(null, "Encounter successfully created");
                }
            }
            this.setVisible(false);

            /*   if (this.getTitle().equals("Edit Encounter")) {
             DefaultMutableTreeNode encounterNode = (DefaultMutableTreeNode) EditEOC.getEncountersTree().getLastSelectedPathComponent();
             EncounterStr selected_encounter = (EncounterStr) encounterNode.getUserObject();
             encounterStr.setId(selected_encounter.getId());
             encounterNode.setUserObject(encounterStr);
             this.setVisible(false);
             }*/
            if (this.getTitle().equals("Edit:Add Encounter")) {
                DefaultMutableTreeNode selectedPatientNode = (DefaultMutableTreeNode) PatientsFrame.getPatientsTree().getLastSelectedPathComponent();
                PatientStr patient = (PatientStr) selectedPatientNode.getUserObject();
                Long doctorId = command.getUserDoctorId(Login.getUserId());
                Long hcOrgId = command.getHCOrgIdOfDoctor(doctorId);
                encounterId = command.addEncounter(code, patient.getId(), doctorId, hcOrgId, date_c, time_c, type_c);
                customizedCarePlanId = command.addCustomizedCarePlan(eocId, doctorId, encounterId);
                encounterStr.setId(encounterId);

                addHCItemsToEncounter(top, customizedCarePlanId);

                DefaultMutableTreeNode encounterNode = new DefaultMutableTreeNode(encounterStr, false);
                EditEOC.getTop_e().add(encounterNode);
                this.setVisible(false);
                EditEOC.getModel_e().reload();
                for (int i = 0; i < EditEOC.getEncountersTree().getRowCount(); i++) {
                    EditEOC.getEncountersTree().expandRow(i);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please fill in all the required fields");
        }
    }//GEN-LAST:event_ok_btActionPerformed

    public static Long getCustomizedCarePlanId() {
        return customizedCarePlanId;
    }

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        if (this.getTitle().equals("Add Encounter")) {
            if (JOptionPane.showConfirmDialog(this, "This will cancel the creation of the episode of care. Are you sure you want to close the window?", "Close Add Encounter", JOptionPane.YES_NO_OPTION) == 0) {
                this.setVisible(false);
            }
        }

    }//GEN-LAST:event_formWindowClosing

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if (this.getTitle().equals("Add Encounter")) {
            if (JOptionPane.showConfirmDialog(this, "This will cancel the creation of the episode of care. Are you sure you want to close the window?", "Close Add Encounter", JOptionPane.YES_NO_OPTION) == 0) {
                this.setVisible(false);
            }
        }
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddEncounterToEOCframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddEncounterToEOCframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddEncounterToEOCframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddEncounterToEOCframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddEncounterToEOCframe("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JTextField code_tf;
    private static javax.swing.JTextField consult_date_tf;
    private static javax.swing.JTextField consult_time_tf;
    private static javax.swing.JTextField consult_type_tf;
    private javax.swing.JTree hcItems_tree;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton ok_bt;
    // End of variables declaration//GEN-END:variables
}
