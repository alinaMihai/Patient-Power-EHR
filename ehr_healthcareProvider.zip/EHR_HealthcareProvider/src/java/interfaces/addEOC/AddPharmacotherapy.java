/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.addEOC;

import episodeofcareprj.Controller;
import interfaces.EditEOC.EditEOC;
import interfaces.EditEOC.EditEncounterFrame;
import interfaces.ViewEOC.ViewEncounter;
import interfaces.addEncounterToEOC.AddEncounterToEOCframe;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import utils.EditMedicineTreeAction;
import utils.MedicineDoubleClickTreeAction;
import utils.MedicineS;
import utils.MedicinesTreeAction;
import utils.Pharmacotherapy;

/**
 *
 * @author Alina
 */
public class AddPharmacotherapy extends javax.swing.JFrame {

    private String name;
    private String state;
    private String date_op;
    private String time_op;
    protected static Long pharmacotherapyId = null;
    private Controller command;
    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    private static JTree medicinesTree;
    private DefaultMutableTreeNode phNode;
    private Pharmacotherapy ph;

    /**
     * Creates new form AddPharmacotherapy
     */
    public AddPharmacotherapy(String name) {
        super(name);
        top = new DefaultMutableTreeNode("Medicines", true);
        medicinesTree = new JTree(top);
        model = (DefaultTreeModel) medicinesTree.getModel();
        medicinesTree.addMouseListener(new MedicineDoubleClickTreeAction(medicinesTree));


        if (this.getTitle().equals("Add Pharmacotherapy")) {
            medicinesTree.addMouseListener(new MedicinesTreeAction(medicinesTree));
        }
        if (this.getTitle().equals("View Pharmacotherapy") || this.getTitle().equals("Edit Pharmacotherapy") || this.getTitle().equalsIgnoreCase("Add Pharmacotherapy DoubleClick")) {
            if (this.getTitle().equals("View Pharmacotherapy")) {
                phNode = (DefaultMutableTreeNode) ViewEncounter.getHcItemsTree().getLastSelectedPathComponent();
                ph = (Pharmacotherapy) phNode.getUserObject();
            } else if (this.getTitle().equals("Edit Pharmacotherapy")) {
                medicinesTree.addMouseListener(new EditMedicineTreeAction(medicinesTree, EditEOC.getAcl()));
                phNode = (DefaultMutableTreeNode) EditEncounterFrame.getHcItemsTree().getLastSelectedPathComponent();
                ph = (Pharmacotherapy) phNode.getUserObject();
            } else if (this.getTitle().equalsIgnoreCase("Add Pharmacotherapy DoubleClick")) {
                DefaultMutableTreeNode phNode = (DefaultMutableTreeNode) AddEncounterToEOCframe.getHcItemsTree().getLastSelectedPathComponent();
                ph = (Pharmacotherapy) phNode.getUserObject();
            }
            if (!ph.getMedicines().isEmpty()) {
                for (MedicineS m : ph.getMedicines()) {
                    utils.MedicineS medicine = new utils.MedicineS();
                    medicine.setId(m.getId());
                    medicine.setName(m.getName());
                    medicine.setCode(m.getCode());
                    medicine.setDose(m.getDose());
                    medicine.setPriceUnit(m.getPriceUnit());
                    medicine.setPrice(m.getPrice());
                    medicine.setStrength(m.getStrength());
                    medicine.setHowTaken(m.getHowTaken());
                    medicine.setReasonForTaking(m.getReasonForTaking());
                    medicine.setDateStarted(m.getDateStarted());
                    medicine.setDateStopped(m.getDateStopped());
                    DefaultMutableTreeNode medNode = new DefaultMutableTreeNode(medicine, false);
                    top.add(medNode);
                }
            }
        }

        this.command = Controller.getInstance();
        initComponents();
        state_cb.setSelectedItem(null);
        state_cb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                JComboBox cb = (JComboBox) ae.getSource();
                state = (String) cb.getSelectedItem();
            }
        });
        for (int i = 0; i < medicinesTree.getRowCount(); i++) {
            medicinesTree.expandRow(i);
        }
    }

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static JTree getMedicinesTree() {
        return medicinesTree;
    }

    public void setData() {

        name = name_tf.getText();
        state = (String) state_cb.getSelectedItem();
        date_op = date_tf.getText();
        time_op = time_tf.getText();
    }

    public JTextField getDate_tf() {
        return date_tf;
    }

    public void setDate_tf(JTextField date_tf) {
        this.date_tf = date_tf;
    }

    public JTextField getName_tf() {
        return name_tf;
    }

    public void setName_tf(JTextField name_tf) {
        this.name_tf = name_tf;
    }

    public JComboBox getState_cb() {
        return state_cb;
    }

    public JTextField getTime_tf() {
        return time_tf;
    }

    public void setTime_tf(JTextField time_tf) {
        this.time_tf = time_tf;
    }

    public JLabel getTitle_label() {
        return title_label;
    }

    public void setTitle_label(JLabel title_label) {
        this.title_label = title_label;
    }

    public JButton getCancel_bt() {
        return cancel_bt;
    }

    public JButton getOk_bt() {
        return ok_bt;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        title_label = new javax.swing.JLabel();
        time_tf = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        date_tf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        ok_bt = new javax.swing.JButton();
        cancel_bt = new javax.swing.JButton();
        name_tf = new javax.swing.JTextField();
        state_cb = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = medicinesTree;
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_label.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_label.setText("Add Pharmacotherapy");

        jLabel6.setText("Date* ");

        jLabel5.setText("State*");

        jLabel3.setText("Name*");

        jLabel7.setText("Time*");

        ok_bt.setText("OK");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        cancel_bt.setText("Cancel");
        cancel_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_btActionPerformed(evt);
            }
        });

        state_cb.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "past", "future" }));

        jScrollPane1.setViewportView(jTree1);

        jLabel1.setText("Double click the medicines node to add a new medicine");

        jLabel4.setText("Right click a medicine node to view options");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 635, Short.MAX_VALUE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel1)
                            .addComponent(name_tf)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(62, 62, 62)
                                .addComponent(jLabel5)
                                .addGap(11, 11, 11))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ok_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cancel_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(date_tf)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(state_cb, 0, 1, Short.MAX_VALUE)
                                .addGap(396, 396, 396))
                            .addComponent(time_tf))))
                .addGap(48, 48, 48))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(265, Short.MAX_VALUE)
                .addComponent(title_label, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(200, 200, 200))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(title_label)
                .addGap(46, 46, 46)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(name_tf))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(state_cb))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(date_tf))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(time_tf)
                    .addComponent(jLabel7))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ok_bt)
                    .addComponent(cancel_bt))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed
        // TODO add your handling code here:
        setData();
        if (this.getTitle().equals("View Pharmacotherapy")) {
            this.setVisible(false);
        } else if (!name.equals("") && !state.equals("") && !date_op.equals("") && !time_op.equals("")) {
            utils.Pharmacotherapy pharmacotherapy = new utils.Pharmacotherapy();
            pharmacotherapy.setName(name);
            pharmacotherapy.setStateHCI(state);
            pharmacotherapy.setDateOp(date_op);
            pharmacotherapy.setTimeOp(time_op);
            for (int i = 0; i < top.getChildCount(); i++) {
                DefaultMutableTreeNode medicineNode = (DefaultMutableTreeNode) top.getChildAt(i);
                MedicineS medicine = (MedicineS) medicineNode.getUserObject();
                pharmacotherapy.getMedicines().add(medicine);
            }
            if (this.getTitle().equals("Add Pharmacotherapy")) {
                pharmacotherapy.setAdd(true);
                DefaultMutableTreeNode hcItem = new DefaultMutableTreeNode(pharmacotherapy, true);

                AddEncounterToEOCframe.getGroupPh().add(hcItem);
                AddEncounterToEOCframe.getModel().reload();
                for (int i = 0; i < AddEncounterToEOCframe.getHcItemsTree().getRowCount(); i++) {
                    AddEncounterToEOCframe.getHcItemsTree().expandRow(i);
                }
                this.setVisible(false);
            }
            if (this.getTitle().equalsIgnoreCase("Add Pharmacotherapy DoubleClick")) {
                pharmacotherapy.setAdd(true);
                DefaultMutableTreeNode selected_phNode = (DefaultMutableTreeNode) AddEncounterToEOCframe.getHcItemsTree().getLastSelectedPathComponent();

                selected_phNode.setUserObject(pharmacotherapy);
                this.setVisible(false);
            }

            if (this.getTitle().equals("Edit:Add Pharmacotherapy")) {
                pharmacotherapy.setAdd(true);
                DefaultMutableTreeNode hcItem = new DefaultMutableTreeNode(pharmacotherapy, true);
                EditEncounterFrame.getGroupPh().add(hcItem);
                EditEncounterFrame.getModel().reload();
                for (int i = 0; i < EditEncounterFrame.getHcItemsTree().getRowCount(); i++) {
                    EditEncounterFrame.getHcItemsTree().expandRow(i);
                }
                this.setVisible(false);
            }
            if (this.getTitle().equals("Edit Pharmacotherapy")) {
                DefaultMutableTreeNode selected_phNode = (DefaultMutableTreeNode) EditEncounterFrame.getHcItemsTree().getLastSelectedPathComponent();
                Pharmacotherapy pharmacotherapy_to_update = (Pharmacotherapy) selected_phNode.getUserObject();
                Long phId = pharmacotherapy_to_update.getId();
                pharmacotherapy.setId(phId);
                selected_phNode.setUserObject(pharmacotherapy);
                // to do method to update pharmacotherapy item
                command.updatePharmacotherapy(phId, name, state, date_op, time_op);
                this.setVisible(false);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please fill in all required fields");
        }
    }//GEN-LAST:event_ok_btActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void cancel_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_btActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_cancel_btActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddPharmacotherapy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddPharmacotherapy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddPharmacotherapy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddPharmacotherapy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddPharmacotherapy("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancel_bt;
    private javax.swing.JTextField date_tf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTree jTree1;
    private javax.swing.JTextField name_tf;
    private javax.swing.JButton ok_bt;
    private javax.swing.JComboBox state_cb;
    private javax.swing.JTextField time_tf;
    private javax.swing.JLabel title_label;
    // End of variables declaration//GEN-END:variables
}
