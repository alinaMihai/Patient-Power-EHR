/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.addEOC;

import doctor_ws.SymptomEntity;
import episodeofcareprj.Controller;
import episodeofcareprj.Login;
import interfaces.addEncounterToEOC.AddEncounterToEOCframe;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import utils.SymptomsActionJList;

/**
 *
 * @author Alina
 */
public class AddEOC extends javax.swing.JFrame {

    private String code;
    private String start_date;
    private String start_time;
    private String end_date;
    private String end_time;
    private static String diagnostic;
    private Controller command;
    protected static DefaultListModel symptoms_listModel;
    protected static Long eocId;
    private List<SymptomEntity> symptomsDB = null;

    /**
     * Creates new form AddEOC
     */
    public AddEOC(String name) {
        super(name);
        command = Controller.getInstance();
        symptoms_listModel = new DefaultListModel();
        initComponents();
        info_label.setVisible(false);
        List<String> diagnostics = command.getDiagnostics();
        for (String d : diagnostics) {
            diagnostic_cb.addItem(d);
        }
        diagnostic_cb.setSelectedItem(null);
        if (this.getTitle().equalsIgnoreCase("Add EOC")) {
            symptoms_list.addMouseListener(new SymptomsActionJList(symptoms_list));
            diagnostic_cb.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                    symptoms_listModel.removeAllElements();
                    JComboBox cb = (JComboBox) ae.getSource();
                    diagnostic = (String) cb.getSelectedItem();
                    symptomsDB = command.getGeneralSymptomsOfDisease(diagnostic);
                    if (symptomsDB != null) {

                        for (SymptomEntity s : symptomsDB) {
                            utils.Symptom symptom = new utils.Symptom();
                            symptom.setName(s.getName() + " general, please double click to update");
                            symptom.setDescription(s.getDescription());
                            symptom.setAppearanceDate(s.getAppearanceDate());
                            symptom.setDisappearanceDate(s.getDisappearanceDate());
                            symptom.setFrequency(s.getFrequency());
                            symptoms_listModel.addElement(symptom);
                        }
                    }
                }
            });
        }

    }

    public static JList getSymptoms_list() {
        return symptoms_list;
    }

    public void setData() {
        code = code_tf.getText();
        start_date = start_date_tf.getText();
        start_time = start_time_tf.getText();
        end_date = end_date_tf.getText();
        end_time = end_time_tf.getText();
        diagnostic = (String) diagnostic_cb.getSelectedItem();
    }

    public static String getDiagnostic() {
        return diagnostic;
    }

    public JTextField getCode_tf() {
        return code_tf;
    }

    public JLabel getInfo_label() {
        return info_label;
    }

    public void setInfo_label(JLabel info_label) {
        this.info_label = info_label;
    }

    public void setCode_tf(JTextField code_tf) {
        this.code_tf = code_tf;
    }

    public JTextField getEnd_date_tf() {
        return end_date_tf;
    }

    public void setEnd_date_tf(JTextField end_date_tf) {
        this.end_date_tf = end_date_tf;
    }

    public JTextField getEnd_time_tf() {
        return end_time_tf;
    }

    public void setEnd_time_tf(JTextField end_time_tf) {
        this.end_time_tf = end_time_tf;
    }

    public JTextField getStart_date_tf() {
        return start_date_tf;
    }

    public void setStart_date_tf(JTextField start_date_tf) {
        this.start_date_tf = start_date_tf;
    }

    public JTextField getStart_time_tf() {
        return start_time_tf;
    }

    public void setStart_time_tf(JTextField start_time_tf) {
        this.start_time_tf = start_time_tf;
    }

    public JLabel getTitle_label() {
        return title_label;
    }

    public void setTitle_label(JLabel title_label) {
        this.title_label = title_label;
    }

    public JComboBox getDiagnostic_cb() {
        return diagnostic_cb;
    }

    public void setDiagnostic_cb(JComboBox diagnostic_cb) {
        this.diagnostic_cb = diagnostic_cb;
    }

    public JButton getAdd_symptom_bt() {
        return add_symptom_bt;
    }

    public void setAdd_symptom_bt(JButton add_symptom_bt) {
        this.add_symptom_bt = add_symptom_bt;
    }

    public JButton getNewDiagnostic_bt() {
        return newDiagnostic_bt;
    }

    public void setNewDiagnostic_bt(JButton newDiagnostic_bt) {
        this.newDiagnostic_bt = newDiagnostic_bt;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField4 = new javax.swing.JTextField();
        title_label = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        symptoms_list = new javax.swing.JList(symptoms_listModel);
        add_symptom_bt = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        code_tf = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        start_date_tf = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        start_time_tf = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        end_date_tf = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        end_time_tf = new javax.swing.JTextField();
        ok_bt = new javax.swing.JButton();
        cancel_bt = new javax.swing.JButton();
        diagnostic_cb = new javax.swing.JComboBox();
        newDiagnostic_bt = new javax.swing.JButton();
        info_label = new javax.swing.JLabel();

        jTextField4.setText("jTextField4");
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_label.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_label.setText("Add Episode of Care");

        jLabel2.setText("Diagnostic*");

        jLabel3.setBackground(new java.awt.Color(0, 153, 153));
        jLabel3.setText("          Symptoms");

        jScrollPane2.setViewportView(symptoms_list);

        add_symptom_bt.setText("Add Symptom");
        add_symptom_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_symptom_btActionPerformed(evt);
            }
        });

        jLabel5.setText("Code*");

        code_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                code_tfActionPerformed(evt);
            }
        });

        jLabel6.setText("Start Date*");

        jLabel7.setText("Start Time*");

        jLabel8.setText("End Date");

        jLabel9.setText("End Time");

        ok_bt.setText("OK");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        cancel_bt.setText("Cancel");
        cancel_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_btActionPerformed(evt);
            }
        });

        newDiagnostic_bt.setText("New Diagnostic");
        newDiagnostic_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newDiagnostic_btActionPerformed(evt);
            }
        });

        info_label.setText("Click on the symptom item to view details");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel9)
                                .addComponent(jLabel8)))
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(add_symptom_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(2, 2, 2)))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(diagnostic_cb, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ok_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(103, 103, 103)
                                .addComponent(newDiagnostic_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(151, 151, 151)
                                .addComponent(cancel_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(end_time_tf, javax.swing.GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
                                        .addComponent(end_date_tf)
                                        .addComponent(code_tf))
                                    .addComponent(start_time_tf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(start_date_tf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 478, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(info_label)))
                        .addContainerGap(87, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(318, 318, 318)
                .addComponent(title_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(title_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(code_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(start_date_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(start_time_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(end_date_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(end_time_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newDiagnostic_bt)
                    .addComponent(jLabel2)
                    .addComponent(diagnostic_cb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(info_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(add_symptom_bt))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cancel_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ok_bt))
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void add_symptom_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_symptom_btActionPerformed
        // TODO add your handling code here:
        if (this.getTitle().equalsIgnoreCase("Add EOC")) {
            AddSymptom frame = new AddSymptom("Add Symptom");
            frame.setLocationRelativeTo(null);
            frame.setResizable(false);
            frame.setVisible(true);
        }

    }//GEN-LAST:event_add_symptom_btActionPerformed

    public static Long getEocId() {
        return eocId;
    }

    public static DefaultListModel getSymptoms_listModel() {
        return symptoms_listModel;
    }

    public static void setSymptoms_listModel(DefaultListModel symptoms_listModel) {
        AddEOC.symptoms_listModel = symptoms_listModel;
    }

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed
        setData();

        if (!code.equals("") && !start_date.equals("") && !start_time.equals("") && !diagnostic.equals("")) {

            utils.EOCStr eocStr = new utils.EOCStr();
            eocStr.setCode(code);
            eocStr.setStartDate(start_date);
            eocStr.setStartTime(start_time);
            eocStr.setEndDate(end_date);
            eocStr.setEndTime(end_time);
            eocStr.setId(eocId);

            if (this.getTitle().equals("Add EOC")) {
                Long diseaseId;
                eocId = command.createEOC(start_date, start_time, end_date, end_time, code);
                diseaseId = command.createDisease(diagnostic);
                command.addDisease(eocId, diseaseId);
                for (int i = 0; i < symptoms_listModel.getSize(); i++) {
                    utils.Symptom s = (utils.Symptom) symptoms_listModel.getElementAt(i);
                    if (s.isAdd()) {
                        Long sympt = command.createSymptom(s.getName(), s.getDescription(), s.getFrequency(),
                                s.getStatus(), s.getAppearanceDate(), s.getDisappearanceDate());
                        command.addSymptom(diseaseId, sympt);
                    }
                }
                Long aclId = command.createACLforUser(Login.getUserId(), true, true, true, true);
                command.addACLtoEOC(eocId, aclId);
               // JOptionPane.showMessageDialog(null, "Episode of Care successfully created");


                AddEncounterToEOCframe frame = new AddEncounterToEOCframe("Add Encounter");
                frame.setResizable(false);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                this.setVisible(false);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please fill all specified fields");
        }

    }//GEN-LAST:event_ok_btActionPerformed

    private void newDiagnostic_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newDiagnostic_btActionPerformed
        // TODO add your handling code here:
        String d = JOptionPane.showInputDialog("Please enter the diagnostic name");
        if (d != null) {
            diagnostic_cb.addItem(d);
        }

    }//GEN-LAST:event_newDiagnostic_btActionPerformed

    private void code_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_code_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_code_tfActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void cancel_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_btActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_cancel_btActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddEOC("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_symptom_bt;
    private javax.swing.JButton cancel_bt;
    private javax.swing.JTextField code_tf;
    private javax.swing.JComboBox diagnostic_cb;
    private javax.swing.JTextField end_date_tf;
    private javax.swing.JTextField end_time_tf;
    private javax.swing.JLabel info_label;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JButton newDiagnostic_bt;
    private javax.swing.JButton ok_bt;
    private javax.swing.JTextField start_date_tf;
    private javax.swing.JTextField start_time_tf;
    private static javax.swing.JList symptoms_list;
    private javax.swing.JLabel title_label;
    // End of variables declaration//GEN-END:variables
}
