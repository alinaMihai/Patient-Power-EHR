/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.EditEOC;

import doctor_ws.AccessControlListEntity;
import episodeofcareprj.Controller;
import interfaces.addEOC.AddSymptom;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import utils.Symptom;

/**
 *
 * @author Alina
 */
public class EditSymptomsTreeAction extends MouseAdapter {

    protected JTree tree;
    private Symptom item;
    private Controller command;
    private AccessControlListEntity acl = null;

    public EditSymptomsTreeAction(JTree tree, AccessControlListEntity acl) {
        this.tree = tree;
        this.acl = acl;
        this.command = Controller.getInstance();
    }

    @Override
    public void mousePressed(MouseEvent e) {

        if (SwingUtilities.isRightMouseButton(e)) {
             TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            DefaultMutableTreeNode selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();

            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (selectionNode.getAllowsChildren() == true) {
                JPopupMenu menu = new JPopupMenu();
                JMenuItem jt1 = new JMenuItem("Add Symptom");
                jt1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        if (acl.isCanInsert()) {
                            AddSymptom frame = new AddSymptom("Edit:Add Symptom");
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "Insert right is not allowed");
                        }
                    }
                });
                menu.add(jt1);
                menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
            }


            if (selectionNode.getAllowsChildren() == false) {
                item = (Symptom) selectionNode.getUserObject();
                if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem jt1 = new JMenuItem("Edit Symptom");
                    jt1.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (acl.isCanUpdate()) {
                                AddSymptom frame = new AddSymptom("Edit Symptom");
                                frame.getTitle_label().setText("Edit "+item.getName());
                                frame.getName_tf().setText(item.getName());
                                frame.getDescription_ta().setText(item.getDescription());
                                frame.getAppearance_date_tf().setText(item.getAppearanceDate());
                                frame.getDisapperance_date_tf().setText(item.getDisappearanceDate());
                                frame.getState_tf().setText(item.getStatus());
                                frame.getFrequency_tf().setText(item.getFrequency());
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            } else {
                                JOptionPane.showMessageDialog(null, "Edit right is not allowed");
                            }
                        }
                    });
                    menu.add(jt1);
                    JMenuItem jt2 = new JMenuItem("Delete Symptom");
                    jt2.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            // to do delete method for the symptom
                            if (acl.isCanDelete()) {
                                DefaultMutableTreeNode symptomNode = (DefaultMutableTreeNode) EditEOC.getSymptomsTree().getLastSelectedPathComponent();
                                Symptom symptom = (Symptom) symptomNode.getUserObject();
                                EditEOC.getTop_s().remove(symptomNode);
                                if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Symptom", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                    command.deleteSymptom(symptom.getId());

                                    EditEOC.getModel_s().reload();
                                    for (int i = 0; i < tree.getRowCount(); i++) {
                                        tree.expandRow(i);
                                    }
                                JOptionPane.showMessageDialog(null, "Symptom successfully deleted");}
                            } else {
                                JOptionPane.showMessageDialog(null, "Delete right is not allowed");
                            }
                        }
                    });
                    menu.add(jt2);
                    menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);

                }
            }

        }
    }
}
