/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.EditEOC;

import doctor_ws.AccessControlListEntity;
import episodeofcareprj.Controller;
import interfaces.addEOC.AddPharmacotherapy;
import interfaces.addEOC.AddProcedure;
import interfaces.addEOC.AddQualitativeObservation;
import interfaces.addEOC.AddQuantitativeObservation;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import utils.Pharmacotherapy;
import utils.Procedure;
import utils.QualObs;
import utils.QuanObs;

/**
 *
 * @author Alina
 */
public class EditHCItemsTreeAction extends MouseAdapter {

    protected JTree hcItemsTree;
    private Controller command;
    private AccessControlListEntity acl = null;

    public EditHCItemsTreeAction(JTree tree, AccessControlListEntity acl) {
        this.hcItemsTree = tree;
        this.acl = acl;
        this.command = Controller.getInstance();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        try {
            if (SwingUtilities.isRightMouseButton(e)) {
                TreePath path = hcItemsTree.getPathForLocation(e.getX(), e.getY());
                final DefaultMutableTreeNode selectionGroup = (DefaultMutableTreeNode) hcItemsTree.getLastSelectedPathComponent();
                Rectangle pathBounds = hcItemsTree.getUI().getPathBounds(hcItemsTree, path);
                if (selectionGroup.getAllowsChildren() == true) {
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                        JPopupMenu menu = new JPopupMenu();
                        JMenuItem jt1 = new JMenuItem("Add New Item");
                        jt1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (acl.isCanInsert()) {
                                    if (selectionGroup.toString().equals("Procedures")) {

                                        AddProcedure frame = new AddProcedure("Edit:Add Procedure");
                                        frame.setResizable(false);
                                        frame.setLocationRelativeTo(null);
                                        frame.setVisible(true);


                                    }

                                    if (selectionGroup.toString().equals("Qualitative Observations")) {
                                        AddQualitativeObservation frame = new AddQualitativeObservation("Edit:Add Qualitative Observation");
                                        frame.setResizable(false);
                                        frame.setLocationRelativeTo(null);
                                        frame.setVisible(true);
                                    }
                                    if (selectionGroup.toString().equals("Quantitative Observations")) {
                                        AddQuantitativeObservation frame = new AddQuantitativeObservation("Edit:Add Quantitative Observation");
                                        frame.setResizable(false);
                                        frame.setLocationRelativeTo(null);
                                        frame.setVisible(true);
                                    }
                                    if (selectionGroup.toString().equals("Pharmacotherapy")) {
                                        AddPharmacotherapy frame = new AddPharmacotherapy("Edit:Add Pharmacotherapy");
                                        frame.setResizable(false);
                                        frame.setLocationRelativeTo(null);
                                        frame.setVisible(true);
                                    }

                                } else {
                                    JOptionPane.showMessageDialog(null, "Insert right is not allowed");
                                }
                            }
                        });
                        menu.add(jt1);
                        menu.show(hcItemsTree, pathBounds.x, pathBounds.y + pathBounds.height);
                        /*        if (selectionGroup.getUserObject() instanceof Pharmacotherapy) {
                         JPopupMenu menu2 = new JPopupMenu();
                         JMenuItem jmi1 = new JMenuItem("Edit Item");
                         jmi1.addActionListener(new ActionListener() {
                         @Override
                         public void actionPerformed(ActionEvent ae) {
                         if (acl.isCanUpdate()) {
                         Pharmacotherapy ph = (Pharmacotherapy) selectionGroup.getUserObject();
                         AddPharmacotherapy frame = new AddPharmacotherapy("Edit Pharmacotherapy");
                         frame.getTitle_label().setText("Edit " + ph.getName());
                         frame.getTime_tf().setText(ph.getTimeOp());
                         frame.getState_cb().setSelectedItem(ph.getStateHCI());
                         frame.getName_tf().setText(ph.getName());
                         frame.getDate_tf().setText(ph.getDateOp());
                         frame.setResizable(false);
                         frame.setLocationRelativeTo(null);
                         frame.setVisible(true);
                         } else {
                         JOptionPane.showMessageDialog(null, "Edit right is not allowed");
                         }
                         }
                         });
                         menu2.add(jmi1);
                         JMenuItem jmi2 = new JMenuItem("Delete Item");
                         jmi2.addActionListener(new ActionListener() {
                         @Override
                         public void actionPerformed(ActionEvent ae) {
                         if (acl.isCanDelete()) {
                         DefaultMutableTreeNode phNode = selectionGroup;
                         Pharmacotherapy ph = (Pharmacotherapy) selectionGroup.getUserObject();
                         // method to remove ph item
                         if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Pharmacotherapy", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                         command.deletePharmacotherapy(ph.getId());
                         EditEncounterFrame.getModel().removeNodeFromParent(phNode);
                         EditEncounterFrame.getModel().reload();
                         for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                         hcItemsTree.expandRow(i);
                         }
                         }
                         } else {
                         JOptionPane.showMessageDialog(null, "Delete right is not allowed");
                         }
                         }
                         });
                         menu2.add(jmi2);

                         /*  JMenuItem jmi3 = new JMenuItem("Add Medicine");
                         jmi3.addActionListener(new ActionListener() {
                         @Override
                         public void actionPerformed(ActionEvent ae) {
                         if (acl.isCanInsert()) {
                         AddMedicine frame = new AddMedicine("Edit:Add Medicine");
                         frame.setResizable(false);
                         frame.setLocationRelativeTo(null);
                         frame.setVisible(true);
                         } else {
                         JOptionPane.showMessageDialog(null, "Insert right is not allowed");
                         }
                         }
                         });
                         menu2.add(jmi3);
                         menu2.show(hcItemsTree, pathBounds.x, pathBounds.y + pathBounds.height);

                         }*/
                    }
                }
                if (selectionGroup.getAllowsChildren() == false) {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem jt2 = new JMenuItem("Edit Item");
                    jt2.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (acl.isCanUpdate()) {
                                if (selectionGroup.getUserObject() instanceof Procedure) {
                                    Procedure p = (Procedure) selectionGroup.getUserObject();
                                    AddProcedure frame = new AddProcedure("Edit Procedure");
                                    frame.getTitle_label().setText("Edit " + p.getName());
                                    frame.getCode_tf().setText(p.getCode());
                                    frame.getName_tf().setText(p.getName());
                                    frame.getDate_tf().setText(p.getDateOp());
                                    frame.getTime_tf().setText(p.getTimeOp());
                                    frame.getState_cb().setSelectedItem(p.getStateHCI());
                                    frame.getProcedure_notes_ta().setText(p.getNotes());

                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);
                                }

                                if (selectionGroup.getUserObject() instanceof QualObs) {
                                    utils.QualObs qo = (utils.QualObs) selectionGroup.getUserObject();

                                    AddQualitativeObservation frame = new AddQualitativeObservation("Edit Qualitative Observation");
                                    frame.getTitle_label().setText("Edit " + qo.getName());
                                    frame.getCode_tf().setText(qo.getCode());
                                    frame.getName_tf().setText(qo.getName());
                                    frame.getDate_tf().setText(qo.getDateOp());
                                    frame.getTime_tf().setText(qo.getTimeOp());
                                    frame.getState_cb().setSelectedItem(qo.getStateHCI());
                                    frame.getNotes_ta().setText(qo.getNotes());
                                    frame.getDescription_tf().setText(qo.getDescription());
                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);
                                }
                                if (selectionGroup.getUserObject() instanceof QuanObs) {
                                    QuanObs qo = (QuanObs) selectionGroup.getUserObject();
                                    AddQuantitativeObservation frame = new AddQuantitativeObservation("Edit Quantitative Observation");
                                    frame.getTitle_label().setText("Edit " + qo.getName());
                                    frame.getCode_tf().setText(qo.getCode());
                                    frame.getName_tf().setText(qo.getName());
                                    frame.getDate_tf().setText(qo.getDateOp());
                                    frame.getTime_tf().setText(qo.getTimeOp());
                                    frame.getState_cb().setSelectedItem(qo.getStateHCI());
                                    frame.getMeasurement_ta().setText(qo.getMeasurementQ());
                                    frame.getDescription_ta().setText(qo.getDescription());
                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);
                                }
                                if (selectionGroup.getUserObject() instanceof Pharmacotherapy) {
                                    Pharmacotherapy ph = (Pharmacotherapy) selectionGroup.getUserObject();
                                    AddPharmacotherapy frame = new AddPharmacotherapy("Edit Pharmacotherapy");
                                    frame.getTitle_label().setText("Edit " + ph.getName());
                                    frame.getTime_tf().setText(ph.getTimeOp());
                                    frame.getState_cb().setSelectedItem(ph.getStateHCI());
                                    frame.getName_tf().setText(ph.getName());
                                    frame.getDate_tf().setText(ph.getDateOp());
                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);

                                }
                                /*   if (selectionGroup.getUserObject() instanceof MedicineS) {
                                 MedicineS med = (MedicineS) selectionGroup.getUserObject();
                                 AddMedicine frame = new AddMedicine("Edit Medicine");
                                 frame.getTitle_label().setText("Edit " + med.getName());
                                 frame.getCode_tf().setText(med.getCode());
                                 frame.getName_tf().setText(med.getName());
                                 frame.getDateStarted_tf().setText(med.getDateStarted());
                                 frame.getDateStopped_tf().setText(med.getDateStopped());
                                 frame.getStrength_tf().setText(med.getStrength());
                                 frame.getHowTaken_tf().setText(med.getHowTaken());
                                 frame.getReason_for_taking_ta().setText(med.getReasonForTaking());
                                 frame.getDose_ta().setText(med.getDose());
                                 frame.getPrice_tf().setText(med.getPrice() + "");
                                 frame.getPrice_unit_cb().setSelectedItem(med.getPriceUnit());
                                 frame.setResizable(false);
                                 frame.setLocationRelativeTo(null);
                                 frame.setVisible(true);
                                 }
                                 */
                            } else {
                                JOptionPane.showMessageDialog(null, "Edit right is not allowed");
                            }
                        }
                    });
                    menu.add(jt2);

                    JMenuItem jt3 = new JMenuItem("Delete Item");
                    jt3.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (acl.isCanDelete()) {
                                if (selectionGroup.getUserObject() instanceof Procedure) {
                                    DefaultMutableTreeNode procedureNode = selectionGroup;
                                    Procedure p = (Procedure) procedureNode.getUserObject();
                                    // method to delete procedure
                                    if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Procedure", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                        command.deleteProcedure(p.getId());
                                        EditEncounterFrame.getModel().removeNodeFromParent(procedureNode);
                                        EditEncounterFrame.getModel().reload();
                                        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                            hcItemsTree.expandRow(i);
                                        }
                                    }
                                }
                                if (selectionGroup.getUserObject() instanceof QualObs) {
                                    DefaultMutableTreeNode qqNode = selectionGroup;
                                    QualObs qualObs = (QualObs) qqNode.getUserObject();
                                    // method to delete qualObs
                                    if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Qualitative Observation", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                        command.deleteQualObs(qualObs.getId());
                                        EditEncounterFrame.getModel().removeNodeFromParent(qqNode);
                                        EditEncounterFrame.getModel().reload();
                                        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                            hcItemsTree.expandRow(i);
                                        }
                                    }
                                }
                                if (selectionGroup.getUserObject() instanceof QuanObs) {
                                    DefaultMutableTreeNode qqNode = selectionGroup;
                                    QuanObs quanObs = (QuanObs) qqNode.getUserObject();
                                    // method to delete quanObs
                                    if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Quantitative Observation", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {

                                        command.deleteQuanObs(quanObs.getId());
                                        EditEncounterFrame.getModel().removeNodeFromParent(qqNode);
                                        EditEncounterFrame.getModel().reload();
                                        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                            hcItemsTree.expandRow(i);
                                        }
                                    }
                                }
                                if (selectionGroup.getUserObject() instanceof Pharmacotherapy) {
                                    DefaultMutableTreeNode phNode = selectionGroup;
                                    Pharmacotherapy ph = (Pharmacotherapy) selectionGroup.getUserObject();
                                    // method to remove ph item
                                    if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Pharmacotherapy", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                        command.deletePharmacotherapy(ph.getId());
                                        EditEncounterFrame.getModel().removeNodeFromParent(phNode);
                                        EditEncounterFrame.getModel().reload();
                                        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                            hcItemsTree.expandRow(i);
                                        }
                                    }
                                }
                                /*  if (selectionGroup.getUserObject() instanceof MedicineS) {
                                 DefaultMutableTreeNode medNode = selectionGroup;
                                 MedicineS medicine = (MedicineS) medNode.getUserObject();
                                 // method to delete med
                                 if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Medicine", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {

                                 command.deleteMedicine(medicine.getId());
                                 EditEncounterFrame.getModel().removeNodeFromParent(medNode);
                                 EditEncounterFrame.getModel().reload();
                                 for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                 hcItemsTree.expandRow(i);
                                 }
                                 }
                                 }*/

                            } else {
                                JOptionPane.showMessageDialog(null, "Delete right is not allowed");
                            }
                        }
                    });
                    menu.add(jt3);

                    menu.show(hcItemsTree, pathBounds.x, pathBounds.y
                            + pathBounds.height);
                }
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Please select an object from the list");
        }
    }
}
