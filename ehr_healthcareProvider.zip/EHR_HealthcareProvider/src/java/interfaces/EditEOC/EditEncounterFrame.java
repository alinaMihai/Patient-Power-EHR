/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.EditEOC;

import doctor_ws.AccessControlListEntity;
import doctor_ws.PlannedHCitemEntity;
import episodeofcareprj.Controller;
import episodeofcareprj.Login;
import interfaces.ViewEOC.EpisodeOfCareFrame;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import utils.CCPStr;
import utils.EncounterStr;
import utils.MedicineS;
import utils.Pharmacotherapy;
import utils.Procedure;
import utils.QualObs;
import utils.QuanObs;

/**
 *
 * @author Alina
 */
public class EditEncounterFrame extends javax.swing.JFrame {

    /**
     * Creates new form ViewEncounter
     */
    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    private static JTree hcItemsTree;
    private static DefaultMutableTreeNode groupP;
    private static DefaultMutableTreeNode groupPh;
    private static DefaultMutableTreeNode groupQualObs;
    private static DefaultMutableTreeNode groupQuanObs;
    private static Controller command;
    private String code;
    private String date_c;
    private String time_c;
    private String type_c;
    private static Long encounterId;
    private static Long customizedCarePlanId;

    public EditEncounterFrame(String name) {
        super(name);
        command = Controller.getInstance();
        List<PlannedHCitemEntity> hcItems;
        top = new DefaultMutableTreeNode("HC Items");
        hcItemsTree = new JTree(top);
        hcItemsTree.setRootVisible(false);
        hcItemsTree.setShowsRootHandles(true);
        model = (DefaultTreeModel) hcItemsTree.getModel();
        groupP = new DefaultMutableTreeNode("Procedures", true);
        model.insertNodeInto(groupP, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupQualObs = new DefaultMutableTreeNode("Qualitative Observations", true);
        model.insertNodeInto(groupQualObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupQuanObs = new DefaultMutableTreeNode("Quantitative Observations", true);
        model.insertNodeInto(groupQuanObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupPh = new DefaultMutableTreeNode("Pharmacotherapy", true);
        model.insertNodeInto(groupPh, top, top.getChildCount());
        model.nodeStructureChanged(top);
        if (this.getTitle().equalsIgnoreCase("Edit Encounter")) {
            DefaultMutableTreeNode encounterNode = (DefaultMutableTreeNode) EditEOC.getEncountersTree().getLastSelectedPathComponent();
            EncounterStr encounter = (EncounterStr) encounterNode.getUserObject();
            encounterId = encounter.getId();
            hcItemsTree.addMouseListener(new EditHCItemsTreeAction(hcItemsTree, EditEOC.getAcl()));

        } else if (this.getTitle().equalsIgnoreCase("Edit HCService")) {
            DefaultMutableTreeNode encounterNode = (DefaultMutableTreeNode) EpisodeOfCareFrame.getEOCTree().getLastSelectedPathComponent();
            CCPStr encounter = (CCPStr) encounterNode.getUserObject();
            encounterId = encounter.getEncounterId();
            AccessControlListEntity acl = command.getByUserAndCCP(Login.getUserId(), encounter.getId());
            if (acl == null) {
                Long userTypeId = command.getUserTypeIdofUser(Login.getUserId());
                acl = command.getByUserTypeAndCCP(userTypeId, encounter.getId());
            }
            if (acl != null) {
                hcItemsTree.addMouseListener(new EditHCItemsTreeAction(hcItemsTree, acl));
            }
        }


        customizedCarePlanId = command.getCustomizedCarePlan(encounterId);


        hcItems = command.getHCItemsOfCustomizedCarePlan(customizedCarePlanId);
        try {
            utils.Utils.retrieveHCItemTree(model, hcItems, groupP, groupQualObs, groupQuanObs, groupPh, "");
        } catch (Exception ex) {
            Logger.getLogger(EditEncounterFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

        initComponents();
        /*  List<DefaultMutableTreeNode> groups = new ArrayList<DefaultMutableTreeNode>();
         groups.add(groupP);
         groups.add(groupQualObs);
         groups.add(groupQuanObs);
         groups.add(groupPh);
         utils.Utils.removeUnusedGroups(model, groups);
         */
        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
            hcItemsTree.expandRow(i);
        }
    }

    public void setData() {
        code = code_tf.getText();
        date_c = consult_date_tf.getText();
        time_c = consult_time_tf.getText();
        type_c = consult_type_tf.getText();
    }

    public static JTree getHcItemsTree() {
        return hcItemsTree;
    }

    public JLabel getTitle_lb() {
        return title_lb;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static DefaultMutableTreeNode getGroupP() {
        return groupP;
    }

    public static DefaultMutableTreeNode getGroupPh() {
        return groupPh;
    }

    public static DefaultMutableTreeNode getGroupQualObs() {
        return groupQualObs;
    }

    public static DefaultMutableTreeNode getGroupQuanObs() {
        return groupQuanObs;
    }

    public JTextField getCode_tf() {
        return code_tf;
    }

    public JTextField getConsult_date_tf() {
        return consult_date_tf;
    }

    public JTextField getConsult_time_tf() {
        return consult_time_tf;
    }

    public JTextField getConsult_type_tf() {
        return consult_type_tf;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        title_lb = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        code_tf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        consult_date_tf = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        consult_time_tf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        consult_type_tf = new javax.swing.JTextField();
        ok_bt = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        hcItems_tree = hcItemsTree;
        jLabel7 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_lb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_lb.setText(" Edit  Encounter");

        jLabel2.setText("Code");

        jLabel3.setText("Consult Date*");

        jLabel4.setText("Consult time*");

        jLabel5.setText("Consult Type");

        ok_bt.setText("OK");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        jLabel6.setText("Healthcare services");

        jScrollPane2.setViewportView(hcItems_tree);

        jLabel7.setText("Right click a group to add new healthcare service");

        jButton1.setText("Cancel");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Right click a healthcare service to see options");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(consult_date_tf)
                                    .addComponent(consult_time_tf)
                                    .addComponent(code_tf)
                                    .addComponent(consult_type_tf)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ok_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(377, 377, 377)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7)
                            .addComponent(jLabel6)
                            .addComponent(jLabel1))))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(title_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(title_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(10, 10, 10)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(code_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(consult_date_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(consult_time_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(consult_type_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ok_bt)
                    .addComponent(jButton1))
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed
        // TODO add your handling code here:
        setData();
        if (!date_c.equals("") && !time_c.equals("")) {
            utils.EncounterStr encounterStr = new utils.EncounterStr();
            encounterStr.setCode(code);
            encounterStr.setConsultDate(date_c);
            encounterStr.setConsultTime(time_c);
            encounterStr.setConsultType(type_c);
            if (hcItemsTree.getRowCount() > 1) {
                for (int i = 0; i < top.getChildCount(); i++) {
                    DefaultMutableTreeNode groupNode = (DefaultMutableTreeNode) top.getChildAt(i);
                    String group = (String) groupNode.getUserObject();
                    if (group.equals("Procedures")) {
                        for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                            DefaultMutableTreeNode procedureNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                            Procedure p;
                            p = (Procedure) procedureNode.getUserObject();
                            if (p.isAdd()) {
                                command.addProcedure(customizedCarePlanId, p.getCode(), p.getName(), p.getStateHCI(),
                                        p.getDateOp(), p.getTimeOp(), p.getNotes());
                            }
                        }
                    }

                    if (group.equals("Qualitative Observations")) {
                        for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                            DefaultMutableTreeNode qqNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                            QualObs qq;
                            qq = (QualObs) qqNode.getUserObject();

                            if (qq.isAdd()) {
                                command.addQualitativeObservation(customizedCarePlanId, qq.getCode(), qq.getName(), qq.getStateHCI(),
                                        qq.getDateOp(), qq.getTimeOp(), qq.getNotes(), qq.getDescription());
                            }
                        }
                    }

                    if (group.equals("Quantitative Observations")) {
                        for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                            DefaultMutableTreeNode qqNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                            QuanObs qq;
                            qq = (QuanObs) qqNode.getUserObject();
                            if (qq.isAdd()) {
                                command.addQuantitativeObservation(customizedCarePlanId, qq.getCode(), qq.getName(), qq.getStateHCI(),
                                        qq.getDateOp(), qq.getTimeOp(), qq.getMeasurementQ(), qq.getDescription());
                            }

                        }
                    }

                    if (group.equals("Pharmacotherapy")) {
                        for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                            DefaultMutableTreeNode phNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                            Pharmacotherapy ph;
                            ph = (Pharmacotherapy) phNode.getUserObject();

                            if (ph.isAdd()) {
                                Long pharmacotherapyId = command.addPharmacotherapy(customizedCarePlanId, ph.getName(),
                                        ph.getStateHCI(), ph.getDateOp(), ph.getTimeOp());
                                if (!ph.getMedicines().isEmpty()) {
                                    for (MedicineS medicine : ph.getMedicines()) {
                                        if (medicine.isAdd()) {

                                            command.addMedicine(pharmacotherapyId, medicine.getName(), medicine.getCode(), medicine.getPriceUnit(),
                                                    medicine.getPrice(), medicine.getStrength(),
                                                    medicine.getDose(), medicine.getHowTaken(), medicine.getReasonForTaking(),
                                                    medicine.getDateStarted(), medicine.getDateStopped());

                                        }
                                    }
                                }
                            } else if (!ph.getMedicines().isEmpty()) {
                                for (MedicineS medicine : ph.getMedicines()) {
                                    if (medicine.isAdd()) {
                                        command.addMedicine(ph.getId(), medicine.getName(), medicine.getCode(), medicine.getPriceUnit(),
                                                medicine.getPrice(), medicine.getStrength(),
                                                medicine.getDose(), medicine.getHowTaken(), medicine.getReasonForTaking(),
                                                medicine.getDateStarted(), medicine.getDateStopped());

                                    }
                                }
                            }
                        }

                    }
                }
                //update Encounter method to do
                command.editEncounter(encounterId, code, date_c, time_c, type_c);
                JOptionPane.showMessageDialog(null, "Encounter successfully updated");
                this.setVisible(false);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please fill in all the required fields");
        }
    }//GEN-LAST:event_ok_btActionPerformed

    public static Long getCustomizedCarePlanId() {
        return customizedCarePlanId;
    }

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditEncounterFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditEncounterFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditEncounterFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditEncounterFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditEncounterFrame("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField code_tf;
    private javax.swing.JTextField consult_date_tf;
    private javax.swing.JTextField consult_time_tf;
    private javax.swing.JTextField consult_type_tf;
    private javax.swing.JTree hcItems_tree;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton ok_bt;
    private static javax.swing.JLabel title_lb;
    // End of variables declaration//GEN-END:variables
}
