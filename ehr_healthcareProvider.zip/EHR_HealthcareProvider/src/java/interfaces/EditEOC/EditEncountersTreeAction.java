/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.EditEOC;

import doctor_ws.AccessControlListEntity;
import episodeofcareprj.Controller;
import interfaces.addEncounterToEOC.AddEncounterToEOCframe;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import utils.EncounterStr;

/**
 *
 * @author Alina
 */
public class EditEncountersTreeAction extends MouseAdapter {
    
    protected JTree tree;
    private EncounterStr item;
    private Controller command;
    private AccessControlListEntity acl = null;
    private DefaultMutableTreeNode selectionNode;
    
    public EditEncountersTreeAction(JTree tree, AccessControlListEntity acl) {
        this.tree = tree;
        this.acl = acl;
        command = Controller.getInstance();
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
        
        if (SwingUtilities.isRightMouseButton(e)) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (selectionNode.getAllowsChildren() == true) {
                JPopupMenu menu = new JPopupMenu();
                JMenuItem jt1 = new JMenuItem("Add Encounter");
                jt1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        if (acl.isCanInsert()) {
                            AddEncounterToEOCframe frame = new AddEncounterToEOCframe("Edit:Add Encounter");
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "Insert right is not allowed");
                        }
                    }
                });
                menu.add(jt1);
                menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
            }
            
            if (selectionNode.getAllowsChildren() == false) {
                item = (EncounterStr) selectionNode.getUserObject();
                if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem jt1 = new JMenuItem("Edit Encounter");
                    jt1.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (acl.isCanUpdate()) {
                                EditEncounterFrame frame = new EditEncounterFrame("Edit Encounter");
                                frame.getTitle_lb().setText("Edit "+item.getConsultType());
                                frame.getCode_tf().setText(item.getCode());
                                frame.getConsult_date_tf().setText(item.getConsultDate());
                                frame.getConsult_time_tf().setText(item.getConsultTime());
                                frame.getConsult_type_tf().setText(item.getConsultType());
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            } else {
                                JOptionPane.showMessageDialog(null, "Edit right is not allowed");
                            }
                        }
                    });
                    menu.add(jt1);
                    JMenuItem jt2 = new JMenuItem("Delete Encounter");
                    jt2.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (acl.isCanDelete()) {
                                // to do delete method for the symptom
                                EditEOC.getTop_e().remove(selectionNode);
                                if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Encounter", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                    command.deleteEncounter(item.getId());
                                    EditEOC.getModel_e().reload();
                                    for (int i = 0; i < tree.getRowCount(); i++) {
                                        tree.expandRow(i);
                                    }
                                JOptionPane.showMessageDialog(null, "Encounter successfully deleted ");
                                }
                            } else {
                                JOptionPane.showMessageDialog(null, "Delete right is not allowed");
                            }
                        }
                    });
                    menu.add(jt2);
                    menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                    
                }
            }
            
        }
    }
}
