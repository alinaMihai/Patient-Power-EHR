/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.EditEOC;

import doctor_ws.AccessControlListEntity;
import doctor_ws.SymptomEntity;
import episodeofcareprj.Controller;
import episodeofcareprj.Login;
import interfaces.ViewEOC.EpisodeOfCareFrame;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import utils.EOCStr;
import utils.EncounterStr;
import utils.Symptom;

/**
 *
 * @author Alina
 */
public class EditEOC extends javax.swing.JFrame {

    private static DefaultMutableTreeNode top_s;
    private static DefaultTreeModel model_s;
    private static JTree symptomsTree;
    private static DefaultMutableTreeNode top_e;
    private static DefaultTreeModel model_e;
    private static JTree encountersTree;
    private static String diagnostic;
    private Controller command;
    private List<SymptomEntity> symptomsDB = null;
    private static EOCStr eoc;
    private static DefaultMutableTreeNode selectedEOCnode;
    private String code;
    private String start_date;
    private String start_time;
    private String end_date;
    private String end_time;
    private static AccessControlListEntity acl = null;

    /**
     * Creates new form EditEOC
     */
    public EditEOC(String name) {
        super(name);
        command = Controller.getInstance();
        top_s = new DefaultMutableTreeNode("Symptoms", true);
        symptomsTree = new JTree(top_s);
        model_s = (DefaultTreeModel) symptomsTree.getModel();
        
        top_e = new DefaultMutableTreeNode("Encounters", true);
        encountersTree = new JTree(top_e);
       
        model_e = (DefaultTreeModel) encountersTree.getModel();
        selectedEOCnode = (DefaultMutableTreeNode) EpisodeOfCareFrame.getEOCTree().getLastSelectedPathComponent();
        eoc = (EOCStr) selectedEOCnode.getUserObject();
        acl = command.getByUserAndEOC(Login.getUserId(), eoc.getId());
        if (acl == null) {
            Long userTypeId = command.getUserTypeIdofUser(Login.getUserId());
            acl = command.getByUserTypeAndEOC(userTypeId, eoc.getId());
        }
        symptomsTree.addMouseListener(new EditSymptomsTreeAction(symptomsTree,acl)); 
        encountersTree.addMouseListener(new EditEncountersTreeAction(encountersTree,acl));
        
        List<Long> encounterIds = command.getEncounterOfEOC(eoc.getId());
        for (Long e : encounterIds) {
            List<String> encounterDetails = command.getEncounterDetails(e);
            EncounterStr encounter = new EncounterStr();
            encounter.setId(Long.parseLong(encounterDetails.get(0)));
            encounter.setCode(encounterDetails.get(1));
            encounter.setConsultDate(encounterDetails.get(2));
            encounter.setConsultTime(encounterDetails.get(3));
            encounter.setConsultType(encounterDetails.get(4));
            DefaultMutableTreeNode encounterNode = new DefaultMutableTreeNode(encounter, false);
            top_e.add(encounterNode);
        }


        symptomsDB = command.getSymptomsOfDisease(eoc.getDiseaseId());
        if (symptomsDB != null) {
            for (SymptomEntity s : symptomsDB) {
                Symptom symptom = new Symptom();
                symptom.setName(s.getName());
                symptom.setDescription(s.getDescription());
                symptom.setAppearanceDate(s.getAppearanceDate());
                symptom.setDisappearanceDate(s.getDisappearanceDate());
                symptom.setFrequency(s.getFrequency());
                symptom.setStatus(s.getStatus());
                symptom.setId(s.getId());
                DefaultMutableTreeNode symptomNode = new DefaultMutableTreeNode(symptom, false);
                top_s.add(symptomNode);
            }
        }
        initComponents();
        for (int i = 0; i < symptomsTree.getRowCount(); i++) {
            symptomsTree.expandRow(i);
        }
        for (int i = 0; i < encountersTree.getRowCount(); i++) {
            encountersTree.expandRow(i);
        }

    }

    public static EOCStr getEoc() {
        return eoc;
    }

    public static DefaultTreeModel getModel_s() {
        return model_s;
    }

    public static DefaultTreeModel getModel_e() {
        return model_e;
    }

    public static DefaultMutableTreeNode getTop_s() {
        return top_s;
    }

    public static JTree getSymptomsTree() {
        return symptomsTree;
    }

    public static DefaultMutableTreeNode getTop_e() {
        return top_e;
    }

    public JLabel getTitle_lb() {
        return title_lb;
    }

    public static JTree getEncountersTree() {
        return encountersTree;
    }

    public JTextField getDiagnostic_tf() {
        return diagnostic_tf;
    }

    public void setDiagnostic_tf(JTextField diagnostic_tf) {
        this.diagnostic_tf = diagnostic_tf;
    }

    public JTextField getCode_tf() {
        return code_tf;
    }

    public JTextField getEnd_date_tf() {
        return end_date_tf;
    }

    public JTextField getEnd_time_tf() {
        return end_time_tf;
    }

    public JTextField getStart_date_tf() {
        return start_date_tf;
    }

    public JTextField getStart_time_tf() {
        return start_time_tf;
    }

    public String getDiagnostic() {
        return diagnostic;
    }

    public static AccessControlListEntity getAcl() {
        return acl;
    }

    public void setData() {
        code = code_tf.getText();
        start_date = start_date_tf.getText();
        start_time = start_time_tf.getText();
        end_date = end_date_tf.getText();
        end_time = end_time_tf.getText();
        diagnostic = diagnostic_tf.getText();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField4 = new javax.swing.JTextField();
        jMenuItem1 = new javax.swing.JMenuItem();
        title_lb = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        code_tf = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        start_date_tf = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        start_time_tf = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        end_date_tf = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        end_time_tf = new javax.swing.JTextField();
        ok_bt = new javax.swing.JButton();
        diagnostic_tf = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        symptoms_tree = symptomsTree;
        jScrollPane4 = new javax.swing.JScrollPane();
        encounters_tree = encountersTree;
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();

        jTextField4.setText("jTextField4");
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_lb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_lb.setText("Edit  Episode of Care");

        jLabel2.setText("Diagnostic");

        jLabel3.setBackground(new java.awt.Color(0, 153, 153));
        jLabel3.setText("          Symptoms");

        jLabel5.setText("Code");

        jLabel6.setText("Start Date");

        jLabel7.setText("Start Time");

        jLabel8.setText("End Date");

        jLabel9.setText("End Time");

        ok_bt.setText("OK");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        jLabel1.setText("Encounters");

        jScrollPane3.setViewportView(symptoms_tree);

        jScrollPane4.setViewportView(encounters_tree);

        jLabel4.setText("right click a symptom to  see options");

        jLabel10.setText("right click an encounter to see options");
        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(ok_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(218, 218, 218))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(58, 58, 58)
                                    .addComponent(jLabel5)
                                    .addGap(8, 8, 8))
                                .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(diagnostic_tf)
                            .addComponent(start_date_tf)
                            .addComponent(end_time_tf)
                            .addComponent(end_date_tf)
                            .addComponent(start_time_tf)
                            .addComponent(code_tf))
                        .addGap(44, 44, 44)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 431, Short.MAX_VALUE)
                    .addComponent(jScrollPane4))
                .addContainerGap(22, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(377, 377, 377)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(291, 291, 291)
                        .addComponent(title_lb)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(title_lb)
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(diagnostic_tf)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(code_tf)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(start_date_tf)
                            .addComponent(jLabel6))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(start_time_tf)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(end_date_tf)
                            .addComponent(jLabel8))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(end_time_tf)
                            .addComponent(jLabel9))
                        .addGap(111, 111, 111)
                        .addComponent(ok_bt))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed

        setData();
        if (!code.equals("") && !start_date.equals("") && !start_time.equals("")) {
            command.updateEOC(eoc.getId(), start_date, start_time, end_date, end_time, code);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Please fill all specified fields");
        }

    }//GEN-LAST:event_ok_btActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditEOC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditEOC("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JTextField code_tf;
    private javax.swing.JTextField diagnostic_tf;
    private static javax.swing.JTree encounters_tree;
    private static javax.swing.JTextField end_date_tf;
    private static javax.swing.JTextField end_time_tf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JButton ok_bt;
    static javax.swing.JTextField start_date_tf;
    private static javax.swing.JTextField start_time_tf;
    private static javax.swing.JTree symptoms_tree;
    private javax.swing.JLabel title_lb;
    // End of variables declaration//GEN-END:variables
}
