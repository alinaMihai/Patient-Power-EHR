/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.editGeneralCarePlan;

import episodeofcareprj.Controller;
import interfaces.createGeneralCarePlan.AddGMedicine;
import interfaces.createGeneralCarePlan.AddGPharmacotherapy;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import utils.MedicineS;

/**
 *
 * @author Alina
 */
public class EditGeneralMedicineTreeAction extends MouseAdapter {

    private JTree tree;
    private Controller command;

    public EditGeneralMedicineTreeAction(JTree tree) {
        this.tree = tree;
        command = Controller.getInstance();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        try {
            if (SwingUtilities.isRightMouseButton(e)) {
                TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                final DefaultMutableTreeNode selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
                Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
                if (selectionNode.getAllowsChildren() == false) {
                    final MedicineS med = (MedicineS) selectionNode.getUserObject();
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                        JPopupMenu menu = new JPopupMenu();
                        JMenuItem jt1 = new JMenuItem("Edit Medicine");
                        jt1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                AddGMedicine frame = new AddGMedicine("Edit Medicine");
                                frame.getTitle_label().setText("Edit " + med.getName());
                                frame.getCode_tf().setText(med.getCode());
                                frame.getName_tf().setText(med.getName());
                                frame.getStrength_tf().setText(med.getStrength());
                                frame.getHowTaken_tf().setText(med.getHowTaken());
                                frame.getReason_for_taking_ta().setText(med.getReasonForTaking());
                                frame.getDose_ta().setText(med.getDose());
                                frame.getPrice_tf().setText(med.getPrice() + "");
                                frame.getPrice_unit_cb().setSelectedItem(med.getPriceUnit());
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                        });
                        menu.add(jt1);
                        JMenuItem jt2 = new JMenuItem("Delete Medicine");
                        jt2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Medicine", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {

                                    command.deleteMedicine(med.getId());
                                    AddGPharmacotherapy.getModel().removeNodeFromParent(selectionNode);
                                    AddGPharmacotherapy.getModel().reload();
                                    for (int i = 0; i < AddGPharmacotherapy.getMedicinesTree().getRowCount(); i++) {
                                        AddGPharmacotherapy.getMedicinesTree().expandRow(i);
                                    }
                                }

                            }
                        });
                        menu.add(jt2);
                        menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                    }
                } else {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem jmi3 = new JMenuItem("Add Medicine");
                    jmi3.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            AddGMedicine frame = new AddGMedicine("Edit:Add Medicine");
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);

                        }
                    });
                    menu.add(jmi3);
                    menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                }

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Please select an object from the list");
        }
    }
}
