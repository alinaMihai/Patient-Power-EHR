/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.editGeneralCarePlan;

/**
 *
 * @author Alina
 */
public class GCPstr {

   private String diagnostic;
    private Long id;

  

    public String getDiagnostic() {
        return diagnostic;
    }

    public void setDiagnostic(String diagnostic) {
        this.diagnostic = diagnostic;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "GCP id: " + id + " for " + diagnostic;
    }
}
