/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.editGeneralCarePlan;

import doctor_ws.PlannedHCitemEntity;
import doctor_ws.PlannedPharmacotherapyEntity;
import doctor_ws.SymptomEntity;
import episodeofcareprj.Controller;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import utils.MedicineS;
import utils.Pharmacotherapy;
import utils.Procedure;
import utils.QualObs;
import utils.QuanObs;
import utils.Symptom;

/**
 *
 * @author Alina
 */
public class EditGeneralCarePlan extends javax.swing.JFrame {

    /**
     * Creates new form EditGeneralCarePlan
     */
    private Controller command;
    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    protected static JTree hcItemsTree;
    private static DefaultMutableTreeNode groupP;
    private static DefaultMutableTreeNode groupPh;
    private static DefaultMutableTreeNode groupQualObs;
    private static DefaultMutableTreeNode groupQuanObs;
    private static DefaultTreeModel model_s;
    private static JTree symptomsTree;
    private static DefaultMutableTreeNode top_s;
    private List<SymptomEntity> symptomsDB = null;
    private DefaultMutableTreeNode selectedGCP;
    private static GCPstr gcp;

    public EditGeneralCarePlan(String name) {
        super(name);
        command = Controller.getInstance();
        top_s = new DefaultMutableTreeNode("Symptoms", true);
        symptomsTree = new JTree(top_s);
        model_s = (DefaultTreeModel) symptomsTree.getModel();
        symptomsTree.addMouseListener(new GeneralSymptomTreeAction(symptomsTree));
        top = new DefaultMutableTreeNode("Healthcare Services");
        hcItemsTree = new JTree(top);
        hcItemsTree.setRootVisible(false);
        hcItemsTree.setShowsRootHandles(true);

        hcItemsTree.addMouseListener(new GeneralHCItemsTreeAction(hcItemsTree));
        model = (DefaultTreeModel) hcItemsTree.getModel();
        groupP = new DefaultMutableTreeNode("Procedures", true);
        model.insertNodeInto(groupP, top, top.getChildCount());
        model.nodeStructureChanged(top);
        //top.add(groupP);
        groupQualObs = new DefaultMutableTreeNode("Qualitative Observations", true);
        model.insertNodeInto(groupQualObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        //top.add(groupQualObs);
        groupQuanObs = new DefaultMutableTreeNode("Quantitative Observations", true);
        model.insertNodeInto(groupQuanObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        //top.add(groupQuanObs);
        groupPh = new DefaultMutableTreeNode("Pharmacotherapy", true);
        model.insertNodeInto(groupPh, top, top.getChildCount());
        model.nodeStructureChanged(top);

        //top.add(groupPh);
        selectedGCP = (DefaultMutableTreeNode) GeneralCarePlans.getGeneralCarePlansTree().getLastSelectedPathComponent();
        gcp = (GCPstr) selectedGCP.getUserObject();
        List<PlannedHCitemEntity> hcItems = command.getGeneralHCItemsOfDisease(gcp.getDiagnostic());
        try {
            utils.Utils.retrieveHCItemTree(model, hcItems, groupP, groupQualObs, groupQuanObs, groupPh, "");
        } catch (Exception ex) {
            Logger.getLogger(EditGeneralCarePlan.class.getName()).log(Level.SEVERE, null, ex);
        }
        symptomsDB = command.getGeneralSymptomsOfDisease(gcp.getDiagnostic());
        if (symptomsDB != null) {

            for (SymptomEntity s : symptomsDB) {
                utils.Symptom symptom = new utils.Symptom();
                symptom.setName(s.getName());
                symptom.setDescription(s.getDescription());
                symptom.setAppearanceDate(s.getAppearanceDate());
                symptom.setDisappearanceDate(s.getDisappearanceDate());
                symptom.setFrequency(s.getFrequency());
                symptom.setId(s.getId());
                DefaultMutableTreeNode symptomNode = new DefaultMutableTreeNode(symptom, false);
                top_s.add(symptomNode);
            }
        }

        for (int i = 0; i < symptomsTree.getRowCount(); i++) {
            symptomsTree.expandRow(i);
        }
        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
            hcItemsTree.expandRow(i);
        }

        initComponents();
    }

    public static GCPstr getGcp() {
        return gcp;
    }

    public static DefaultTreeModel getModel_s() {
        return model_s;
    }

    public static JTree getSymptomsTree() {
        return symptomsTree;
    }

    public static DefaultMutableTreeNode getTop_s() {
        return top_s;
    }

    public DefaultMutableTreeNode getSelectedGCP() {
        return selectedGCP;
    }

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static JTree getHcItemsTree() {
        return hcItemsTree;
    }

    public static DefaultMutableTreeNode getGroupP() {
        return groupP;
    }

    public static DefaultMutableTreeNode getGroupPh() {
        return groupPh;
    }

    public static DefaultMutableTreeNode getGroupQualObs() {
        return groupQualObs;
    }

    public static DefaultMutableTreeNode getGroupQuanObs() {
        return groupQuanObs;
    }

    public JLabel getTitle_lb() {
        return title_lb;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        title_lb = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = hcItemsTree;
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        diagnostic_tf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTree2 = symptomsTree;
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_lb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_lb.setText("Edit General Care Plan");

        jScrollPane1.setViewportView(jTree1);

        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setText("Healthcare services");

        jLabel3.setText("Diagnostic");

        jScrollPane2.setViewportView(jTree2);

        jLabel4.setText("Symptoms");

        jLabel5.setText("right click a symptom to see options");

        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setText("right click the symptoms group to add a new symptom");

        jLabel9.setText("right click a healtcare service to see options");

        jLabel1.setText("right click a Healthcare Services group to add a new heathcare service");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(224, 224, 224)
                .addComponent(title_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(267, 267, 267))
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(diagnostic_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9))
                                .addGap(21, 21, 21)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(title_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(diagnostic_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGap(3, 3, 3)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Long gcpId = gcp.getId();
        if (hcItemsTree.getRowCount() > 1) {
            for (int i = 0; i < top.getChildCount(); i++) {
                DefaultMutableTreeNode groupNode = (DefaultMutableTreeNode) top.getChildAt(i);
                String group = (String) groupNode.getUserObject();
                if (group.equals("Procedures")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode procedureNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        Procedure p = (Procedure) procedureNode.getUserObject();
                        if (p.isAdd()) {
                            command.addGeneralProcedure(gcpId, p.getCode(), p.getName(), p.getNotes());
                        }
                    }
                }

                if (group.equals("Qualitative Observations")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode qqNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        QualObs qq = (QualObs) qqNode.getUserObject();
                        if (qq.isAdd()) {
                            command.addGeneralQualitativeObservation(gcpId, qq.getCode(), qq.getName(), qq.getNotes(), qq.getDescription());
                        }
                    }
                }

                if (group.equals("Quantitative Observations")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode qqNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        QuanObs qq = (QuanObs) qqNode.getUserObject();
                        if (qq.isAdd()) {
                            command.addGeneralQuantitativeObservation(gcpId, qq.getCode(), qq.getName(), qq.getMeasurementQ(), qq.getDescription());
                        }
                    }
                }

                if (group.equals("Pharmacotherapy")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode phNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        Pharmacotherapy ph = (Pharmacotherapy) phNode.getUserObject();
                        PlannedPharmacotherapyEntity pharmacotherapyObj;
                        if (ph.isAdd()) {
                            pharmacotherapyObj = command.addGeneralPharmacotherapy(gcpId, ph.getName());
                            if (phNode.getChildCount() > 0) {
                                for (int iii = 0; iii < phNode.getChildCount(); iii++) {
                                    DefaultMutableTreeNode medicineNode = (DefaultMutableTreeNode) phNode.getChildAt(iii);
                                    MedicineS medicine = (MedicineS) medicineNode.getUserObject();
                                    if (medicine.isAdd()) {

                                        command.addMedicine(pharmacotherapyObj.getId(), medicine.getName(), medicine.getCode(), medicine.getPriceUnit(),
                                                medicine.getPrice(), medicine.getStrength(),
                                                medicine.getDose(), medicine.getHowTaken(), medicine.getReasonForTaking(),
                                                medicine.getDateStarted(), medicine.getDateStopped());

                                    }
                                }
                            }
                        } else if (phNode.getChildCount() > 0) {
                            for (int iii = 0; iii < phNode.getChildCount(); iii++) {
                                DefaultMutableTreeNode medicineNode = (DefaultMutableTreeNode) phNode.getChildAt(iii);
                                MedicineS medicine = (MedicineS) medicineNode.getUserObject();
                                if (medicine.isAdd()) {
                                    DefaultMutableTreeNode pharmacotherapyParent = (DefaultMutableTreeNode) medicineNode.getParent();
                                    Pharmacotherapy pharmacotherapy = (Pharmacotherapy) pharmacotherapyParent.getUserObject();

                                    command.addMedicine(pharmacotherapy.getId(), medicine.getName(), medicine.getCode(), medicine.getPriceUnit(),
                                            medicine.getPrice(), medicine.getStrength(),
                                            medicine.getDose(), medicine.getHowTaken(), medicine.getReasonForTaking(),
                                            "", "");

                                }
                            }
                        }
                    }
                }

            }
        }
        if (symptomsTree.getRowCount() > 1) {
            for (int i = 0; i < top_s.getChildCount(); i++) {
                DefaultMutableTreeNode symptomNode = (DefaultMutableTreeNode) top_s.getChildAt(i);
                Symptom s = (Symptom) symptomNode.getUserObject();
                Long diseaseId = command.getDiseaseIdOfDiagnostic(gcp.getDiagnostic());
                if (s.isAdd()) {
                    Long sympt = command.createSymptom(s.getName(), s.getDescription(), s.getFrequency(),
                            s.getStatus(), s.getAppearanceDate(), s.getDisappearanceDate());
                    s.setId(sympt);
                    command.addSymptom(diseaseId, sympt);
                }
            }
        }
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }

    public JTextField getDiagnostic_tf() {
        return diagnostic_tf;
    }//GEN-LAST:event_formWindowClosing

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditGeneralCarePlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditGeneralCarePlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditGeneralCarePlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditGeneralCarePlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditGeneralCarePlan("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField diagnostic_tf;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTree jTree1;
    private javax.swing.JTree jTree2;
    private javax.swing.JLabel title_lb;
    // End of variables declaration//GEN-END:variables
}
