/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.editGeneralCarePlan;

import episodeofcareprj.Controller;
import interfaces.createGeneralCarePlan.AddGSymptom;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import utils.Symptom;

/**
 *
 * @author Alina
 */
public class GeneralSymptomTreeAction extends MouseAdapter {

    protected JTree tree;
    private Symptom item;
    private Controller command;

    public GeneralSymptomTreeAction(JTree tree) {
        this.tree = tree;
        this.command = Controller.getInstance();
    }

    @Override
    public void mousePressed(MouseEvent e) {

        if (SwingUtilities.isRightMouseButton(e)) {
            int selRow = tree.getRowForLocation(e.getX(), e.getY());
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            DefaultMutableTreeNode selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();

            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (selectionNode.getAllowsChildren() == true) {
                JPopupMenu menu = new JPopupMenu();
                JMenuItem jt1 = new JMenuItem("Add Symptom");
                jt1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        AddGSymptom frame = new AddGSymptom("Edit:Add Symptom");
                        frame.setResizable(false);
                        frame.setLocationRelativeTo(null);
                        frame.setVisible(true);

                    }
                });
                menu.add(jt1);
                menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
            }

            if (selRow > 0) {
                if (selectionNode.getAllowsChildren() == false) {
                    item = (Symptom) selectionNode.getUserObject();
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                        JPopupMenu menu = new JPopupMenu();
                        JMenuItem jt1 = new JMenuItem("Edit Symptom");
                        jt1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                AddGSymptom frame = new AddGSymptom("Edit Symptom");
                                frame.getTitle_label().setText("Edit Symptom");
                                frame.getName_tf().setText(item.getName());
                                frame.getDescription_ta().setText(item.getDescription());
                                frame.getFrequency_tf().setText(item.getFrequency());
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                        });
                        menu.add(jt1);
                        JMenuItem jt2 = new JMenuItem("Delete Symptom");
                        jt2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                // to do delete method for the symptom
                                DefaultMutableTreeNode symptomNode = (DefaultMutableTreeNode) EditGeneralCarePlan.getSymptomsTree().getLastSelectedPathComponent();
                                Symptom symptom = (Symptom) symptomNode.getUserObject();
                                EditGeneralCarePlan.getTop_s().remove(symptomNode);
                                if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Symptom", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                    command.deleteSymptom(symptom.getId());

                                    EditGeneralCarePlan.getModel_s().reload();
                                    for (int i = 0; i < tree.getRowCount(); i++) {
                                        tree.expandRow(i);
                                    }
                                }

                            }
                        });
                        menu.add(jt2);
                        menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);

                    }
                }

            }
        }
    }
}
