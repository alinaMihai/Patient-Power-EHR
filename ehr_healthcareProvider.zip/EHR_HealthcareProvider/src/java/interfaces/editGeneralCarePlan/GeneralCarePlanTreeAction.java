/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.editGeneralCarePlan;

import episodeofcareprj.Controller;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class GeneralCarePlanTreeAction extends MouseAdapter {

    protected JTree tree;
    private Controller command;
    private DefaultMutableTreeNode selectionNode;
    private GCPstr gcp;

    public GeneralCarePlanTreeAction(JTree tree) {
        this.tree = tree;
        command = Controller.getInstance();
    }

    @Override
    public void mousePressed(MouseEvent e) {

        if (SwingUtilities.isRightMouseButton(e)) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            gcp = (GCPstr) selectionNode.getUserObject();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {

                if (selectionNode.getAllowsChildren() == false) {
                    JPopupMenu menu = new JPopupMenu();

                    JMenuItem jt2 = new JMenuItem("Edit General Care Plan");
                    jt2.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            EditGeneralCarePlan frame = new EditGeneralCarePlan("Edit GeneralCarePlan");
                            frame.getTitle_lb().setText("Edit " + gcp.getDiagnostic());
                            frame.getDiagnostic_tf().setText(gcp.getDiagnostic());
                            frame.getDiagnostic_tf().setEditable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setResizable(false);
                            frame.setVisible(true);
                        }
                    });
                    menu.add(jt2);
                    JMenuItem jt3 = new JMenuItem("Delete General Care Plan");
                    jt3.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete GeneralCarePlan", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                command.deleteGeneralCarePlan(gcp.getId());
                                // tree.setSelectionPath(null);
                                DefaultTreeModel model = (DefaultTreeModel) tree.getModel();

                                model.removeNodeFromParent(selectionNode);
                                model.reload();
                                for (int i = 0; i < tree.getRowCount(); i++) {
                                    tree.expandRow(i);
                                }
                            }
                        }
                    });
                    menu.add(jt3);
                    menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                }
            }
        }
    }
}
