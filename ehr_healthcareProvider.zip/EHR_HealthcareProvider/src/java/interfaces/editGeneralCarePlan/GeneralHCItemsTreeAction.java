/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.editGeneralCarePlan;

import episodeofcareprj.Controller;
import interfaces.createGeneralCarePlan.AddGPharmacotherapy;
import interfaces.createGeneralCarePlan.AddGProcedure;
import interfaces.createGeneralCarePlan.AddGQualitativeObservation;
import interfaces.createGeneralCarePlan.AddGQuantitativeObservation;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import utils.Pharmacotherapy;
import utils.Procedure;
import utils.QualObs;
import utils.QuanObs;

/**
 *
 * @author Alina
 */
public class GeneralHCItemsTreeAction extends MouseAdapter {

    protected JTree hcItemsTree;
    private Controller command;

    public GeneralHCItemsTreeAction(JTree tree) {
        this.hcItemsTree = tree;
        this.command = Controller.getInstance();
    }

    @Override
    public void mousePressed(MouseEvent e) {

        if (SwingUtilities.isRightMouseButton(e)) {
            TreePath path = hcItemsTree.getPathForLocation(e.getX(), e.getY());
            final DefaultMutableTreeNode selectionGroup = (DefaultMutableTreeNode) hcItemsTree.getLastSelectedPathComponent();
            Rectangle pathBounds = hcItemsTree.getUI().getPathBounds(hcItemsTree, path);
            if (selectionGroup.getAllowsChildren() == true) {
                if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem jt1 = new JMenuItem("Add New Item");
                    jt1.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (selectionGroup.toString().equals("Procedures")) {

                                AddGProcedure frame = new AddGProcedure("Edit:Add Procedure");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);

                            }

                            if (selectionGroup.toString().equals("Qualitative Observations")) {
                                AddGQualitativeObservation frame = new AddGQualitativeObservation("Edit:Add Qualitative Observation");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                            if (selectionGroup.toString().equals("Quantitative Observations")) {
                                AddGQuantitativeObservation frame = new AddGQuantitativeObservation("Edit:Add Quantitative Observation");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                            if (selectionGroup.toString().equals("Pharmacotherapy")) {
                                AddGPharmacotherapy frame = new AddGPharmacotherapy("Edit:Add Pharmacotherapy");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }

                        }
                    });
                    menu.add(jt1);
                    menu.show(hcItemsTree, pathBounds.x, pathBounds.y + pathBounds.height);
                    /* if (selectionGroup.getUserObject() instanceof Pharmacotherapy) {
                     JPopupMenu menu2 = new JPopupMenu();
                     JMenuItem jmi1 = new JMenuItem("Edit Item");
                     jmi1.addActionListener(new ActionListener() {
                     @Override
                     public void actionPerformed(ActionEvent ae) {
                     Pharmacotherapy ph = (Pharmacotherapy) selectionGroup.getUserObject();
                     AddGPharmacotherapy frame = new AddGPharmacotherapy("Edit Pharmacotherapy");
                     frame.getTitle_label().setText("Edit Pharmacotherapy");
                     frame.getName_tf().setText(ph.getName());
                     frame.setResizable(false);
                     frame.setLocationRelativeTo(null);
                     frame.setVisible(true);
                     }
                     });
                     menu2.add(jmi1);
                     JMenuItem jmi2 = new JMenuItem("Delete Item");
                     jmi2.addActionListener(new ActionListener() {
                     @Override
                     public void actionPerformed(ActionEvent ae) {
                     DefaultMutableTreeNode phNode = selectionGroup;
                     Pharmacotherapy ph = (Pharmacotherapy) selectionGroup.getUserObject();
                     // method to remove ph item
                     if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Pharmacotherapy", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                     command.deletePharmacotherapy(ph.getId());
                     EditGeneralCarePlan.getModel().removeNodeFromParent(phNode);
                     EditGeneralCarePlan.getModel().reload();
                     for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                     hcItemsTree.expandRow(i);
                     }
                     }

                     }
                     });
                     menu2.add(jmi2);

                     JMenuItem jmi3 = new JMenuItem("Add Medicine");
                     jmi3.addActionListener(new ActionListener() {
                     @Override
                     public void actionPerformed(ActionEvent ae) {
                     AddGMedicine frame = new AddGMedicine("Edit:Add Medicine");
                     frame.setResizable(false);
                     frame.setLocationRelativeTo(null);
                     frame.setVisible(true);

                     }
                     });
                     menu2.add(jmi3);
                     menu2.show(hcItemsTree, pathBounds.x, pathBounds.y + pathBounds.height);

                     }*/
                }
            }
            if (selectionGroup.getAllowsChildren() == false) {
                JPopupMenu menu = new JPopupMenu();
                JMenuItem jt2 = new JMenuItem("Edit Item");
                jt2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        if (selectionGroup.getUserObject() instanceof Procedure) {
                            Procedure p = (Procedure) selectionGroup.getUserObject();
                            AddGProcedure frame = new AddGProcedure("Edit Procedure");
                            frame.getTitle_label().setText("Edit Procedure");
                            frame.getCode_tf().setText(p.getCode());
                            frame.getName_tf().setText(p.getName());
                            frame.getProcedure_notes_ta().setText(p.getNotes());

                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        }

                        if (selectionGroup.getUserObject() instanceof QualObs) {
                            utils.QualObs qo = (utils.QualObs) selectionGroup.getUserObject();

                            AddGQualitativeObservation frame = new AddGQualitativeObservation("Edit Qualitative Observation");
                            frame.getTitle_label().setText("Edit Qualitative Observation");
                            frame.getCode_tf().setText(qo.getCode());
                            frame.getName_tf().setText(qo.getName());
                            frame.getNotes_ta().setText(qo.getNotes());
                            frame.getDescription_tf().setText(qo.getDescription());
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        }
                        if (selectionGroup.getUserObject() instanceof QuanObs) {
                            QuanObs qo = (QuanObs) selectionGroup.getUserObject();
                            AddGQuantitativeObservation frame = new AddGQuantitativeObservation("Edit Quantitative Observation");
                            frame.getTitle_label().setText("Edit Quantitative Observation");
                            frame.getCode_tf().setText(qo.getCode());
                            frame.getName_tf().setText(qo.getName());
                            frame.getMeasurement_ta().setText(qo.getMeasurementQ());
                            frame.getDescription_ta().setText(qo.getDescription());
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        }
                        if (selectionGroup.getUserObject() instanceof Pharmacotherapy) {
                            Pharmacotherapy ph = (Pharmacotherapy) selectionGroup.getUserObject();
                            AddGPharmacotherapy frame = new AddGPharmacotherapy("Edit Pharmacotherapy");
                            frame.getTitle_label().setText("Edit Pharmacotherapy");
                            frame.getName_tf().setText(ph.getName());
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        }
                        /*
                         if (selectionGroup.getUserObject() instanceof MedicineS) {
                         MedicineS med = (MedicineS) selectionGroup.getUserObject();
                         AddGMedicine frame = new AddGMedicine("Edit Medicine");
                         frame.getTitle_label().setText("Edit Medicine");
                         frame.getCode_tf().setText(med.getCode());
                         frame.getName_tf().setText(med.getName());
                         frame.getStrength_tf().setText(med.getStrength());
                         frame.getHowTaken_tf().setText(med.getHowTaken());
                         frame.getReason_for_taking_ta().setText(med.getReasonForTaking());
                         frame.getDose_ta().setText(med.getDose());
                         frame.getPrice_tf().setText(med.getPrice() + "");
                         frame.getPrice_unit_cb().setSelectedItem(med.getPriceUnit());
                         frame.setResizable(false);
                         frame.setLocationRelativeTo(null);
                         frame.setVisible(true);
                         }
                         */

                    }
                });
                menu.add(jt2);

                JMenuItem jt3 = new JMenuItem("Delete Item");
                jt3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        if (selectionGroup.getUserObject() instanceof Procedure) {
                            DefaultMutableTreeNode procedureNode = selectionGroup;
                            Procedure p = (Procedure) procedureNode.getUserObject();
                            // method to delete procedure
                            if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Procedure", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                command.deleteProcedure(p.getId());
                                EditGeneralCarePlan.getModel().removeNodeFromParent(procedureNode);
                                EditGeneralCarePlan.getModel().reload();
                                for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                    hcItemsTree.expandRow(i);
                                }
                            }
                        }
                        if (selectionGroup.getUserObject() instanceof QualObs) {
                            DefaultMutableTreeNode qqNode = selectionGroup;
                            QualObs qualObs = (QualObs) qqNode.getUserObject();
                            // method to delete qualObs
                            if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Qualitative Observation", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                command.deleteQualObs(qualObs.getId());
                                EditGeneralCarePlan.getModel().removeNodeFromParent(qqNode);
                                EditGeneralCarePlan.getModel().reload();
                                for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                    hcItemsTree.expandRow(i);
                                }
                            }
                        }
                        if (selectionGroup.getUserObject() instanceof QuanObs) {
                            DefaultMutableTreeNode qqNode = selectionGroup;
                            QuanObs quanObs = (QuanObs) qqNode.getUserObject();
                            // method to delete quanObs
                            if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Quantitative Observation", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {

                                command.deleteQuanObs(quanObs.getId());
                                EditGeneralCarePlan.getModel().removeNodeFromParent(qqNode);
                                EditGeneralCarePlan.getModel().reload();
                                for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                    hcItemsTree.expandRow(i);
                                }
                            }
                        }
                        if (selectionGroup.getUserObject() instanceof Pharmacotherapy) {
                            Pharmacotherapy ph = (Pharmacotherapy) selectionGroup.getUserObject();
                            if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Pharmacotherapy", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                command.deletePharmacotherapy(ph.getId());
                                EditGeneralCarePlan.getModel().removeNodeFromParent(selectionGroup);
                                EditGeneralCarePlan.getModel().reload();
                                for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                                    hcItemsTree.expandRow(i);
                                }
                            }
                        }
                        /*
                         if (selectionGroup.getUserObject() instanceof MedicineS) {
                         DefaultMutableTreeNode medNode = selectionGroup;
                         MedicineS medicine = (MedicineS) medNode.getUserObject();
                         // method to delete med
                         if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Medicine", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {

                         command.deleteMedicine(medicine.getId());
                         EditGeneralCarePlan.getModel().removeNodeFromParent(medNode);
                         EditGeneralCarePlan.getModel().reload();
                         for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
                         hcItemsTree.expandRow(i);
                         }
                         }
                         }*/


                    }
                });
                menu.add(jt3);
                menu.show(hcItemsTree, pathBounds.x, pathBounds.y
                        + pathBounds.height);
            }
        }

    }
}
