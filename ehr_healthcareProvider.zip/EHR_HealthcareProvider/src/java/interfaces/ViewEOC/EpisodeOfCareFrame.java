/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.ViewEOC;

import doctor_ws.AccessControlListEntity;
import episodeofcareprj.Controller;
import episodeofcareprj.Login;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import utils.CCPStr;
import utils.EOCJTreeClickAction;
import utils.EOCStr;
import utils.PatientStr;

/**
 *
 * @author Alina
 */
public class EpisodeOfCareFrame extends javax.swing.JFrame {

    private Controller command;
    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    protected static JTree EOCTree;
    private static PatientStr patient;
    private static AccessControlListEntity acl;

    /**
     * Creates new form EpisodeOfCareFrame
     */
    public EpisodeOfCareFrame(String name) {
        super(name);
        command = Controller.getInstance();
        top = new DefaultMutableTreeNode("Episodes of care");
        EOCTree = new JTree(top);
        model = (DefaultTreeModel) EOCTree.getModel();
        EOCTree.setRootVisible(false);
        EOCTree.setShowsRootHandles(true);
        EOCTree.addMouseListener(new EOCJTreeClickAction(EOCTree));
        EOCTree.setRootVisible(false);
        EOCTree.setShowsRootHandles(true);
        DefaultMutableTreeNode patientNode = (DefaultMutableTreeNode) PatientsFrame.getPatientsTree().getLastSelectedPathComponent();
        patient = (PatientStr) patientNode.getUserObject();
        List<Long> eocIds = command.getEOCsOfPatient(patient.getId());

        if (!eocIds.isEmpty()) {
            for (Long eId : eocIds) {
                acl = command.getByUserAndEOC(Login.getUserId(), eId);
                if (acl == null) {
                    Long userTypeId = command.getUserTypeIdofUser(Login.getUserId());
                    acl = command.getByUserTypeAndEOC(userTypeId, eId);
                }
                if (acl == null) {
                    List<Long> ccpIds = command.getCCPsofEOC(eId);
                    if (!ccpIds.isEmpty()) {
                        for (Long ccpId : ccpIds) {
                            AccessControlListEntity acl = command.getByUserAndCCP(Login.getUserId(), ccpId);
                            if (acl == null) {
                                Long userTypeId = command.getUserTypeIdofUser(Login.getUserId());
                                acl = command.getByUserTypeAndCCP(userTypeId, ccpId);
                            }
                            if (acl != null) {
                                List<String> ccpDetails = command.getCCPDetails(ccpId);
                                CCPStr ccp = new CCPStr();
                                ccp.setId(ccpId);
                                ccp.setEncounter_type(ccpDetails.get(0));
                                ccp.setEncounter_date(ccpDetails.get(1));
                                ccp.setEncounter_time(ccpDetails.get(2));
                                ccp.setEncounter_code(ccpDetails.get(3));
                                ccp.setEncounterId(Long.parseLong(ccpDetails.get(4)));
                                DefaultMutableTreeNode ccpNode = new DefaultMutableTreeNode(ccp, false);
                                model.insertNodeInto(ccpNode, top, top.getChildCount());
                                model.nodeStructureChanged(top);
                                // top.add(ccpNode);
                            }
                        }
                    }
                } else if (acl != null) {
                    ArrayList<String> eocDetails = (ArrayList<String>) command.getEOCDetails(eId);
                    EOCStr eoc = new EOCStr();
                    eoc.setId(Long.parseLong(eocDetails.get(0)));
                    eoc.setCode(eocDetails.get(1));
                    eoc.setStartDate(eocDetails.get(2));
                    eoc.setStartTime(eocDetails.get(3));
                    eoc.setEndDate(eocDetails.get(4));
                    eoc.setEndTime(eocDetails.get(5));
                    eoc.setDiagnostic(eocDetails.get(6));
                    eoc.setDiseaseId(Long.parseLong(eocDetails.get(7)));
                    DefaultMutableTreeNode eocNode = new DefaultMutableTreeNode(eoc, false);
                    model.insertNodeInto(eocNode, top, top.getChildCount());
                    model.nodeStructureChanged(top);
                    //top.add(eocNode);
                }
            }
        }
        initComponents();
        if (top.getChildCount() < 1) {
            JOptionPane.showMessageDialog(null, "You have no access to this data or there is no data to display");
            this.setVisible(false);

        } else {
            for (int i = 0; i < EOCTree.getRowCount(); i++) {
                EOCTree.expandRow(i);
            }

            this.setVisible(true);
        }

    }

    public static JTree getEOCTree() {
        return EOCTree;
    }

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static AccessControlListEntity getAcl() {
        return acl;
    }

    public static PatientStr getPatient() {
        return patient;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        EOC_tree = EOCTree;
        jLabel2 = new javax.swing.JLabel();
        viewPatient_bt = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Episodes of Care");

        jScrollPane1.setViewportView(EOC_tree);

        jLabel2.setText("Right click an episode of care or a healthcare service to see options");

        viewPatient_bt.setText("View Patient Details");
        viewPatient_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewPatient_btActionPerformed(evt);
            }
        });

        jButton1.setText("close window");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(viewPatient_bt))
                        .addGap(0, 178, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(153, 153, 153)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(197, 197, 197))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addGap(36, 36, 36)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(viewPatient_bt)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(26, 26, 26))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void viewPatient_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewPatient_btActionPerformed
        // TODO add your handling code here:
        ViewPatientDetails frame = new ViewPatientDetails();

        ArrayList<String> p = (ArrayList<String>) command.getPatientInfo(patient.getId());
        try {
            frame.getFull_Name_tf().setText((String) p.get(0));
            frame.getFull_Name_tf().setEditable(false);
            frame.getCnp_tf().setText(p.get(1) + "");
            frame.getCnp_tf().setEditable(false);
            frame.getHealthInsurance_tf().setText(p.get(2) + "");
            frame.getHealthInsurance_tf().setEditable(false);
            frame.getAge_tf().setText(p.get(3) + "");
            frame.getAge_tf().setEditable(false);
            frame.getBloodType_tf().setText(p.get(4) + "");
            frame.getBloodType_tf().setEditable(false);
            frame.getEthnicity_tf().setText(p.get(5) + "");
            frame.getEthnicity_tf().setEditable(false);
            frame.getEmail_tf().setText(p.get(6) + "");
            frame.getEmail_tf().setEditable(false);
            if (p.size() == 12) {
                frame.getCity_tf().setText(p.get(8));
                frame.getCountry_tf().setText(p.get(9));
                frame.getStreet_tf().setText(p.get(10));
                frame.getNumber_tf().setText(p.get(11));

            }
            frame.getCity_tf().setEditable(false);
            frame.getCountry_tf().setEditable(false);
            frame.getStreet_tf().setEditable(false);
            frame.getNumber_tf().setEditable(false);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            frame.setResizable(false);
        } catch (Exception ex) {
            Logger.getLogger(EpisodeOfCareFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_viewPatient_btActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EpisodeOfCareFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EpisodeOfCareFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EpisodeOfCareFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EpisodeOfCareFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EpisodeOfCareFrame("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTree EOC_tree;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton viewPatient_bt;
    // End of variables declaration//GEN-END:variables
}
