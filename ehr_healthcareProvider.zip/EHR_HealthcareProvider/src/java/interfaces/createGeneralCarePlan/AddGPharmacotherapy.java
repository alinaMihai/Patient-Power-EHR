/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.createGeneralCarePlan;

import doctor_ws.PlannedPharmacotherapyEntity;
import episodeofcareprj.Controller;
import interfaces.editGeneralCarePlan.EditGeneralCarePlan;
import interfaces.editGeneralCarePlan.EditGeneralMedicineTreeAction;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import utils.MedicineS;
import utils.Pharmacotherapy;

/**
 *
 * @author Alina
 */
public class AddGPharmacotherapy extends javax.swing.JFrame {

    private String name;
    protected static PlannedPharmacotherapyEntity pharmacotherapyObj = null;
    private Controller command;
    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    private static JTree medicinesTree;
    private DefaultMutableTreeNode phNode;
    private Pharmacotherapy ph;

    /**
     * Creates new form AddPharmacotherapy
     */
    public AddGPharmacotherapy(String name) {
        super(name);
        command = Controller.getInstance();

        top = new DefaultMutableTreeNode("Medicines", true);
        medicinesTree = new JTree(top);
        model = (DefaultTreeModel) medicinesTree.getModel();
        initComponents();
        
        //    medicinesTree.addMouseListener(new MedicineDoubleClickTreeAction(medicinesTree));
        if (this.getTitle().equals("Add Pharmacotherapy")) {
            edit_info.setVisible(false);
            edit_info2.setVisible(false);
            medicinesTree.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    if (e.getClickCount() == 2) {
                        TreePath path = medicinesTree.getPathForLocation(e.getX(), e.getY());
                        DefaultMutableTreeNode selectionGroup = (DefaultMutableTreeNode) medicinesTree.getLastSelectedPathComponent();
                        Rectangle pathBounds = medicinesTree.getUI().getPathBounds(medicinesTree, path);

                        if (selectionGroup.getAllowsChildren() == true) {
                            if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                                AddGMedicine frame = new AddGMedicine("Add Medicine");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                        }
                    }
                }
            });
            //        medicinesTree.addMouseListener(new MedicinesTreeAction(medicinesTree));
        }
        if (this.getTitle().equals("Edit Pharmacotherapy")) {
            //medicinesTree.addMouseListener(new EditMedicineTreeAction(medicinesTree, EditEOC.getAcl()));
            medicinesTree.addMouseListener(new EditGeneralMedicineTreeAction(medicinesTree));
            edit_info.setVisible(true);
            edit_info2.setVisible(true);
            add_info.setVisible(false);
            phNode = (DefaultMutableTreeNode) EditGeneralCarePlan.getHcItemsTree().getLastSelectedPathComponent();
            ph = (Pharmacotherapy) phNode.getUserObject();

            if (!ph.getMedicines().isEmpty()) {
                for (MedicineS m : ph.getMedicines()) {
                    utils.MedicineS medicine = new utils.MedicineS();
                    medicine.setId(m.getId());
                    medicine.setName(m.getName());
                    medicine.setCode(m.getCode());
                    medicine.setDose(m.getDose());
                    medicine.setPriceUnit(m.getPriceUnit());
                    medicine.setPrice(m.getPrice());
                    medicine.setStrength(m.getStrength());
                    medicine.setHowTaken(m.getHowTaken());
                    medicine.setReasonForTaking(m.getReasonForTaking());
                    DefaultMutableTreeNode medNode = new DefaultMutableTreeNode(medicine, false);
                    top.add(medNode);
                }
            }
        }

        for (int i = 0; i < medicinesTree.getRowCount(); i++) {
            medicinesTree.expandRow(i);
        }
    }

    public void setData() {

        name = name_tf.getText();
    }

    public JTextField getName_tf() {
        return name_tf;
    }

    public JLabel getTitle_label() {
        return title_label;
    }

    public static DefaultMutableTreeNode getTop() {
        return top;
    }

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static JTree getMedicinesTree() {
        return medicinesTree;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        title_label = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ok_bt = new javax.swing.JButton();
        cancel_bt = new javax.swing.JButton();
        name_tf = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = medicinesTree;
        add_info = new javax.swing.JLabel();
        edit_info2 = new javax.swing.JLabel();
        edit_info = new javax.swing.JLabel();

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        title_label.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        title_label.setText("Add Pharmacotherapy");

        jLabel3.setText("Name*");

        ok_bt.setText("OK");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        cancel_bt.setText("Cancel");
        cancel_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_btActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(jTree1);

        add_info.setText("Double click the medicines node to add a new medicine");

        edit_info2.setText("Right click the medicines group to add a new medicine");

        edit_info.setText("Right click a medicine node to view options");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name_tf)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ok_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cancel_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(add_info)
                            .addComponent(edit_info2)
                            .addComponent(edit_info)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 635, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addComponent(title_label, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                        .addGap(164, 164, 164)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(title_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30)
                .addComponent(add_info)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(edit_info2)
                .addGap(9, 9, 9)
                .addComponent(edit_info)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ok_bt)
                    .addComponent(cancel_bt))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed
        // TODO add your handling code here:
        setData();
        if (!name.equals("")) {
            utils.Pharmacotherapy pharmacotherapy = new utils.Pharmacotherapy();
            pharmacotherapy.setName(name);
            for (int i = 0; i < top.getChildCount(); i++) {
                DefaultMutableTreeNode medicineNode = (DefaultMutableTreeNode) top.getChildAt(i);
                MedicineS medicine = (MedicineS) medicineNode.getUserObject();
                pharmacotherapy.getMedicines().add(medicine);
            }

            if (this.getTitle().equals("Add Pharmacotherapy")) {
                //    pharmacotherapyObj = command.addGeneralPharmacotherapy(AddDisease.GeneralcarePlanId, name);
                pharmacotherapy.setAdd(true);
                DefaultMutableTreeNode hcItem = new DefaultMutableTreeNode(pharmacotherapy, true);
                AddGCarePlan.groupPh.add(hcItem);
                AddGCarePlan.getModel().reload();
                for (int i = 0; i < AddGCarePlan.getHcItemsTree().getRowCount(); i++) {
                    AddGCarePlan.getHcItemsTree().expandRow(i);
                }
                this.setVisible(false);

                /*      pharmacotherapy.setId(pharmacotherapyObj.getId());
                 JOptionPane.showMessageDialog(null, "Pharmacotherapy successfully added");
                 this.setVisible(false);

                 DefaultMutableTreeNode hcItem = new DefaultMutableTreeNode(pharmacotherapy, true);
                 AddGCarePlan.groupPh.add(hcItem);
                 AddGCarePlan.getModel().reload();
                 for (int i = 0; i < AddGCarePlan.getHcItemsTree().getRowCount(); i++) {
                 AddGCarePlan.getHcItemsTree().expandRow(i);
                 }*/
            }
            if (this.getTitle().equals("Edit:Add Pharmacotherapy")) {
                pharmacotherapy.setAdd(true);
                DefaultMutableTreeNode hcItem = new DefaultMutableTreeNode(pharmacotherapy, true);
                EditGeneralCarePlan.getGroupPh().add(hcItem);
                EditGeneralCarePlan.getModel().reload();
                for (int i = 0; i < EditGeneralCarePlan.getHcItemsTree().getRowCount(); i++) {
                    EditGeneralCarePlan.getHcItemsTree().expandRow(i);
                }
                this.setVisible(false);
            }
            if (this.getTitle().equals("Edit Pharmacotherapy")) {

                DefaultMutableTreeNode selected_phNode = (DefaultMutableTreeNode) EditGeneralCarePlan.getHcItemsTree().getLastSelectedPathComponent();
                Pharmacotherapy pharmacotherapy_to_update = (Pharmacotherapy) selected_phNode.getUserObject();
                if (pharmacotherapy_to_update.isAdd()) {
                    pharmacotherapy_to_update.setName(name);
                    pharmacotherapy_to_update.setUpdate(true);

                } else {
                    Long phId = pharmacotherapy_to_update.getId();
                    pharmacotherapy.setId(phId);
                    command.updatePharmacotherapy(phId, name, "", "", "");
                    selected_phNode.setUserObject(pharmacotherapy);
                }

                EditGeneralCarePlan.getModel().reload();
                for (int i = 0; i < EditGeneralCarePlan.getHcItemsTree().getRowCount(); i++) {
                    EditGeneralCarePlan.getHcItemsTree().expandRow(i);
                }
                this.setVisible(false);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please fill in all required fields");
        }
    }//GEN-LAST:event_ok_btActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void cancel_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_btActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_cancel_btActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddGPharmacotherapy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddGPharmacotherapy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddGPharmacotherapy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddGPharmacotherapy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddGPharmacotherapy("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel add_info;
    private javax.swing.JButton cancel_bt;
    private javax.swing.JLabel edit_info;
    private javax.swing.JLabel edit_info2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTree jTree1;
    private javax.swing.JTextField name_tf;
    private javax.swing.JButton ok_bt;
    private javax.swing.JLabel title_label;
    // End of variables declaration//GEN-END:variables
}
