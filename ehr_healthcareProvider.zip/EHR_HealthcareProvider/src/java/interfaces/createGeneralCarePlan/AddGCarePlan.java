/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.createGeneralCarePlan;

import doctor_ws.PlannedPharmacotherapyEntity;
import episodeofcareprj.Controller;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import utils.MedicineS;
import utils.Pharmacotherapy;
import utils.Procedure;
import utils.QualObs;
import utils.QuanObs;

/**
 *
 * @author Alina
 */
public class AddGCarePlan extends javax.swing.JFrame {

    private static DefaultMutableTreeNode top;
    private static DefaultTreeModel model;
    private static JTree hcItemsTree;
    private DefaultMutableTreeNode selectionGroup;
    protected static DefaultMutableTreeNode groupP;
    protected static DefaultMutableTreeNode groupPh;
    protected static DefaultMutableTreeNode groupQualObs;
    protected static DefaultMutableTreeNode groupQuanObs;
    private Controller command;

    /**
     * Creates new form AddCarePlan
     */
    public AddGCarePlan(String name) {
        super(name);
        command = Controller.getInstance();
        top = new DefaultMutableTreeNode("HC Items");
        hcItemsTree = new JTree(top);
        hcItemsTree.setRootVisible(false);
        hcItemsTree.setShowsRootHandles(true);
        model = (DefaultTreeModel) hcItemsTree.getModel();
        groupP = new DefaultMutableTreeNode("Procedures", true);
        model.insertNodeInto(groupP, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupQualObs = new DefaultMutableTreeNode("Qualitative Observations", true);
        model.insertNodeInto(groupQualObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupQuanObs = new DefaultMutableTreeNode("Quantitative Observations", true);
        model.insertNodeInto(groupQuanObs, top, top.getChildCount());
        model.nodeStructureChanged(top);
        groupPh = new DefaultMutableTreeNode("Pharmacotherapy", true);
        model.insertNodeInto(groupPh, top, top.getChildCount());
        model.nodeStructureChanged(top);

        hcItemsTree.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    TreePath path = hcItemsTree.getPathForLocation(e.getX(), e.getY());
                    selectionGroup = (DefaultMutableTreeNode) hcItemsTree.getLastSelectedPathComponent();
                    Rectangle pathBounds = hcItemsTree.getUI().getPathBounds(hcItemsTree, path);
                    if (selectionGroup.getAllowsChildren() == true) {
                        if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                            if (selectionGroup.toString().equals("Procedures")) {
                                AddGProcedure frame = new AddGProcedure("Add Procedure");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }

                            if (selectionGroup.toString().equals("Qualitative Observations")) {
                                AddGQualitativeObservation frame = new AddGQualitativeObservation("Add Qualitative Observation");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                            if (selectionGroup.toString().equals("Quantitative Observations")) {
                                AddGQuantitativeObservation frame = new AddGQuantitativeObservation("Add Quantitative Observation");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                            if (selectionGroup.toString().equals("Pharmacotherapy")) {
                                AddGPharmacotherapy frame = new AddGPharmacotherapy("Add Pharmacotherapy");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                            /*  if (selectionGroup.getUserObject() instanceof Pharmacotherapy) {
                             AddGMedicine frame = new AddGMedicine("Add Medicine");
                             frame.setResizable(false);
                             frame.setLocationRelativeTo(null);
                             frame.setVisible(true);
                             }*/
                        }

                    }
                }
            }
        });

        for (int i = 0; i < hcItemsTree.getRowCount(); i++) {
            hcItemsTree.expandRow(i);
        }
        initComponents();
    }

    public static JTree getHcItemsTree() {
        return hcItemsTree;
    }

    public static void setHcItemsTree(JTree hcItemsTree) {
        AddGCarePlan.hcItemsTree = hcItemsTree;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ok_bt = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        hcItems_tree = hcItemsTree;
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Create General  Care Plan");

        jLabel2.setText("Healthcare Services");

        ok_bt.setText("OK");
        ok_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ok_btActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(hcItems_tree);

        jButton1.setText("Cancel");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Double click a heathcare service group to add new service");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(109, 109, 109))
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ok_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(184, 184, 184)
                                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel2)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 14, Short.MAX_VALUE)
                .addGap(15, 15, 15)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ok_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(34, 34, 34))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static DefaultTreeModel getModel() {
        return model;
    }

    public static void setModel(DefaultTreeModel model) {
        AddGCarePlan.model = model;
    }

    private void ok_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ok_btActionPerformed
        // TODO add your handling code here:
        //  JOptionPane.showMessageDialog(null, "Care Plan successfully created");
        Long generalCarePlanId = AddDisease.GeneralcarePlanId;
        if (hcItemsTree.getRowCount() > 1) {
            for (int i = 0; i < top.getChildCount(); i++) {
                DefaultMutableTreeNode groupNode = (DefaultMutableTreeNode) top.getChildAt(i);
                String group = (String) groupNode.getUserObject();
                if (group.equals("Procedures")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode procedureNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        Procedure p = (Procedure) procedureNode.getUserObject();
                        if (p.isAdd()) {
                            command.addGeneralProcedure(generalCarePlanId, p.getCode(), p.getName(), p.getNotes());
                        }
                    }
                }

                if (group.equals("Qualitative Observations")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode qqNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        QualObs qq = (QualObs) qqNode.getUserObject();
                        if (qq.isAdd()) {
                            command.addGeneralQualitativeObservation(generalCarePlanId, qq.getCode(), qq.getName(), qq.getNotes(), qq.getDescription());
                        }
                    }
                }

                if (group.equals("Quantitative Observations")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode qqNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        QuanObs qq = (QuanObs) qqNode.getUserObject();
                        if (qq.isAdd()) {
                            command.addGeneralQuantitativeObservation(generalCarePlanId, qq.getCode(), qq.getName(), qq.getMeasurementQ(), qq.getDescription());
                        }
                    }
                }

                if (group.equals("Pharmacotherapy")) {
                    for (int ii = 0; ii < groupNode.getChildCount(); ii++) {
                        DefaultMutableTreeNode phNode = (DefaultMutableTreeNode) groupNode.getChildAt(ii);
                        Pharmacotherapy ph = (Pharmacotherapy) phNode.getUserObject();
                        if (ph.isAdd()) {
                            PlannedPharmacotherapyEntity pharmacotherapyObj = command.addGeneralPharmacotherapy(generalCarePlanId, ph.getName());
                            if (!ph.getMedicines().isEmpty()) {
                                for (MedicineS medicine : ph.getMedicines()) {
                                    if (medicine.isAdd()) {
                                        command.addMedicine(pharmacotherapyObj.getId(), medicine.getName(), medicine.getCode(), medicine.getPriceUnit(),
                                                medicine.getPrice(), medicine.getStrength(),
                                                medicine.getDose(), medicine.getHowTaken(), medicine.getReasonForTaking(),
                                                medicine.getDateStarted(), medicine.getDateStopped());

                                    }
                                }
                            }
                        } else if (!ph.getMedicines().isEmpty()) {
                            for (MedicineS medicine : ph.getMedicines()) {
                                if (medicine.isAdd()) {
                                    command.addMedicine(ph.getId(), medicine.getName(), medicine.getCode(), medicine.getPriceUnit(),
                                            medicine.getPrice(), medicine.getStrength(),
                                            medicine.getDose(), medicine.getHowTaken(), medicine.getReasonForTaking(),
                                            medicine.getDateStarted(), medicine.getDateStopped());

                                }
                            }
                        }
                    }
                }
            }
        }
        JOptionPane.showMessageDialog(null, "General Care Plan successfully created");
        this.setVisible(false);
    }//GEN-LAST:event_ok_btActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddGCarePlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddGCarePlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddGCarePlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddGCarePlan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddGCarePlan("").setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTree hcItems_tree;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton ok_bt;
    // End of variables declaration//GEN-END:variables
}
