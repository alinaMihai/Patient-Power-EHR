/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.PlannedProcedureEntity;



/**
 *
 * @author Alina
 */
public class Procedure extends PlannedProcedureEntity{
private boolean add=false;

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }

    @Override
    public String toString() {
        return super.name;
    }
}
