/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import interfaces.addEOC.AddMedicine;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class MedicinesTreeAction extends MouseAdapter {

    protected JTree hcItemsTree;

    public MedicinesTreeAction(JTree tree) {
        this.hcItemsTree = tree;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (e.getClickCount() == 2) {
            TreePath path = hcItemsTree.getPathForLocation(e.getX(), e.getY());
            final DefaultMutableTreeNode selectionGroup = (DefaultMutableTreeNode) hcItemsTree.getLastSelectedPathComponent();
            Rectangle pathBounds = hcItemsTree.getUI().getPathBounds(hcItemsTree, path);

            if (selectionGroup.getAllowsChildren() == true) {
                if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                    AddMedicine frame = new AddMedicine("Add Medicine");
                    frame.setResizable(false);
                    frame.setLocationRelativeTo(null);
                    frame.setVisible(true);
                }
            }


        }
    }
}
