/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.EpisodeOfCareEntity2;

/**
 *
 * @author Alina
 */
public class EOCStr extends EpisodeOfCareEntity2 {

    private String diagnostic;
    private Long diseaseId;

    public String getDiagnostic() {
        return diagnostic;
    }

    public void setDiagnostic(String diagnostic) {
        this.diagnostic = diagnostic;
    }

    public Long getDiseaseId() {
        return diseaseId;
    }

    public void setDiseaseId(Long diseaseId) {
        this.diseaseId = diseaseId;
    }

    @Override
    public String toString() {
        return "Episode of care for " + diagnostic + " diagnostic";
    }
}
