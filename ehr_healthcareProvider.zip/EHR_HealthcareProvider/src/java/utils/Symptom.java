/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.SymptomEntity;



/**
 *
 * @author Alina
 */
public class Symptom extends SymptomEntity {
   private boolean add;

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }
   
    @Override
    public String toString() {
        return super.name;
    }
}
