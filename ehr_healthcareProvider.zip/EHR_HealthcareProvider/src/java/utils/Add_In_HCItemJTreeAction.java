/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import interfaces.addEOC.AddMedicine;
import interfaces.addEOC.AddPharmacotherapy;
import interfaces.addEOC.AddProcedure;
import interfaces.addEOC.AddQualitativeObservation;
import interfaces.addEOC.AddQuantitativeObservation;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class Add_In_HCItemJTreeAction extends MouseAdapter {

    protected JTree hcItemsTree;

    public Add_In_HCItemJTreeAction(JTree tree) {
        this.hcItemsTree = tree;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isRightMouseButton(e)) {
            TreePath path = hcItemsTree.getPathForLocation(e.getX(), e.getY());
            final DefaultMutableTreeNode selectionGroup = (DefaultMutableTreeNode) hcItemsTree.getLastSelectedPathComponent();
            Rectangle pathBounds = hcItemsTree.getUI().getPathBounds(hcItemsTree, path);

            if (selectionGroup.getAllowsChildren() == true) {
                if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem jt = new JMenuItem("Add New Item");
                    jt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (selectionGroup.toString().equals("Procedures")) {
                                AddProcedure frame = new AddProcedure("Add Procedure");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }

                            if (selectionGroup.toString().equals("Qualitative Observations")) {
                                AddQualitativeObservation frame = new AddQualitativeObservation("Add Qualitative Observation");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                            if (selectionGroup.toString().equals("Quantitative Observations")) {
                                AddQuantitativeObservation frame = new AddQuantitativeObservation("Add Quantitative Observation");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                            if (selectionGroup.toString().equals("Pharmacotherapy")) {
                                AddPharmacotherapy frame = new AddPharmacotherapy("Add Pharmacotherapy");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                          /*  if (selectionGroup.getUserObject() instanceof Pharmacotherapy) {
                                AddMedicine frame = new AddMedicine("Add Medicine");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }*/
                        }
                    });
                    menu.add(jt);
                    menu.show(hcItemsTree, pathBounds.x, pathBounds.y + pathBounds.height);
                }
            }
        }
    }
}
