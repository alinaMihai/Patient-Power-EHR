/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.QualitativeObservationEntity;

/**
 *
 * @author Alina
 */
public class QualObs extends QualitativeObservationEntity {

    private boolean add = false;

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }

    @Override
    public String toString() {
        return super.name;
    }
}
