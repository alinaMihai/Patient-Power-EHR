/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.AccessControlListEntity;
import episodeofcareprj.Controller;
import interfaces.addEOC.AddMedicine;
import interfaces.addEOC.AddPharmacotherapy;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class EditMedicineTreeAction extends MouseAdapter {

    private AccessControlListEntity acl = null;
    private JTree tree;
    private DefaultMutableTreeNode selectionNode;
    private MedicineS med;
    private Controller command;

    public EditMedicineTreeAction(JTree tree, AccessControlListEntity acl) {
        this.tree = tree;
        command = Controller.getInstance();
        this.acl = acl;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        try {
            if (SwingUtilities.isRightMouseButton(e)) {
                TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
                Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
                if (selectionNode.getAllowsChildren() == false) {
                    med = (MedicineS) selectionNode.getUserObject();
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                        JPopupMenu menu = new JPopupMenu();
                        JMenuItem jt1 = new JMenuItem("Edit Medicine");
                        jt1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                AddMedicine frame = new AddMedicine("Edit Medicine");
                                frame.getTitle_label().setText("Edit " + med.getName());
                                frame.getCode_tf().setText(med.getCode());
                                frame.getName_tf().setText(med.getName());
                                frame.getDateStarted_tf().setText(med.getDateStarted());
                                frame.getDateStopped_tf().setText(med.getDateStopped());
                                frame.getStrength_tf().setText(med.getStrength());
                                frame.getHowTaken_tf().setText(med.getHowTaken());
                                frame.getReason_for_taking_ta().setText(med.getReasonForTaking());
                                frame.getDose_ta().setText(med.getDose());
                                frame.getPrice_tf().setText(med.getPrice() + "");
                                frame.getPrice_unit_cb().setSelectedItem(med.getPriceUnit());
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            }
                        });
                        menu.add(jt1);
                        JMenuItem jt2 = new JMenuItem("Delete Medicine");
                        jt2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (acl.isCanDelete()) {
                                    if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete Medicine", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {

                                        command.deleteMedicine(med.getId());
                                        AddPharmacotherapy.getModel().removeNodeFromParent(selectionNode);
                                        AddPharmacotherapy.getModel().reload();
                                        for (int i = 0; i < AddPharmacotherapy.getMedicinesTree().getRowCount(); i++) {
                                            AddPharmacotherapy.getMedicinesTree().expandRow(i);
                                        }
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(null, "Delete right is not allowed");
                                }
                            }
                        });
                        menu.add(jt2);
                        menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                    }
                } else {
                    JPopupMenu menu = new JPopupMenu();
                    JMenuItem jmi3 = new JMenuItem("Add Medicine");
                    jmi3.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (acl.isCanInsert()) {
                                AddMedicine frame = new AddMedicine("Edit:Add Medicine");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);
                                frame.setVisible(true);
                            } else {
                                JOptionPane.showMessageDialog(null, "Insert right is not allowed");
                            }
                        }
                    });
                    menu.add(jmi3);
                    menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                }

            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Please select an object from the list");
        }
    }
}
