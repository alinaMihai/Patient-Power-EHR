/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import interfaces.ViewEOC.EpisodeOfCareFrame;
import interfaces.addEOC.AddEOC;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class PatientActionJTree extends MouseAdapter {

    protected JTree tree;
    private DefaultMutableTreeNode selectionNode;
    private PatientStr patient;

    public PatientActionJTree(JTree tree) {
        this.tree = tree;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isRightMouseButton(e)) {
            int selRow = tree.getRowForLocation(e.getX(), e.getY());
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (selRow > 0) {
                if (selectionNode.getAllowsChildren() == false) {
                    patient = (PatientStr) selectionNode.getUserObject();
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                        JPopupMenu menu = new JPopupMenu();
                        JMenuItem jt1 = new JMenuItem("View Episodes of care");
                        jt1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                EpisodeOfCareFrame frame = new EpisodeOfCareFrame("View Episodes of care");
                                frame.setResizable(false);
                                frame.setLocationRelativeTo(null);

                            }
                        });
                        menu.add(jt1);
                        if (patient.isOfDoctor()) {
                            JMenuItem jt2 = new JMenuItem("Add new Episode of care");
                            jt2.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent ae) {
                                    AddEOC frame = new AddEOC("Add EOC");
                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);

                                }
                            });
                            menu.add(jt2);
                        }
                        menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                    }
                }
            }
        }
    }
}
