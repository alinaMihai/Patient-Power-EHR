/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.QuantitativeObservationEntity;

/**
 *
 * @author Alina
 */
public class QuanObs extends QuantitativeObservationEntity {

    private boolean add = false;

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }

    public String toString() {
        return super.name;
    }
}
