/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.MedicineEntity;
import doctor_ws.PlannedHCitemEntity;
import doctor_ws.PlannedPharmacotherapyEntity;
import doctor_ws.PlannedProcedureEntity;
import doctor_ws.QualitativeObservationEntity;
import doctor_ws.QuantitativeObservationEntity;
import episodeofcareprj.Controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 *
 * @author Alina
 */
public class Utils {

    private static Controller command = Controller.getInstance();

    public static XMLGregorianCalendar StringToXMLGregorianCalendar(String dateString) throws ParseException, DatatypeConfigurationException {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date d = sdf.parse(dateString);
        GregorianCalendar g = new GregorianCalendar();
        g.setTime(d);
        XMLGregorianCalendar date = DatatypeFactory.newInstance().newXMLGregorianCalendar(g);
        date.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
        return date;
    }

    public static void retrieveHCItemTree(DefaultTreeModel model, List<PlannedHCitemEntity> hcItems, DefaultMutableTreeNode groupP,
            DefaultMutableTreeNode groupQualObs, DefaultMutableTreeNode groupQuanObs, DefaultMutableTreeNode groupPh,
            String name) {
        List<MedicineEntity> medicines;
        if (!hcItems.isEmpty()) {
            for (PlannedHCitemEntity phciI : hcItems) {
                if (phciI instanceof PlannedProcedureEntity) {
                    PlannedProcedureEntity phci = (PlannedProcedureEntity) phciI;
                    utils.Procedure procedure = new utils.Procedure();
                    procedure.setName(phci.getName() + name);
                    procedure.setCode(phci.getCode());
                    procedure.setDateOp(phci.getDateOp());
                    procedure.setStateHCI(phci.getStateHCI());
                    procedure.setTimeOp(phci.getTimeOp());
                    procedure.setNotes(phci.getNotes());
                    procedure.setId(phci.getId());
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(procedure, false);
                        groupP.add(item);
                }
                if (phciI instanceof QualitativeObservationEntity) {
                    QualitativeObservationEntity phci = (QualitativeObservationEntity) phciI;
                    utils.QualObs qualObs = new utils.QualObs();
                    qualObs.setName(phci.getName() + name);
                    qualObs.setCode(phci.getCode());
                    qualObs.setDateOp(phci.getDateOp());
                    qualObs.setStateHCI(phci.getStateHCI());
                    qualObs.setTimeOp(phci.getTimeOp());
                    qualObs.setNotes(phci.getNotes());
                    qualObs.setDescription(phci.getDescription());
                    qualObs.setId(phci.getId());
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(qualObs, false);
                        groupQualObs.add(item);
                }
                if (phciI instanceof QuantitativeObservationEntity) {
                    QuantitativeObservationEntity phci = (QuantitativeObservationEntity) phciI;
                    utils.QuanObs quanObs = new utils.QuanObs();
                    quanObs.setName(phci.getName() + name);
                    quanObs.setCode(phci.getCode());
                    quanObs.setDateOp(phci.getDateOp());
                    quanObs.setStateHCI(phci.getStateHCI());
                    quanObs.setTimeOp(phci.getTimeOp());
                    quanObs.setMeasurementQ(phci.getMeasurementQ());
                    quanObs.setDescription(phci.getDescription());
                    quanObs.setId(phci.getId());
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(quanObs, false);
                        groupQuanObs.add(item);
                }
                if (phciI instanceof PlannedPharmacotherapyEntity) {
                    PlannedPharmacotherapyEntity phci = (PlannedPharmacotherapyEntity) phciI;
                    utils.Pharmacotherapy pharmacotherapy = new utils.Pharmacotherapy();
                    pharmacotherapy.setId(phci.getId());
                    pharmacotherapy.setName(phci.getName() + name);
                    pharmacotherapy.setDateOp(phci.getDateOp());
                    pharmacotherapy.setStateHCI(phci.getStateHCI());
                    pharmacotherapy.setTimeOp(phci.getTimeOp());
                    medicines = command.getMedicinesOfPharmacotherapy(phci.getId());
                    DefaultMutableTreeNode item = new DefaultMutableTreeNode(pharmacotherapy, false);
                        groupPh.add(item);
                    if (!medicines.isEmpty()) {
                        for (MedicineEntity m : medicines) {
                            utils.MedicineS med = new utils.MedicineS();
                            med.setCode(m.getCode());
                            med.setName(m.getName() + name);
                            med.setDose(m.getDose());
                            med.setStrength(m.getStrength());
                            med.setHowTaken(m.getHowTaken());
                            med.setReasonForTaking(m.getReasonForTaking());
                            med.setDateStarted(m.getDateStarted());
                            med.setDateStopped(m.getDateStopped());
                            med.setPrice(m.getPrice());
                            med.setPriceUnit(m.getPriceUnit());
                            med.setId(m.getId());
                          //  DefaultMutableTreeNode medicineNode = new DefaultMutableTreeNode(med, false);
                            pharmacotherapy.getMedicines().add(med);
                        }
                    }
                }
            }
        }
      
    }

    public static void removeUnusedGroups(DefaultTreeModel model, List<DefaultMutableTreeNode> groups) {
        for (DefaultMutableTreeNode group : groups) {
            if (group.getChildCount() == 0) {
                model.removeNodeFromParent(group);
            }
        }
    }
}
