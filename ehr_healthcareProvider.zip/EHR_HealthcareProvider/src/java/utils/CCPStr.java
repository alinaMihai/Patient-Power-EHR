/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import hcwebservices.CustomizedCarePlanEntity;

/**
 *
 * @author Alina
 */
public class CCPStr extends CustomizedCarePlanEntity {
    private Long encounterId;
   private String encounter_date;
   private String encounter_type;
   private String encounter_code;
   private String encounter_time;

    public String getEncounter_date() {
        return encounter_date;
    }

    public void setEncounter_date(String encounter_date) {
        this.encounter_date = encounter_date;
    }

    public String getEncounter_type() {
        return encounter_type;
    }

    public void setEncounter_type(String encounter_type) {
        this.encounter_type = encounter_type;
    }

    public String getEncounter_code() {
        return encounter_code;
    }

    public void setEncounter_code(String encounter_code) {
        this.encounter_code = encounter_code;
    }

    public String getEncounter_time() {
        return encounter_time;
    }

    public void setEncounter_time(String encounter_time) {
        this.encounter_time = encounter_time;
    }

    public Long getEncounterId() {
        return encounterId;
    }

    public void setEncounterId(Long encounterId) {
        this.encounterId = encounterId;
    }

    @Override
    public String toString() {
        return "HCServices on: " + encounter_date + " type " + encounter_type;
    }
}
