/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.MedicineEntity;
import doctor_ws.PlannedPharmacotherapyEntity;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alina
 */
public class Pharmacotherapy extends PlannedPharmacotherapyEntity {
    private List<MedicineS> medicines;
    private boolean add = false;
   private boolean update=false;
    public Pharmacotherapy(){
    medicines=new ArrayList<MedicineS>();
    }
    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }

    public List<MedicineS> getMedicines() {
        return medicines;
    }

    public boolean isUpdate() {
        return update;
    }

    public void setUpdate(boolean update) {
        this.update = update;
    }

  
    @Override
    public String toString() {
        return super.name;
    }
}
