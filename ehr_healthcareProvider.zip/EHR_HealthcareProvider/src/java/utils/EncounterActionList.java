/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import interfaces.ViewEOC.ViewEncounter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JList;
import javax.swing.ListModel;

/**
 *
 * @author Alina
 */
public class EncounterActionList extends MouseAdapter {

    protected JList list;

    public EncounterActionList(JList l) {
        list = l;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            int index = list.locationToIndex(e.getPoint());
            ListModel dlm = list.getModel();
            EncounterStr item = (EncounterStr) dlm.getElementAt(index);
            list.ensureIndexIsVisible(index);
            ViewEncounter frame = new ViewEncounter("View Encounter");
            ViewEncounter.getTitle_lb().setText(item.getConsultType());
            ViewEncounter.getCode_tf().setText(item.getCode());
            ViewEncounter.getCode_tf().setEditable(false);
            ViewEncounter.getConsult_date_tf().setText(item.getConsultDate());
            ViewEncounter.getConsult_date_tf().setEditable(false);
            ViewEncounter.getConsult_time_tf().setText(item.getConsultTime());
            ViewEncounter.getConsult_time_tf().setEditable(false);
            ViewEncounter.getConsult_type_tf().setText(item.getConsultType());
            ViewEncounter.getConsult_type_tf().setEditable(false);
           
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            frame.setResizable(false);

        }
    }
}
