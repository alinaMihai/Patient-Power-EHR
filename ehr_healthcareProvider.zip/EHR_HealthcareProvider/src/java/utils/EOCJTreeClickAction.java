/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import doctor_ws.AccessControlListEntity;
import episodeofcareprj.Controller;
import episodeofcareprj.Login;
import interfaces.EditEOC.EditEOC;
import interfaces.EditEOC.EditEncounterFrame;
import interfaces.ViewEOC.EpisodeOfCareFrame;
import interfaces.ViewEOC.ViewEOC;
import interfaces.ViewEOC.ViewEncounter;
import interfaces.addEncounterToEOC.AddEncounterToEOCframe;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class EOCJTreeClickAction extends MouseAdapter {

    protected JTree tree;
    private Controller command;
    private AccessControlListEntity acl = null;
    private EOCStr eoc = null;
    private CCPStr ccp = null;
    private DefaultMutableTreeNode selectionNode;
    private AccessControlListEntity acl_ccp = null;

    public EOCJTreeClickAction(JTree tree) {
        this.tree = tree;
        command = Controller.getInstance();

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isRightMouseButton(e)) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);

            if (selectionNode.getAllowsChildren() == false) {
                if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                    if (selectionNode.getUserObject() instanceof EOCStr) {
                        this.eoc = (EOCStr) selectionNode.getUserObject();
                        acl = command.getByUserAndEOC(Login.getUserId(), eoc.getId());
                        if (acl == null) {
                            Long userTypeId = command.getUserTypeIdofUser(Login.getUserId());
                            acl = command.getByUserTypeAndEOC(userTypeId, eoc.getId());
                        }

                        JPopupMenu menu = new JPopupMenu();
                        JMenuItem jt1 = new JMenuItem("View Episode of Care ");
                        jt1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (acl.isCanView()) {
                                    ViewEOC frame = new ViewEOC("View EOC");
                                    frame.getCode_tf().setText(eoc.getCode());
                                    frame.getCode_tf().setEditable(false);
                                    frame.getStart_date_tf().setText(eoc.getStartDate());
                                    frame.getStart_date_tf().setEditable(false);
                                    frame.getStart_time_tf().setText(eoc.getStartTime());
                                    frame.getStart_time_tf().setEditable(false);
                                    frame.getEnd_date_tf().setText(eoc.getEndDate());
                                    frame.getEnd_date_tf().setEditable(false);
                                    frame.getEnd_time_tf().setText(eoc.getEndTime());
                                    frame.getEnd_time_tf().setEditable(false);
                                    frame.getDiagnostic_tf().setText(eoc.getDiagnostic());
                                    frame.getTitle_lb().setText(eoc.getDiagnostic());
                                    frame.getDiagnostic_tf().setEditable(false);
                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);
                                } else {
                                    JOptionPane.showMessageDialog(null, "View right is not allowed");
                                }
                            }
                        });
                        menu.add(jt1);
                        JMenuItem jt2 = new JMenuItem("Add to Episode of Care");
                        jt2.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (acl != null) {
                                    if (!acl.isCanInsert()) {
                                        JOptionPane.showMessageDialog(null, "Add right is not allowed");
                                    } else {
                                        // open the frame to insert new encounter
                                        AddEncounterToEOCframe frame = new AddEncounterToEOCframe("Add New Encounter");
                                        frame.setResizable(false);
                                        frame.setLocationRelativeTo(null);
                                        frame.setVisible(true);
                                    }
                                }
                            }
                        });
                        menu.add(jt2);
                        JMenuItem jt3 = new JMenuItem("Edit Episode of Care");
                        jt3.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (!acl.isCanUpdate()) {
                                    JOptionPane.showMessageDialog(null, "Edit right is not allowed");
                                } else {
                                    EditEOC frame = new EditEOC("Edit EOC");
                                    frame.getTitle_lb().setText(eoc.getDiagnostic());
                                    frame.getCode_tf().setText(eoc.getCode());
                                    frame.getStart_date_tf().setText(eoc.getStartDate());
                                    frame.getStart_time_tf().setText(eoc.getStartTime());
                                    frame.getEnd_date_tf().setText(eoc.getEndDate());
                                    frame.getEnd_time_tf().setText(eoc.getEndTime());
                                    frame.getDiagnostic_tf().setText(eoc.getDiagnostic());
                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);
                                }
                            }
                        });
                        menu.add(jt3);
                        JMenuItem jt4 = new JMenuItem("Delete Episode of Care");
                        jt4.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (!acl.isCanDelete()) {
                                    JOptionPane.showMessageDialog(null, "Delete right is not allowed");
                                } else {
                                    if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete EOC", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                        command.deleteEOC(eoc.getId());
                                        DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
                                        model.removeNodeFromParent(selectionNode);
                                        model.reload();
                                        for (int i = 0; i < tree.getRowCount(); i++) {
                                            tree.expandRow(i);
                                        }

                                    }
                                }
                            }
                        });
                        menu.add(jt4);
                        menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);
                    } else if (selectionNode.getUserObject() instanceof CCPStr) {
                        this.ccp = (CCPStr) selectionNode.getUserObject();
                        acl_ccp = command.getByUserAndCCP(Login.getUserId(), ccp.getId());
                        if (acl_ccp == null) {
                            Long userTypeId = command.getUserTypeIdofUser(Login.getUserId());
                            acl_ccp = command.getByUserTypeAndCCP(userTypeId, ccp.getId());
                        }
                        JPopupMenu menu = new JPopupMenu();
                        JMenuItem jt1 = new JMenuItem("View HCService ");
                        jt1.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (acl_ccp.isCanView()) {
                                    ViewEncounter frame = new ViewEncounter("View HCService");
                                    ViewEncounter.getTitle_lb().setText(ccp.getEncounter_type());
                                    ViewEncounter.getConsult_type_tf().setText(ccp.getEncounter_type());
                                    ViewEncounter.getConsult_type_tf().setEditable(false);
                                    ViewEncounter.getConsult_date_tf().setText(ccp.getEncounter_date());
                                    ViewEncounter.getConsult_date_tf().setEditable(false);
                                    ViewEncounter.getConsult_time_tf().setText(ccp.getEncounter_time());
                                    ViewEncounter.getConsult_time_tf().setEditable(false);
                                    ViewEncounter.getCode_tf().setText(ccp.getEncounter_code());
                                    ViewEncounter.getCode_tf().setEditable(false);
                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);
                                } else {
                                    JOptionPane.showMessageDialog(null, "View right is not allowed");
                                }
                            }
                        });
                        menu.add(jt1);

                        JMenuItem jt3 = new JMenuItem("Edit HCService");
                        jt3.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (!acl_ccp.isCanUpdate() || !acl_ccp.isCanInsert()) {
                                    JOptionPane.showMessageDialog(null, "Edit right is not allowed");
                                } else {
                                    EditEncounterFrame frame = new EditEncounterFrame("Edit HCService");
                                    frame.getTitle_lb().setText("Edit " + ccp.getEncounter_type());
                                    frame.getConsult_type_tf().setText(ccp.getEncounter_type());
                                    frame.getConsult_date_tf().setText(ccp.getEncounter_date());
                                    frame.getConsult_time_tf().setText(ccp.getEncounter_time());
                                    frame.getCode_tf().setText(ccp.getEncounter_code());
                                    frame.setResizable(false);
                                    frame.setLocationRelativeTo(null);
                                    frame.setVisible(true);
                                }
                            }
                        });
                        menu.add(jt3);
                        JMenuItem jt4 = new JMenuItem("Delete HCService");
                        jt4.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                if (!acl_ccp.isCanDelete()) {
                                    JOptionPane.showMessageDialog(null, "Delete right is not allowed");
                                } else {
                                    if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the object from the database?", "Delete EOC", JOptionPane.YES_NO_CANCEL_OPTION) == 0) {
                                        command.deleteCCP(ccp.getId());
                                        //     EpisodeOfCareFrame.getModel().removeNodeFromParent(selectionNode);
                                        DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
                                        model.removeNodeFromParent(selectionNode);
                                        model.reload();
                                        for (int i = 0; i < tree.getRowCount(); i++) {
                                            tree.expandRow(i);
                                        }
                                    }

                                }
                            }
                        });
                        menu.add(jt4);
                        menu.show(tree, pathBounds.x, pathBounds.y + pathBounds.height);

                    }
                }
            }
        }
    }
}
