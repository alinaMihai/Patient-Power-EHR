/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author Alina
 */
public class ViewCCPJTreeAction extends MouseAdapter {

    protected JTree tree;

    public ViewCCPJTreeAction(JTree tree) {
        this.tree = tree;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int selRow = tree.getRowForLocation(e.getX(), e.getY());
        TreePath selPath = tree.getPathForLocation(e.getX(), e.getY());
        if (e.getClickCount() == 2) {
            TreePath path = tree.getPathForLocation(e.getX(), e.getY());
            DefaultMutableTreeNode selectionNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            Rectangle pathBounds = tree.getUI().getPathBounds(tree, path);
            if (selRow > 0) {
                if (selectionNode.getAllowsChildren() == false) {
                    if (pathBounds != null && pathBounds.contains(e.getX(), e.getY())) {
                        if (selectionNode.getUserObject() instanceof utils.Procedure) {
                            utils.Procedure p = (utils.Procedure) selectionNode.getUserObject();
                            interfaces.addEOC.AddProcedure frame = new interfaces.addEOC.AddProcedure("View Procedure");
                            frame.getCode_tf().setText(p.getCode());
                            frame.getName_tf().setText(p.getName());
                            frame.getDate_tf().setText(p.getDateOp());
                            frame.getTime_tf().setText(p.getTimeOp());
                            frame.getState_cb().setSelectedItem(p.getStateHCI());
                            frame.getProcedure_notes_ta().setText(p.getNotes());
                            frame.getTitle_label().setText("View Procedure");
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        }
                        if (selectionNode.getUserObject() instanceof utils.QualObs) {
                            utils.QualObs qo = (utils.QualObs) selectionNode.getUserObject();
                            interfaces.addEOC.AddQualitativeObservation frame = new interfaces.addEOC.AddQualitativeObservation("View Qualitative Observation");
                            frame.getCode_tf().setText(qo.getCode());
                            frame.getName_tf().setText(qo.getName());
                            frame.getDate_tf().setText(qo.getDateOp());
                            frame.getTime_tf().setText(qo.getTimeOp());
                            frame.getState_cb().setSelectedItem(qo.getStateHCI());
                            frame.getNotes_ta().setText(qo.getNotes());
                            frame.getDescription_tf().setText(qo.getDescription());
                            frame.getTitle_label().setText("View Qualitative Observation");
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        }
                        if (selectionNode.getUserObject() instanceof utils.QuanObs) {
                            utils.QuanObs qo = (utils.QuanObs) selectionNode.getUserObject();
                            interfaces.addEOC.AddQuantitativeObservation frame = new interfaces.addEOC.AddQuantitativeObservation("View Quantitative Observation");
                            frame.getCode_tf().setText(qo.getCode());
                            frame.getName_tf().setText(qo.getName());
                            frame.getDate_tf().setText(qo.getDateOp());
                            frame.getTime_tf().setText(qo.getTimeOp());
                            frame.getState_cb().setSelectedItem(qo.getStateHCI());
                            frame.getMeasurement_ta().setText(qo.getMeasurementQ());
                            frame.getDescription_ta().setText(qo.getDescription());
                            frame.getTitle_label().setText("View Quantitative Observation");
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                        }
                        /*   if (selectionNode.getUserObject() instanceof utils.MedicineS) {
                         utils.MedicineS med = (utils.MedicineS) selectionNode.getUserObject();
                         interfaces.addEOC.AddMedicine frame = new interfaces.addEOC.AddMedicine("View Medicine");
                         frame.getCode_tf().setText(med.getCode());
                         frame.getName_tf().setText(med.getName());
                         frame.getDateStarted_tf().setText(med.getDateStarted());
                         frame.getDateStopped_tf().setText(med.getDateStopped());
                         frame.getStrength_tf().setText(med.getStrength());
                         frame.getHowTaken_tf().setText(med.getHowTaken());
                         frame.getReason_for_taking_ta().setText(med.getReasonForTaking());
                         frame.getDose_ta().setText(med.getDose());
                         frame.getPrice_tf().setText(med.getPrice() + "");
                         frame.getPrice_unit_cb().setSelectedItem(med.getPriceUnit());
                         frame.getTitle_label().setText("View Medicine");
                         frame.setResizable(false);
                         frame.setLocationRelativeTo(null);
                         frame.setVisible(true);
                         }
                         }*/

                        if (selectionNode.getUserObject() instanceof utils.Pharmacotherapy) {
                            utils.Pharmacotherapy ph = (Pharmacotherapy) selectionNode.getUserObject();
                            interfaces.addEOC.AddPharmacotherapy frame = new interfaces.addEOC.AddPharmacotherapy("View Pharmacotherapy");
                            frame.getTime_tf().setText(ph.getTimeOp());
                            frame.getState_cb().setSelectedItem(ph.getStateHCI());
                            frame.getName_tf().setText(ph.getName());
                            frame.getDate_tf().setText(ph.getDateOp());
                            frame.getTitle_label().setText("View Pharmacotherapy");
                            frame.setResizable(false);
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);

                        }
                    }
                }
            }
        }
    }
}
