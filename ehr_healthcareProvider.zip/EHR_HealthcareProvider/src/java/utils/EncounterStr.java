/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import hcwebservices.ContactEntity;


/**
 *
 * @author Alina
 */
public class EncounterStr extends ContactEntity{

    @Override
    public String toString() {
        return "Encounter  on " + super.consultDate+ " Type "+ consultType;
    }
}
