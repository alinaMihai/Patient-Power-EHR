/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import interfaces.addEOC.AddSymptom;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JList;
import javax.swing.ListModel;

/**
 *
 * @author Alina
 */
public class SymptomsActionJList extends MouseAdapter {
    
    protected JList list;
    
    public SymptomsActionJList(JList l) {
        list = l;
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            int index = list.locationToIndex(e.getPoint());
            ListModel dlm = list.getModel();
            Symptom item = (Symptom) dlm.getElementAt(index);
            list.ensureIndexIsVisible(index);
            // JOptionPane.showMessageDialog(null, "Double clicked on " + item);
            AddSymptom frame = new AddSymptom("Add Symptom DoubleClick");
            String name=item.getName();
            int last_index=name.indexOf("general, please double click to update");
            String new_name=item.getName().substring(0,last_index);
            frame.getName_tf().setText(new_name);
            frame.getTitle_label().setText(new_name);
            frame.getDescription_ta().setText(item.getDescription());
            frame.getAppearance_date_tf().setText(item.getAppearanceDate());
            frame.getDisapperance_date_tf().setText(item.getDisappearanceDate());
            frame.getState_tf().setText(item.getStatus());
            frame.getFrequency_tf().setText(item.getFrequency());
            frame.setResizable(false);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            
        }
    }
}
