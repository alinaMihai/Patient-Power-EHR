/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import interfaces.addEOC.AddSymptom;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JList;
import javax.swing.ListModel;

/**
 *
 * @author Alina
 */
public class ViewSymptomJListAction extends MouseAdapter {
    
    protected JList list;
    
    public ViewSymptomJListAction(JList l) {
        list = l;
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            int index = list.locationToIndex(e.getPoint());
            ListModel dlm = list.getModel();
            Symptom item = (Symptom) dlm.getElementAt(index);
            list.ensureIndexIsVisible(index);
            AddSymptom frame = new AddSymptom("View Symptom");
            frame.getName_tf().setText(item.getName());
            frame.getName_tf().setEditable(false);
            frame.getDescription_ta().setText(item.getDescription());
            frame.getDescription_ta().setEditable(false);
            frame.getAppearance_date_tf().setText(item.getAppearanceDate());
            frame.getAppearance_date_tf().setEditable(false);
            frame.getDisapperance_date_tf().setText(item.getDisappearanceDate());
            frame.getDisapperance_date_tf().setEditable(false);
            frame.getState_tf().setText(item.getStatus());
            frame.getState_tf().setEditable(false);
            frame.getFrequency_tf().setText(item.getFrequency());
            frame.getFrequency_tf().setEditable(false);
            frame.getCancel_bt().setVisible(false);
            frame.getOk_bt().setText("close window");
            frame.getTitle_label().setText(item.getName());
            frame.setResizable(false);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            
        }
    }
}
